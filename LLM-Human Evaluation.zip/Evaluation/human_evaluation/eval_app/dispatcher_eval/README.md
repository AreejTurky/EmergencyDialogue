# 911 Dispatcher Evaluation — Annotation Web App

A self-contained Flask web app for human evaluation of 911 dispatcher conversations.

## What it does

- 21 reviewers self-select into 7 evaluation bins (locks at 3 reviewers per bin)
- Each reviewer rates 30 conversations (15 shared anchors + 15 unique to their bin)
- Results saved as 7 CSV files (one per bin), ready for Krippendorff's α / ICC analysis
- Supports Arabic RTL conversation display
- Resume-safe: reviewers can stop and continue later

## Setup

### 1. Install dependencies

```bash
pip install -r requirements.txt
```

### 2. Prepare your data

Place your conversations as CSV in `data/conversations.csv` with these columns:

| Column | Required | Description |
|---|---|---|
| `conversation_id` | Yes | Unique string identifier |
| `predicted_title` | No | Optional title shown above the conversation in the UI |
| `conversation` | Yes | Full conversation text with `user:` / `assistant:` turns separated by blank lines |
| `block` | No | Ignored — row order is what counts |

**Row order matters:**

- Rows 1–15 → anchor conversations (rated by every reviewer)
- Rows 16–30 → bin 1
- Rows 31–45 → bin 2
- Rows 46–60 → bin 3
- Rows 61–75 → bin 4
- Rows 76–90 → bin 5
- Rows 91–105 → bin 6
- Rows 106–120 → bin 7

The included `data/conversations.csv` already follows this format.

### 3. Run

```bash
python app.py
```

Server starts on `http://localhost:5000`.

### 4. Share with reviewers

**Option A — ngrok (fastest)**

```bash
ngrok http 5000
```

Give reviewers the `https://xxxxx.ngrok-free.app` URL.

**Option B — Deploy to Render (free tier)**

1. Push this folder to a GitHub repo
2. New Web Service on Render → connect repo
3. Build command: `pip install -r requirements.txt`
4. Start command: `gunicorn app:app`
5. Set environment variable `EVAL_SECRET_KEY` to a random string

**Option C — Railway / Fly.io / PythonAnywhere**

Same idea. All have free tiers.

## Output

After reviewers complete their bins, you get seven CSV files:

```
data/results/bin_1.csv  ...  data/results/bin_7.csv
```

Each row:

```
conversation_id, is_anchor, reviewer_name, Q1_location, Q2_consciousness,
Q3_chief_complaint, Q4_question_ordering, Q5_caller_retention,
Q6_pre_arrival, Q7_affective, Q8_callback, Q9_overall, timestamp
```

Q1–Q8 values: `yes` / `no` / `na`
Q9 value: `1`–`5`

## Admin dashboard

```
http://your-host:5000/admin/status?key=admin
```

Set `ADMIN_KEY` environment variable to change the password.

## Configuration

Edit constants at the top of `app.py`:

```python
NUM_BINS = 7
RATERS_PER_BIN = 3
ANCHOR_COUNT = 15
BIN_SIZE = 15
```

## Reviewer workflow

1. Reviewer visits the URL
2. Enters their full name (identifies their ratings in the CSV)
3. Sees 7 bin cards (color-coded: available / in-progress yours / done / full)
4. Clicks an available bin
5. Rates 30 conversations — 9 questions each, "submit & next"
6. Can stop anytime and resume later
7. After 30 conversations, sees a thank-you page

## Notes

- Question order is fixed within the form. If you want randomized question order per item, it's a small JS change.
- Conversation order is fixed (anchors first, then bin items).
- Concurrency is handled with thread locks. Multiple reviewers can rate simultaneously.
- No database — state lives in `data/state.json` and `data/results/*.csv`. Back these up.

## Analysis (next step)

After data collection, compute Krippendorff's α / ICC:

```python
import krippendorff
import pandas as pd

dfs = [pd.read_csv(f"data/results/bin_{i}.csv") for i in range(1, 8)]
all_ratings = pd.concat(dfs)

anchors = all_ratings[all_ratings.is_anchor == "TRUE"]
# ... compute α per criterion across all 21 raters on anchors
```

Ask for the analysis pipeline once you have your CSVs.
