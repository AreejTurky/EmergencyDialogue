"""
911 Dispatcher Evaluation — Human Annotation Web App

Setup:
  1. Place 120 conversations as CSV in data/conversations.csv with columns:
     - conversation_id (unique string)
     - predicted_title (optional, shown above the conversation in the UI)
     - conversation (string with "user:" / "assistant:" turns separated by blank lines)
     - block (optional, ignored — row order is what counts)

     Row order:
       - Rows 1-15    = anchor conversations (rated by all reviewers)
       - Rows 16-30   = bin 1
       - Rows 31-45   = bin 2
       - Rows 46-60   = bin 3
       - Rows 61-75   = bin 4
       - Rows 76-90   = bin 5
       - Rows 91-105  = bin 6
       - Rows 106-120 = bin 7

  2. Run: python app.py
  3. Share via ngrok (recommended) or deploy to Render/Railway

Output:
  data/results/bin_1.csv ... bin_7.csv
  Each CSV: conversation_id, is_anchor, reviewer_name, Q1..Q9, timestamp
"""

import csv
import json
import os
import threading
from datetime import datetime, timezone
from pathlib import Path

from flask import (
    Flask,
    jsonify,
    redirect,
    render_template_string,
    request,
    session,
    url_for,
)

# ───────────────────────────────────────────────────────────────────────────
# Configuration
# ───────────────────────────────────────────────────────────────────────────

BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"
RESULTS_DIR = DATA_DIR / "results"
CONVERSATIONS_FILE = DATA_DIR / "conversations.csv"
STATE_FILE = DATA_DIR / "state.json"

NUM_BINS = 7
RATERS_PER_BIN = 3
ANCHOR_COUNT = 15
BIN_SIZE = 15
TOTAL_PER_REVIEWER = ANCHOR_COUNT + BIN_SIZE  # 30

DATA_DIR.mkdir(exist_ok=True)
RESULTS_DIR.mkdir(exist_ok=True)

# ───────────────────────────────────────────────────────────────────────────
# Flask app
# ───────────────────────────────────────────────────────────────────────────

app = Flask(__name__)
app.secret_key = os.environ.get("EVAL_SECRET_KEY", "dev-secret-please-change-in-prod")

_lock = threading.RLock()


# ───────────────────────────────────────────────────────────────────────────
# Data loading
# ───────────────────────────────────────────────────────────────────────────

def parse_conversation_text(text):
    """Parse a 'user: ... \\n\\nassistant: ... \\n\\nuser: ...' string into messages."""
    if not text:
        return []
    text = text.strip()
    # Split on blank-line followed by a role marker. Tolerant of leading whitespace.
    import re

    # Find all role markers and split there
    pattern = re.compile(r"(?:^|\n\n+)\s*(user|assistant)\s*:\s*", re.IGNORECASE)
    matches = list(pattern.finditer(text))
    if not matches:
        # No role markers — return whole text as a single user turn
        return [{"role": "user", "content": text}]

    messages = []
    for i, m in enumerate(matches):
        role = m.group(1).lower()
        start = m.end()
        end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        content = text[start:end].strip()
        if content:
            messages.append({"role": role, "content": content})
    return messages


def load_conversations():
    """Load CSV. Row order determines anchor/bin assignment.
    First ANCHOR_COUNT rows = anchors. Next NUM_BINS * BIN_SIZE rows = bins in order.
    """
    if not CONVERSATIONS_FILE.exists():
        return [], {i + 1: [] for i in range(NUM_BINS)}

    convs = []
    with open(CONVERSATIONS_FILE, "r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            conv_id = (row.get("conversation_id") or row.get("id") or "").strip()
            title = (row.get("predicted_title") or "").strip()
            text = row.get("conversation") or ""
            if not conv_id or not text:
                continue
            convs.append(
                {
                    "id": conv_id,
                    "title": title,
                    "messages": parse_conversation_text(text),
                }
            )

    expected = ANCHOR_COUNT + NUM_BINS * BIN_SIZE
    if len(convs) != expected:
        print(
            f"⚠  Expected {expected} conversations, found {len(convs)}. "
            f"App will run but may behave unexpectedly."
        )

    anchors = convs[:ANCHOR_COUNT]
    bins = {}
    for i in range(NUM_BINS):
        start = ANCHOR_COUNT + i * BIN_SIZE
        end = start + BIN_SIZE
        bins[i + 1] = convs[start:end]
    return anchors, bins


def load_state():
    with _lock:
        state = None
        if STATE_FILE.exists():
            with open(STATE_FILE, "r", encoding="utf-8") as f:
                state = json.load(f)

        if state is None:
            state = {
                "bins": {
                    str(i): {"completed": [], "in_progress": {}}
                    for i in range(1, NUM_BINS + 1)
                }
            }

        # Keep state compatible if NUM_BINS changes across runs.
        bins = state.setdefault("bins", {})
        for i in range(1, NUM_BINS + 1):
            bins.setdefault(str(i), {"completed": [], "in_progress": {}})
        return state


def save_state(state):
    with _lock:
        with open(STATE_FILE, "w", encoding="utf-8") as f:
            json.dump(state, f, indent=2, ensure_ascii=False)


def ensure_bin_csv(bin_id):
    path = RESULTS_DIR / f"bin_{bin_id}.csv"
    if not path.exists():
        with open(path, "w", encoding="utf-8", newline="") as f:
            w = csv.writer(f)
            w.writerow(
                [
                    "conversation_id",
                    "is_anchor",
                    "reviewer_name",
                    "Q1_location",
                    "Q2_consciousness",
                    "Q3_chief_complaint",
                    "Q4_question_ordering",
                    "Q5_caller_retention",
                    "Q6_pre_arrival",
                    "Q7_affective",
                    "Q8_callback",
                    "Q9_overall",
                    "timestamp",
                ]
            )
    return path


def append_rating(bin_id, row):
    path = ensure_bin_csv(bin_id)
    with _lock:
        with open(path, "a", encoding="utf-8", newline="") as f:
            w = csv.writer(f)
            w.writerow(row)


ANCHORS, BINS = load_conversations()


# ───────────────────────────────────────────────────────────────────────────
# Helpers
# ───────────────────────────────────────────────────────────────────────────

def get_bin_status(state, bin_id, reviewer):
    """available / in_progress_you / completed_you / full"""
    b = state["bins"][str(bin_id)]
    if reviewer in b["completed"]:
        return "completed_you"
    if reviewer in b["in_progress"]:
        return "in_progress_you"
    if len(b["completed"]) + len(b["in_progress"]) >= RATERS_PER_BIN:
        return "full"
    return "available"


def get_reviewer_progress(state, bin_id, reviewer):
    """Returns the index of the next conversation the reviewer should rate."""
    b = state["bins"][str(bin_id)]
    if reviewer in b["in_progress"]:
        return b["in_progress"][reviewer].get("next_index", 0)
    return 0


def reviewer_queue(bin_id):
    """Returns the list of (conv, is_anchor) tuples for a bin's reviewer.
    Anchors first, then bin items. Order is fixed (no per-reviewer randomization
    of conversation order — keeps debugging simple. Question order IS randomized client-side.)
    """
    queue = []
    for c in ANCHORS:
        queue.append({"conv": c, "is_anchor": True})
    for c in BINS.get(bin_id, []):
        queue.append({"conv": c, "is_anchor": False})
    return queue


# ───────────────────────────────────────────────────────────────────────────
# Routes
# ───────────────────────────────────────────────────────────────────────────

@app.route("/")
def login():
    if session.get("reviewer"):
        return redirect(url_for("bins"))
    return render_template_string(LOGIN_HTML)


@app.route("/login", methods=["POST"])
def do_login():
    name = request.form.get("name", "").strip()
    if not name or len(name) < 2:
        return render_template_string(LOGIN_HTML, error="Please enter a valid name.")
    session["reviewer"] = name
    return redirect(url_for("bins"))


@app.route("/logout")
def logout():
    session.pop("reviewer", None)
    return redirect(url_for("login"))


@app.route("/bins")
def bins():
    reviewer = session.get("reviewer")
    if not reviewer:
        return redirect(url_for("login"))

    state = load_state()
    bin_data = []
    for i in range(1, NUM_BINS + 1):
        b = state["bins"][str(i)]
        status = get_bin_status(state, i, reviewer)
        completed_count = len(b["completed"])
        in_progress_count = len(b["in_progress"])
        bin_data.append(
            {
                "id": i,
                "status": status,
                "completed": completed_count,
                "in_progress": in_progress_count,
                "total_slots": RATERS_PER_BIN,
            }
        )

    return render_template_string(
        BINS_HTML,
        reviewer=reviewer,
        bins=bin_data,
        total_per_reviewer=TOTAL_PER_REVIEWER,
        raters_per_bin=RATERS_PER_BIN,
    )


@app.route("/start/<int:bin_id>")
def start_bin(bin_id):
    reviewer = session.get("reviewer")
    if not reviewer:
        return redirect(url_for("login"))
    if bin_id < 1 or bin_id > NUM_BINS:
        return redirect(url_for("bins"))

    state = load_state()
    status = get_bin_status(state, bin_id, reviewer)

    if status == "completed_you":
        return redirect(url_for("bins"))
    if status == "full":
        return redirect(url_for("bins"))

    # Reserve a slot if not already reserved
    b = state["bins"][str(bin_id)]
    if reviewer not in b["in_progress"]:
        # Final check before reserving
        if len(b["completed"]) + len(b["in_progress"]) >= RATERS_PER_BIN:
            return redirect(url_for("bins"))
        b["in_progress"][reviewer] = {
            "next_index": 0,
            "started_at": datetime.now(timezone.utc).isoformat(),
        }
        save_state(state)

    return redirect(url_for("rate", bin_id=bin_id))


@app.route("/rate/<int:bin_id>")
def rate(bin_id):
    reviewer = session.get("reviewer")
    if not reviewer:
        return redirect(url_for("login"))

    state = load_state()
    b = state["bins"][str(bin_id)]
    if reviewer not in b["in_progress"]:
        return redirect(url_for("bins"))

    queue = reviewer_queue(bin_id)
    next_index = b["in_progress"][reviewer].get("next_index", 0)

    if next_index >= len(queue):
        # Done — promote from in_progress to completed
        del b["in_progress"][reviewer]
        if reviewer not in b["completed"]:
            b["completed"].append(reviewer)
        save_state(state)
        return render_template_string(
            DONE_HTML,
            bin_id=bin_id,
            reviewer=reviewer,
            total_per_reviewer=TOTAL_PER_REVIEWER,
        )

    item = queue[next_index]
    return render_template_string(
        RATE_HTML,
        bin_id=bin_id,
        reviewer=reviewer,
        conv=item["conv"],
        is_anchor=item["is_anchor"],
        index=next_index,
        total=len(queue),
        progress_pct=int(next_index / len(queue) * 100),
    )


@app.route("/submit/<int:bin_id>", methods=["POST"])
def submit(bin_id):
    reviewer = session.get("reviewer")
    if not reviewer:
        return jsonify({"ok": False, "error": "not_logged_in"}), 401

    state = load_state()
    b = state["bins"][str(bin_id)]
    if reviewer not in b["in_progress"]:
        return jsonify({"ok": False, "error": "no_session"}), 400

    next_index = b["in_progress"][reviewer].get("next_index", 0)
    queue = reviewer_queue(bin_id)
    if next_index >= len(queue):
        return jsonify({"ok": False, "error": "already_done"}), 400

    item = queue[next_index]
    conv_id = item["conv"].get("id", f"unknown_{next_index}")
    is_anchor = item["is_anchor"]

    # Validate all 9 answers present
    answers = {}
    for i in range(1, 10):
        v = request.form.get(f"q{i}")
        if v is None or v == "":
            return jsonify({"ok": False, "error": f"missing_q{i}"}), 400
        answers[f"q{i}"] = v

    timestamp = datetime.now(timezone.utc).isoformat()
    row = [
        conv_id,
        "TRUE" if is_anchor else "FALSE",
        reviewer,
        answers["q1"], answers["q2"], answers["q3"], answers["q4"],
        answers["q5"], answers["q6"], answers["q7"], answers["q8"],
        answers["q9"],
        timestamp,
    ]
    append_rating(bin_id, row)

    # Advance pointer
    b["in_progress"][reviewer]["next_index"] = next_index + 1
    save_state(state)

    return jsonify({"ok": True, "next_index": next_index + 1, "total": len(queue)})


@app.route("/admin/status")
def admin_status():
    """Read-only status dashboard. Optionally protect with ?key=..."""
    key = request.args.get("key", "")
    expected = os.environ.get("ADMIN_KEY", "admin")
    if key != expected:
        return "Unauthorized — pass ?key=<admin_key>", 401

    state = load_state()
    return render_template_string(
        ADMIN_HTML,
        state=state,
        num_bins=NUM_BINS,
        raters_per_bin=RATERS_PER_BIN,
        total_per_reviewer=TOTAL_PER_REVIEWER,
    )


# ───────────────────────────────────────────────────────────────────────────
# Templates (embedded)
# ───────────────────────────────────────────────────────────────────────────

BASE_CSS = """
<style>
  :root {
    --ink: #1a1a1a;
    --ink-soft: #4a4a4a;
    --paper: #faf8f3;
    --paper-2: #f0ece2;
    --rule: #d6d2c4;
    --accent: #8b1e1e;
    --accent-soft: #f4e6e6;
    --green: #2d6a4f;
    --green-soft: #e2efe7;
    --grey: #888;
    --grey-soft: #e5e3da;
  }
  * { box-sizing: border-box; }
  html, body {
    margin: 0; padding: 0;
    background: var(--paper);
    color: var(--ink);
    font-family: 'Source Serif Pro', 'Lora', Georgia, serif;
    font-size: 16px;
    line-height: 1.55;
  }
  .container {
    max-width: 980px;
    margin: 0 auto;
    padding: 40px 24px;
  }
  .container-narrow { max-width: 560px; }
  h1 {
    font-family: 'Source Serif Pro', Georgia, serif;
    font-weight: 600;
    font-size: 2rem;
    margin: 0 0 8px 0;
    letter-spacing: -0.01em;
  }
  h2 {
    font-family: 'Source Serif Pro', Georgia, serif;
    font-weight: 500;
    font-size: 1.25rem;
    margin: 24px 0 12px 0;
  }
  .eyebrow {
    font-family: 'IBM Plex Mono', 'Courier New', monospace;
    font-size: 0.75rem;
    text-transform: uppercase;
    letter-spacing: 0.15em;
    color: var(--ink-soft);
    margin-bottom: 8px;
  }
  .rule {
    border: 0;
    border-top: 1px solid var(--rule);
    margin: 24px 0;
  }
  .button {
    display: inline-block;
    padding: 12px 24px;
    background: var(--ink);
    color: var(--paper);
    text-decoration: none;
    border: none;
    border-radius: 0;
    font-family: 'IBM Plex Mono', monospace;
    font-size: 0.9rem;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    cursor: pointer;
    transition: background 0.15s;
  }
  .button:hover { background: var(--accent); }
  .button:disabled, .button.disabled {
    background: var(--grey-soft);
    color: var(--grey);
    cursor: not-allowed;
  }
  .button-secondary {
    background: transparent;
    color: var(--ink);
    border: 1px solid var(--ink);
  }
  .button-secondary:hover { background: var(--ink); color: var(--paper); }
  input[type=text] {
    width: 100%;
    padding: 12px 14px;
    border: 1px solid var(--rule);
    background: white;
    font-family: inherit;
    font-size: 1rem;
    color: var(--ink);
  }
  input[type=text]:focus {
    outline: none;
    border-color: var(--accent);
  }
  .error {
    color: var(--accent);
    font-size: 0.9rem;
    margin-top: 8px;
  }
  .small { font-size: 0.85rem; color: var(--ink-soft); }
  .topbar {
    border-bottom: 1px solid var(--rule);
    padding: 16px 24px;
    background: var(--paper-2);
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  .topbar-title {
    font-family: 'IBM Plex Mono', monospace;
    font-size: 0.8rem;
    text-transform: uppercase;
    letter-spacing: 0.1em;
  }
  .topbar a {
    color: var(--ink-soft);
    font-family: 'IBM Plex Mono', monospace;
    font-size: 0.8rem;
    text-decoration: none;
  }
  .topbar a:hover { color: var(--accent); }
</style>
"""

LOGIN_HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Dispatcher Evaluation — Sign in</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Source+Serif+Pro:wght@400;500;600&family=IBM+Plex+Mono:wght@400;500&family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet">
""" + BASE_CSS + """
</head>
<body>
  <div class="container container-narrow" style="padding-top: 80px;">
    <div class="eyebrow">911 Dispatcher Evaluation</div>
    <h1>Reviewer sign in</h1>
    <p class="small">Enter your full name. This identifies your ratings in the output and tracks your progress across sessions.</p>
    <hr class="rule">
    <form method="POST" action="/login">
      <input type="text" name="name" placeholder="Full name" autocomplete="name" required minlength="2" autofocus>
      {% if error %}<div class="error">{{ error }}</div>{% endif %}
      <div style="margin-top: 16px;">
        <button class="button" type="submit">Continue →</button>
      </div>
    </form>
  </div>
</body>
</html>
"""

BINS_HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Choose a bin — Dispatcher Evaluation</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Source+Serif+Pro:wght@400;500;600&family=IBM+Plex+Mono:wght@400;500&family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet">
""" + BASE_CSS + """
<style>
  .bin-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
    gap: 16px;
    margin-top: 32px;
  }
  .bin-card {
    border: 1px solid var(--rule);
    background: white;
    padding: 24px 20px;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    gap: 8px;
    text-decoration: none;
    color: var(--ink);
    transition: border-color 0.15s, transform 0.15s;
    position: relative;
  }
  .bin-card.available:hover {
    border-color: var(--ink);
    transform: translateY(-2px);
  }
  .bin-card.in-progress-you {
    border-color: var(--accent);
    background: var(--accent-soft);
  }
  .bin-card.completed-you {
    background: var(--green-soft);
    border-color: var(--green);
    color: var(--green);
    cursor: not-allowed;
  }
  .bin-card.full {
    background: var(--grey-soft);
    color: var(--grey);
    cursor: not-allowed;
  }
  .bin-num {
    font-family: 'Source Serif Pro', Georgia, serif;
    font-size: 3rem;
    font-weight: 600;
    line-height: 1;
  }
  .bin-status {
    font-family: 'IBM Plex Mono', monospace;
    font-size: 0.7rem;
    text-transform: uppercase;
    letter-spacing: 0.12em;
    color: var(--ink-soft);
  }
  .bin-card.in-progress-you .bin-status { color: var(--accent); }
  .bin-card.completed-you .bin-status { color: var(--green); }
  .bin-card.full .bin-status { color: var(--grey); }
  .bin-slots {
    font-family: 'IBM Plex Mono', monospace;
    font-size: 0.8rem;
    color: var(--ink-soft);
    margin-top: auto;
  }
  .info-box {
    background: var(--paper-2);
    border-left: 3px solid var(--ink);
    padding: 16px 20px;
    margin: 24px 0;
    font-size: 0.9rem;
  }
  .info-box ul { margin: 8px 0 0 0; padding-left: 20px; }
</style>
</head>
<body>
  <div class="topbar">
    <span class="topbar-title">911 Evaluation · {{ reviewer }}</span>
    <a href="/logout">Sign out</a>
  </div>
  <div class="container">
    <div class="eyebrow">Step 1 of 2</div>
    <h1>Choose an evaluation bin</h1>
    <p class="small">You will rate <strong>{{ total_per_reviewer }} conversations</strong> total: 15 shared anchor items + 15 unique items from your chosen bin. Approximately 90 minutes.</p>

    <div class="info-box">
      <strong>Before you start:</strong>
      <ul>
        <li>You can stop and resume — your progress is saved automatically.</li>
        <li>Each bin closes once {{ raters_per_bin }} reviewers have completed it.</li>
        <li>Once you start a bin, please finish it before switching.</li>
      </ul>
    </div>

    <p class="small"><strong>Please select a single bin to start evaluation</strong></p>

    <div class="bin-grid">
      {% for b in bins %}
        {% if b.status == 'available' %}
          <a href="/start/{{ b.id }}" class="bin-card available">
            <div class="bin-num">{{ b.id }}</div>
            <div class="bin-status">Available</div>
            <div class="bin-slots">{{ b.completed + b.in_progress }} / {{ b.total_slots }} reviewers</div>
          </a>
        {% elif b.status == 'in_progress_you' %}
          <a href="/rate/{{ b.id }}" class="bin-card in-progress-you">
            <div class="bin-num">{{ b.id }}</div>
            <div class="bin-status">► Continue</div>
            <div class="bin-slots">{{ b.completed + b.in_progress }} / {{ b.total_slots }} reviewers</div>
          </a>
        {% elif b.status == 'completed_you' %}
          <div class="bin-card completed-you">
            <div class="bin-num">{{ b.id }}</div>
            <div class="bin-status">✓ Done</div>
            <div class="bin-slots">{{ b.completed + b.in_progress }} / {{ b.total_slots }} reviewers</div>
          </div>
        {% else %}
          <div class="bin-card full">
            <div class="bin-num">{{ b.id }}</div>
            <div class="bin-status">Full</div>
            <div class="bin-slots">{{ b.completed + b.in_progress }} / {{ b.total_slots }} reviewers</div>
          </div>
        {% endif %}
      {% endfor %}
    </div>
  </div>
</body>
</html>
"""

RATE_HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Rating · Bin {{ bin_id }} · {{ index + 1 }} / {{ total }}</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Source+Serif+Pro:wght@400;500;600&family=IBM+Plex+Mono:wght@400;500&family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet">
""" + BASE_CSS + """
<style>
  body { background: var(--paper-2); }
  .layout {
    display: grid;
    grid-template-columns: minmax(0, 1.3fr) minmax(0, 1fr);
    gap: 32px;
    max-width: 1280px;
    margin: 0 auto;
    padding: 24px;
  }
  @media (max-width: 900px) {
    .layout { grid-template-columns: 1fr; }
  }
  .progress-bar {
    height: 4px;
    background: var(--rule);
    margin-bottom: 16px;
  }
  .progress-fill {
    height: 100%;
    background: var(--ink);
    width: {{ progress_pct }}%;
    transition: width 0.3s;
  }
  .conv-panel {
    background: white;
    border: 1px solid var(--rule);
    padding: 24px;
    max-height: calc(100vh - 100px);
    overflow-y: auto;
    position: sticky;
    top: 24px;
  }
  .messages { direction: rtl; text-align: right; font-family: 'Tajawal', 'Noto Sans Arabic', sans-serif; font-size: 1rem; line-height: 1.7; }
  .msg { margin: 12px 0; padding: 12px 16px; border-radius: 4px; }
  .msg-user { background: var(--paper-2); border-left: 3px solid var(--ink-soft); }
  .msg-assistant { background: var(--accent-soft); border-left: 3px solid var(--accent); }
  .msg-role {
    font-family: 'IBM Plex Mono', monospace;
    font-size: 0.7rem;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    color: var(--ink-soft);
    margin-bottom: 6px;
    direction: ltr;
    text-align: left;
  }
  .form-panel {
    background: white;
    border: 1px solid var(--rule);
    padding: 24px;
  }
  .question {
    border-bottom: 1px solid var(--rule);
    padding: 16px 0;
  }
  .question:last-of-type { border-bottom: none; }
  .question-num {
    font-family: 'IBM Plex Mono', monospace;
    font-size: 0.75rem;
    color: var(--accent);
    letter-spacing: 0.1em;
  }
  .question-text {
    font-size: 0.95rem;
    line-height: 1.4;
    margin: 4px 0 12px 0;
  }
  .question-source {
    font-size: 0.75rem;
    color: var(--ink-soft);
    margin-bottom: 10px;
    font-style: italic;
  }
  .radio-group {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
  }
  .radio-option {
    flex: 1;
    min-width: 70px;
  }
  .radio-option input { display: none; }
  .radio-option label {
    display: block;
    padding: 8px 12px;
    border: 1px solid var(--rule);
    text-align: center;
    cursor: pointer;
    font-family: 'IBM Plex Mono', monospace;
    font-size: 0.8rem;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    transition: all 0.15s;
    background: white;
  }
  .radio-option input:checked + label {
    background: var(--ink);
    color: var(--paper);
    border-color: var(--ink);
  }
  .radio-option label:hover { border-color: var(--ink); }
  .scale-group {
    display: grid;
    grid-template-columns: repeat(5, 1fr);
    gap: 4px;
  }
  .scale-option input { display: none; }
  .scale-option label {
    display: block;
    padding: 12px 4px;
    border: 1px solid var(--rule);
    text-align: center;
    cursor: pointer;
    font-family: 'Source Serif Pro', serif;
    font-size: 1.2rem;
    transition: all 0.15s;
    background: white;
  }
  .scale-option input:checked + label {
    background: var(--accent);
    color: var(--paper);
    border-color: var(--accent);
  }
  .scale-labels {
    display: flex;
    justify-content: space-between;
    font-size: 0.7rem;
    color: var(--ink-soft);
    margin-top: 4px;
    font-family: 'IBM Plex Mono', monospace;
  }
  .anchor-badge {
    display: inline-block;
    padding: 3px 8px;
    background: var(--ink);
    color: var(--paper);
    font-family: 'IBM Plex Mono', monospace;
    font-size: 0.7rem;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    margin-left: 8px;
  }
  .submit-row {
    margin-top: 24px;
    display: flex;
    gap: 12px;
    align-items: center;
  }
  .timer {
    font-family: 'IBM Plex Mono', monospace;
    font-size: 0.8rem;
    color: var(--ink-soft);
    margin-left: auto;
  }
  .err-msg {
    background: var(--accent-soft);
    color: var(--accent);
    padding: 8px 12px;
    margin-top: 8px;
    font-size: 0.85rem;
    display: none;
  }
</style>
</head>
<body>
  <div class="topbar">
    <span class="topbar-title">Bin {{ bin_id }} · {{ index + 1 }} of {{ total }}{% if is_anchor %} · ANCHOR{% endif %}</span>
    <a href="/bins">Save & exit</a>
  </div>
  <div class="progress-bar"><div class="progress-fill"></div></div>

  <div class="layout">
    <div class="conv-panel">
      <div class="eyebrow">Conversation
        {% if is_anchor %}<span class="anchor-badge">Anchor</span>{% endif %}
      </div>
      <h2 style="margin-top: 0; font-family: 'IBM Plex Mono', monospace; font-size: 0.85rem; color: var(--ink-soft);">ID: {{ conv.id }}</h2>
      <hr class="rule">
      <div class="messages">
        {% for m in conv.messages %}
          <div class="msg {% if m.role == 'user' %}msg-user{% else %}msg-assistant{% endif %}">
            <div class="msg-role">{{ m.role }}</div>
            <div>{{ m.content }}</div>
          </div>
        {% endfor %}
      </div>
    </div>

    <div class="form-panel">
      <div class="eyebrow">Rate this conversation</div>
      <form id="rating-form">
        <!-- Q1 -->
        <div class="question">
          <div class="question-num">Q1 · Location completeness</div>
          <div class="question-text">Did the dispatcher collect an exact address or specific location <em>before</em> dispatching help?</div>
          <div class="radio-group">
            <div class="radio-option"><input type="radio" name="q1" id="q1y" value="yes"><label for="q1y">Yes</label></div>
            <div class="radio-option"><input type="radio" name="q1" id="q1n" value="no"><label for="q1n">No</label></div>
            <div class="radio-option"><input type="radio" name="q1" id="q1na" value="na"><label for="q1na">N/A</label></div>
          </div>
        </div>
        <!-- Q2 -->
        <div class="question">
          <div class="question-num">Q2 · Consciousness & breathing</div>
          <div class="question-text">For medical calls: did the dispatcher explicitly ask whether the patient is conscious and breathing?</div>
          <div class="question-source">N/A for non-medical calls.</div>
          <div class="radio-group">
            <div class="radio-option"><input type="radio" name="q2" id="q2y" value="yes"><label for="q2y">Yes</label></div>
            <div class="radio-option"><input type="radio" name="q2" id="q2n" value="no"><label for="q2n">No</label></div>
            <div class="radio-option"><input type="radio" name="q2" id="q2na" value="na"><label for="q2na">N/A</label></div>
          </div>
        </div>
        <!-- Q3 -->
        <div class="question">
          <div class="question-num">Q3 · Chief complaint accuracy</div>
          <div class="question-text">Was the nature of the emergency correctly identified and confirmed in the first exchange?</div>
          <div class="radio-group">
            <div class="radio-option"><input type="radio" name="q3" id="q3y" value="yes"><label for="q3y">Yes</label></div>
            <div class="radio-option"><input type="radio" name="q3" id="q3n" value="no"><label for="q3n">No</label></div>
            <div class="radio-option"><input type="radio" name="q3" id="q3na" value="na"><label for="q3na">N/A</label></div>
          </div>
        </div>
        <!-- Q4 -->
        <div class="question">
          <div class="question-num">Q4 · Question ordering compliance</div>
          <div class="question-text">Did the dispatcher follow the correct protocol sequence (location → callback → chief complaint → sub-questions) without skipping steps?</div>
          <div class="radio-group">
            <div class="radio-option"><input type="radio" name="q4" id="q4y" value="yes"><label for="q4y">Yes</label></div>
            <div class="radio-option"><input type="radio" name="q4" id="q4n" value="no"><label for="q4n">No</label></div>
            <div class="radio-option"><input type="radio" name="q4" id="q4na" value="na"><label for="q4na">N/A</label></div>
          </div>
        </div>
        <!-- Q5 -->
        <div class="question">
          <div class="question-num">Q5 · Caller retention</div>
          <div class="question-text">Did the dispatcher explicitly ask the caller to stay on the line until help arrives?</div>
          <div class="radio-group">
            <div class="radio-option"><input type="radio" name="q5" id="q5y" value="yes"><label for="q5y">Yes</label></div>
            <div class="radio-option"><input type="radio" name="q5" id="q5n" value="no"><label for="q5n">No</label></div>
            <div class="radio-option"><input type="radio" name="q5" id="q5na" value="na"><label for="q5na">N/A</label></div>
          </div>
        </div>
        <!-- Q6 -->
        <div class="question">
          <div class="question-num">Q6 · Pre-arrival instructions</div>
          <div class="question-text">Did the dispatcher provide actionable safety instructions while waiting for responders, without asking permission?</div>
          <div class="radio-group">
            <div class="radio-option"><input type="radio" name="q6" id="q6y" value="yes"><label for="q6y">Yes</label></div>
            <div class="radio-option"><input type="radio" name="q6" id="q6n" value="no"><label for="q6n">No</label></div>
            <div class="radio-option"><input type="radio" name="q6" id="q6na" value="na"><label for="q6na">N/A</label></div>
          </div>
        </div>
        <!-- Q7 -->
        <div class="question">
          <div class="question-num">Q7 · Affective calibration</div>
          <div class="question-text">Did the dispatcher remain calm, reassuring, and professional without blaming or dismissing the caller's distress?</div>
          <div class="radio-group">
            <div class="radio-option"><input type="radio" name="q7" id="q7y" value="yes"><label for="q7y">Yes</label></div>
            <div class="radio-option"><input type="radio" name="q7" id="q7n" value="no"><label for="q7n">No</label></div>
            <div class="radio-option"><input type="radio" name="q7" id="q7na" value="na"><label for="q7na">N/A</label></div>
          </div>
        </div>
        <!-- Q8 -->
        <div class="question">
          <div class="question-num">Q8 · Callback number</div>
          <div class="question-text">Was a callback number collected in case the call is disconnected?</div>
          <div class="radio-group">
            <div class="radio-option"><input type="radio" name="q8" id="q8y" value="yes"><label for="q8y">Yes</label></div>
            <div class="radio-option"><input type="radio" name="q8" id="q8n" value="no"><label for="q8n">No</label></div>
            <div class="radio-option"><input type="radio" name="q8" id="q8na" value="na"><label for="q8na">N/A</label></div>
          </div>
        </div>
        <!-- Q9 -->
        <div class="question">
          <div class="question-num">Q9 · Overall dispatcher quality</div>
          <div class="question-text">How would you rate the dispatcher's overall performance on this call?</div>
          <div class="scale-group">
            {% for n in range(1, 6) %}
              <div class="scale-option"><input type="radio" name="q9" id="q9_{{ n }}" value="{{ n }}"><label for="q9_{{ n }}">{{ n }}</label></div>
            {% endfor %}
          </div>
          <div class="scale-labels"><span>1 — Dangerously poor</span><span>5 — Exemplary</span></div>
        </div>

        <div class="err-msg" id="err">Please answer all 9 questions before continuing.</div>

        <div class="submit-row">
          <button type="submit" class="button" id="submit-btn">Submit & next →</button>
          <span class="timer" id="timer">0s on this conversation</span>
        </div>
      </form>
    </div>
  </div>

  <script>
    // Timer
    const start = Date.now();
    setInterval(() => {
      const sec = Math.floor((Date.now() - start) / 1000);
      const min = Math.floor(sec / 60);
      const rem = sec % 60;
      document.getElementById('timer').textContent = min > 0 ? `${min}m ${rem}s` : `${sec}s on this conversation`;
    }, 1000);

    // Submit
    document.getElementById('rating-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const form = e.target;
      const fd = new FormData(form);
      // Validate
      for (let i = 1; i <= 9; i++) {
        if (!fd.get('q' + i)) {
          document.getElementById('err').style.display = 'block';
          document.querySelector(`input[name=q${i}]`).scrollIntoView({behavior: 'smooth', block: 'center'});
          return;
        }
      }
      document.getElementById('err').style.display = 'none';
      const btn = document.getElementById('submit-btn');
      btn.disabled = true;
      btn.textContent = 'Saving...';
      try {
        const resp = await fetch('/submit/{{ bin_id }}', { method: 'POST', body: fd });
        const data = await resp.json();
        if (data.ok) {
          window.location.href = '/rate/{{ bin_id }}';
        } else {
          alert('Error saving: ' + (data.error || 'unknown'));
          btn.disabled = false;
          btn.textContent = 'Submit & next →';
        }
      } catch (err) {
        alert('Network error. Please try again.');
        btn.disabled = false;
        btn.textContent = 'Submit & next →';
      }
    });
  </script>
</body>
</html>
"""

DONE_HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Bin {{ bin_id }} complete</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Source+Serif+Pro:wght@400;500;600&family=IBM+Plex+Mono:wght@400;500&display=swap" rel="stylesheet">
""" + BASE_CSS + """
</head>
<body>
  <div class="topbar">
    <span class="topbar-title">911 Evaluation · {{ reviewer }}</span>
    <a href="/logout">Sign out</a>
  </div>
  <div class="container container-narrow" style="padding-top: 60px;">
    <div class="eyebrow">Bin {{ bin_id }} complete</div>
    <h1>Thank you, {{ reviewer }}.</h1>
    <p>You have completed all {{ total_per_reviewer }} conversations in Bin {{ bin_id }}. Your ratings have been saved.</p>
    <hr class="rule">
    <p>You can pick another bin if any are still open, or sign out.</p>
    <div style="display: flex; gap: 12px; margin-top: 24px;">
      <a href="/bins" class="button">Choose another bin</a>
      <a href="/logout" class="button button-secondary">Sign out</a>
    </div>
  </div>
</body>
</html>
"""

ADMIN_HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Admin · Status</title>
  <link href="https://fonts.googleapis.com/css2?family=Source+Serif+Pro:wght@400;500;600&family=IBM+Plex+Mono:wght@400;500&display=swap" rel="stylesheet">
""" + BASE_CSS + """
<style>
  table { width: 100%; border-collapse: collapse; margin-top: 16px; }
  th, td { text-align: left; padding: 10px 14px; border-bottom: 1px solid var(--rule); font-family: 'IBM Plex Mono', monospace; font-size: 0.85rem; }
  th { background: var(--paper-2); text-transform: uppercase; letter-spacing: 0.08em; font-size: 0.75rem; }
</style>
</head>
<body>
  <div class="container">
    <div class="eyebrow">Admin</div>
    <h1>Evaluation status</h1>
    <table>
      <tr><th>Bin</th><th>Completed</th><th>In progress</th><th>Slots</th></tr>
      {% for i in range(1, num_bins + 1) %}
      <tr>
        <td>{{ i }}</td>
        <td>{{ ', '.join(state.bins[i|string].completed) or '—' }}</td>
        <td>
          {% for r, p in state.bins[i|string].in_progress.items() %}
            {{ r }} ({{ p.next_index }}/{{ total_per_reviewer }}){% if not loop.last %}, {% endif %}
          {% endfor %}
          {% if not state.bins[i|string].in_progress %}—{% endif %}
        </td>
        <td>{{ state.bins[i|string].completed|length + state.bins[i|string].in_progress|length }} / {{ raters_per_bin }}</td>
      </tr>
      {% endfor %}
    </table>
  </div>
</body>
</html>
"""


# ───────────────────────────────────────────────────────────────────────────
# Entrypoint
# ───────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("=" * 60)
    print("911 Dispatcher Evaluation server")
    print("=" * 60)
    print(f"  Conversations file: {CONVERSATIONS_FILE}")
    print(f"  Anchors loaded:     {len(ANCHORS)}")
    for i, c in BINS.items():
        print(f"  Bin {i} loaded:       {len(c)} conversations")
    print(f"  Results dir:        {RESULTS_DIR}")
    print(f"  State file:         {STATE_FILE}")
    print(f"  Admin URL:          /admin/status?key=<ADMIN_KEY env var, default 'admin'>")
    print("=" * 60)
    app.run(host="0.0.0.0", port=5050, debug=False)
