"""
Stratified sample of 120 conversations covering all 73 labels.
Strategy: floor of 1 sample per label, then distribute remaining
slots proportionally to label frequency (largest-remainder method).
"""
import pandas as pd
import numpy as np

INPUT_PATH  = "/mnt/user-data/uploads/conversation_title_mapping.xlsx"
OUTPUT_PATH = "/mnt/user-data/outputs/eval_sample_120.csv"
LABEL_COL   = "predicted_title"
N_SAMPLE    = 120
SEED        = 42


def largest_remainder(weights: pd.Series, total: int) -> pd.Series:
    raw   = weights / weights.sum() * total
    base  = np.floor(raw).astype(int)
    short = total - base.sum()
    frac  = (raw - base).sort_values(ascending=False)
    base.loc[frac.head(int(short)).index] += 1
    return base


def allocate_floor1_proportional(counts: pd.Series, n: int) -> pd.Series:
    L = len(counts)
    if n < L:
        raise ValueError(f"n={n} < number of labels={L}")
    alloc = largest_remainder(counts, n - L) + 1
    return alloc.clip(upper=counts).astype(int)


def stratified_sample(df, alloc, label_col, seed):
    rng = np.random.default_rng(seed)
    parts = []
    for label, k in alloc.items():
        group = df[df[label_col] == label]
        idx   = rng.choice(group.index, size=k, replace=False)
        parts.append(df.loc[idx])
    return pd.concat(parts).sample(frac=1, random_state=seed).reset_index(drop=True)


df     = pd.read_excel(INPUT_PATH)
counts = df[LABEL_COL].value_counts()
alloc  = allocate_floor1_proportional(counts, N_SAMPLE)

sample = stratified_sample(df, alloc, LABEL_COL, SEED)

# Add empty columns for human evaluator.
sample["human_label"] = ""
sample["is_correct"]  = ""
sample["notes"]       = ""

sample.to_csv(OUTPUT_PATH, index=False, encoding="utf-8-sig")

# Sanity check
print(f"Total sampled:    {len(sample)}")
print(f"Labels covered:   {sample[LABEL_COL].nunique()} / {len(counts)}")
print(f"Top label share:  {alloc.max()} samples ({alloc.max()/N_SAMPLE:.1%})")
print(f"Singleton labels: {(alloc == 1).sum()}")
print(f"Saved to:         {OUTPUT_PATH}")