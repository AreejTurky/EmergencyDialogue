"""
Merge the 120-row eval CSV with the source conversations file.

Output: same 120 rows in the same order, with the columns
human_label / is_correct / notes dropped and a new 'conversation' column
populated from the source file.
"""
import pandas as pd
import json
import ast
from pathlib import Path

# ---------- config ----------
EVAL_CSV    = "/Users/linaalqahtani/Desktop/neurips_human_eval/eval_sample_120_spread.csv"
SOURCE_PATH = "/Users/linaalqahtani/Desktop/neurips_human_eval/sft_chatml.jsonl"   # <-- fill in
OUTPUT_CSV  = "/Users/linaalqahtani/Desktop/neurips_human_eval/eval_sample_120_with_convs.csv"

ID_COL      = "conversation_id"   # id column in the eval CSV
SRC_ID_COL  = "id"                # id column in the source file
SRC_MSG_COL = "messages"          # messages column in the source file

CONV_FORMAT = "readable"          # "readable" (role: content blocks) or "json"
# ----------------------------


def load_source(path: str) -> pd.DataFrame:
    """Load conversations. Supports .json, .jsonl, .parquet, .csv."""
    p = Path(path)
    s = p.suffix.lower()
    if s == ".jsonl":   return pd.read_json(p, lines=True)
    if s == ".json":    return pd.read_json(p)
    if s == ".parquet": return pd.read_parquet(p)
    if s == ".csv":     return pd.read_csv(p)
    raise ValueError(f"unsupported source extension: {s}")


def parse_msgs(m):
    """Ensure messages are a list of dicts even if stored as a string."""
    if isinstance(m, list):
        return m
    if isinstance(m, str):
        try:
            return json.loads(m)
        except json.JSONDecodeError:
            return ast.literal_eval(m)        # handles Python-repr strings
    raise TypeError(f"unexpected messages type: {type(m)}")


def format_conv(msgs, mode):
    msgs = parse_msgs(msgs)
    if mode == "json":
        return json.dumps(msgs, ensure_ascii=False)
    return "\n\n".join(f"{m['role']}: {m['content']}" for m in msgs)


# ---------- load ----------
eval_df = pd.read_csv(EVAL_CSV)
src_df  = load_source(SOURCE_PATH)

# ---------- validate uniqueness in the source ----------
dups = src_df[SRC_ID_COL][src_df[SRC_ID_COL].duplicated(keep=False)].unique()
if len(dups):
    raise ValueError(
        f"Source file has {len(dups)} duplicate id(s). "
        f"Each id must map to exactly one conversation. "
        f"Examples: {list(dups[:5])}"
    )

id_to_msgs = dict(zip(src_df[SRC_ID_COL], src_df[SRC_MSG_COL]))

# ---------- merge in eval-CSV order ----------
missing, convs = [], []
for cid in eval_df[ID_COL]:
    if cid in id_to_msgs:
        convs.append(format_conv(id_to_msgs[cid], CONV_FORMAT))
    else:
        missing.append(cid)
        convs.append(None)

if missing:
    print(f"!!  {len(missing)} id(s) not found in source file:")
    for m in missing:
        print(f"    - {m}")
else:
    print(f"OK  All {len(eval_df)} ids matched.")

# ---------- assemble output ----------
out = eval_df.drop(
    columns=["human_label", "is_correct", "notes"],
    errors="ignore",
).copy()
out["conversation"] = convs
out.to_csv(OUTPUT_CSV, index=False, encoding="utf-8-sig")

print(f"\nSaved: {OUTPUT_CSV}")
print(f"Rows: {len(out)}  |  Columns: {out.columns.tolist()}")