# LLM-Judge Validation Report

**Setup:** 5 LLM judges (`ClaudeOpus, GPT4o, GeminiPro, JaisChat, Qwen72B`) compared against human consensus on 120 conversations.

---

## 1. Headline numbers

- **LLM panel ↔ human consensus on Q9:** Pearson r = **0.964** [95% CI: 0.95, 0.97]
- Spearman ρ = 0.958, Kendall τ = 0.879
- Mean absolute error (Q9): **0.244** points on the 1–5 scale
- **Mean Cohen's κ across binary criteria (Q1–Q8): 0.984**

**Interpretation:**
- ✔ Q9 correlation is **strong** (r ≥ 0.7) — supports use of LLM panel as proxy for human evaluation on overall quality.
- ✔ Mean κ on binary criteria is **substantial** (≥ 0.6) — strong category agreement.

---

## 2. Per-criterion validation

| Criterion | Pearson r | 95% CI | Spearman ρ | Kendall τ | MAE | Cohen's κ | Accuracy |
|---|---|---|---|---|---|---|---|
| Q1_location | — | — | — | — | — | 1.000 | 1.000 |
| Q2_consciousness | — | — | — | — | — | 0.974 | 0.983 |
| Q3_chief_complaint | — | — | — | — | — | 1.000 | 1.000 |
| Q4_question_ordering | — | — | — | — | — | 1.000 | 1.000 |
| Q5_caller_retention | — | — | — | — | — | 0.958 | 0.975 |
| Q6_pre_arrival | — | — | — | — | — | 0.984 | 0.992 |
| Q7_affective | — | — | — | — | — | 0.967 | 0.983 |
| Q8_callback | — | — | — | — | — | 0.986 | 0.992 |
| Q9_overall | 0.964 | [0.95, 0.97] | 0.958 | 0.879 | 0.244 | — | — |

**What to look for:**
- Concrete protocol criteria (Q1 location, Q8 callback) typically show highest agreement
- Subjective criteria (Q7 affective calibration) typically show lowest agreement — same pattern as inter-human agreement
- Wide gap between Pearson r and Spearman ρ on Q9 indicates non-linearity worth investigating

---

## 3. Per-judge correlation (each LLM vs. humans, separately)

| Judge | Q9 Pearson r | 95% CI | Spearman ρ | Kendall τ | Q9 MAE | Mean κ on Q1–Q8 |
|---|---|---|---|---|---|---|
| ClaudeOpus | 0.944 | [0.91, 0.97] | 0.938 | 0.892 | 0.160 | 0.855 |
| GPT4o | 0.855 | [0.80, 0.90] | 0.853 | 0.772 | 0.358 | 0.858 |
| GeminiPro | 0.849 | [0.79, 0.90] | 0.851 | 0.764 | 0.441 | 0.693 |
| JaisChat | 0.803 | [0.74, 0.86] | 0.810 | 0.706 | 0.617 | 0.696 |
| Qwen72B | 0.846 | [0.79, 0.89] | 0.841 | 0.759 | 0.414 | 0.747 |

**Best individual judge:** ClaudeOpus (r = 0.944)
**Weakest individual judge:** JaisChat (r = 0.803)
✔ **Aggregate panel (r = 0.964) outperforms any individual judge** — supports multi-judge protocol.

---

## 4. Inter-judge agreement (do LLMs agree with each other?)

Krippendorff's α across the LLM panel, per criterion:

| Criterion | Level | Inter-judge α | n judges |
|---|---|---|---|
| Q1_location | nominal | 0.737 | 5 |
| Q2_consciousness | nominal | 0.610 | 5 |
| Q3_chief_complaint | nominal | 0.561 | 5 |
| Q4_question_ordering | nominal | 0.604 | 5 |
| Q5_caller_retention | nominal | 0.627 | 5 |
| Q6_pre_arrival | nominal | 0.585 | 5 |
| Q7_affective | nominal | 0.333 | 5 |
| Q8_callback | nominal | 0.713 | 5 |
| Q9_overall | interval | 0.707 | 5 |

**Mean inter-judge α: 0.609**


---

## 5. Per-stratum analysis (anchors vs. unique items)

Tells us whether LLM-human agreement on the multi-rater anchor subset generalizes to the single-rater unique items.

| Stratum | n | Q9 Pearson r | 95% CI | Spearman ρ | Kendall τ | MAE |
|---|---|---|---|---|---|---|
| All 120 | 120 | 0.964 | [0.95, 0.97] | 0.958 | 0.879 | 0.244 |
| Anchors (15, multi-rater) | 15 | 0.932 | [0.77, 0.98] | 0.907 | 0.810 | 0.243 |
| Unique (105, single-rater) | 105 | 0.966 | [0.95, 0.98] | 0.960 | 0.886 | 0.244 |

✔ Anchor r (0.93) ≈ Unique r (0.97) — LLM-human agreement is consistent across both subsets.

---

## 6. Bland–Altman analysis (systematic bias direction)

- **Mean (LLM − human) on Q9:** -0.061
- **95% Limits of Agreement:** [-0.653, +0.531]

✔ No meaningful systematic bias — LLM panel is calibrated to human consensus.

See `bland_altman.png` for the visualization.

---

## 7. Leave-one-out sensitivity

Drop one judge at a time and recompute panel-vs-human r. Tests whether any single judge dominates the panel.

| Left-out judge | Panel r vs. humans | Δ from full panel |
|---|---|---|
| (none / full panel) | 0.964 | +0.000 |
| ClaudeOpus | 0.945 | -0.019 |
| GPT4o | 0.954 | -0.010 |
| GeminiPro | 0.955 | -0.009 |
| JaisChat | 0.963 | -0.001 |
| Qwen72B | 0.963 | -0.001 |

✔ Maximum |Δ| = 0.019 — panel is robust to any single judge being removed.

---

## 8. Paper-ready paragraph

> **LLM-judge validation.** We validate a panel of 5 LLM judges (ClaudeOpus, GPT4o, GeminiPro, JaisChat, Qwen72B) against the 120-item human evaluation set. On the overall quality score, panel mean ratings correlated with human consensus at Pearson r = 0.96 [95% CI: 0.95, 0.97], Spearman ρ = 0.96, and Kendall τ = 0.88. Mean absolute error was 0.24 on the 1–5 scale. Per-criterion Cohen's κ on the binary criteria (Q1–Q8) ranged from 0.96 to 1.00 (mean κ = 0.98). Per-judge correlations with human consensus ranged from 0.80 to 0.94, with the aggregate panel score exceeding any individual judge. Bland–Altman analysis revealed mean difference of -0.06 (LLM − human) with 95% limits of agreement [-0.65, +0.53]. Leave-one-out sensitivity showed panel correlation remained stable (max |Δr| = 0.02) under removal of any single judge.
