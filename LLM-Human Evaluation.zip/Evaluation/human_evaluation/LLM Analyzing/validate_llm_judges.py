"""
LLM-Judge Validation Pipeline
==============================

Compares an LLM judge panel against the human consensus to validate that
the LLM panel can serve as a scalable proxy for human evaluation.

Inputs:
  ./output/human_consensus_120.csv    (from analyze_human_eval.py)
  ./input_llm/judge_<name>.csv        (one CSV per LLM judge)

  Each judge CSV must have columns:
    conversation_id, Q1_location, Q2_consciousness, Q3_chief_complaint,
    Q4_question_ordering, Q5_caller_retention, Q6_pre_arrival,
    Q7_affective, Q8_callback, Q9_overall

  Q1-Q8 values: yes / no / na
  Q9 values: 1-5 integer

Outputs:
  ./output_llm/llm_consensus_120.csv          (panel-aggregated ratings)
  ./output_llm/per_judge_correlation.csv      (each judge vs. human)
  ./output_llm/per_criterion_correlation.csv  (per-criterion validation)
  ./output_llm/per_stratum_correlation.csv    (per-anchor-vs-unique)
  ./output_llm/inter_judge_agreement.csv      (Krippendorff's alpha across judges)
  ./output_llm/sensitivity_loo.csv            (leave-one-out judge analysis)
  ./output_llm/llm_human_agreement_q1q8.csv   (Cohen's kappa per binary criterion)
  ./output_llm/per_judge_correlation.png
  ./output_llm/per_criterion_correlation.png
  ./output_llm/bland_altman.png
  ./output_llm/scatter_human_vs_llm.png
  ./output_llm/LLM_VALIDATION_REPORT.md

Computes:
  1. Per-criterion Pearson r, Spearman rho, Kendall tau (LLM panel vs. humans)
  2. Per-judge correlation against human consensus
  3. Cohen's kappa per binary criterion (LLM panel vs. humans)
  4. Inter-judge Krippendorff's alpha (judges agreeing with each other)
  5. Bland-Altman analysis on Q9 (systematic bias direction)
  6. Per-stratum correlation: anchors (multi-rater) vs. unique (single-rater)
  7. Leave-one-out sensitivity (does any single judge dominate?)
  8. MAE and RMSE on Q9 in original units
"""

import sys
import warnings
from pathlib import Path

import krippendorff
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.metrics import cohen_kappa_score


# ───────────────────────────────────────────────────────────────────────────
# Configuration
# ───────────────────────────────────────────────────────────────────────────

BASE = Path(__file__).parent
HUMAN_CONSENSUS_FILE = BASE / "output" / "human_consensus_120.csv"
LLM_INPUT_DIR = BASE / "input_llm"
OUT = BASE / "output_llm"
OUT.mkdir(exist_ok=True)

CRITERIA_BIN = ["Q1_location", "Q2_consciousness", "Q3_chief_complaint",
                "Q4_question_ordering", "Q5_caller_retention",
                "Q6_pre_arrival", "Q7_affective", "Q8_callback"]
SCORE_CRITERION = "Q9_overall"
ALL_CRITERIA = CRITERIA_BIN + [SCORE_CRITERION]

# Map yes/no/na to ints for nominal-level alpha
CAT_MAP = {"yes": 1, "no": 0, "na": 2}

N_BOOTSTRAP = 1000
RNG = np.random.default_rng(42)


# ───────────────────────────────────────────────────────────────────────────
# Loading & aggregation
# ───────────────────────────────────────────────────────────────────────────

def load_human_consensus():
    df = pd.read_csv(HUMAN_CONSENSUS_FILE)
    print(f"  Human consensus: {len(df)} rows")
    return df


def load_judges():
    """Load all judge_<name>.csv files. Returns dict: judge_name -> DataFrame."""
    files = sorted(LLM_INPUT_DIR.glob("judge_*.csv"))
    if not files:
        raise FileNotFoundError(f"No judge_*.csv files found in {LLM_INPUT_DIR}")
    judges = {}
    for fp in files:
        # judge name = filename stem with "judge_" prefix removed
        name = fp.stem.replace("judge_", "")
        df = pd.read_csv(fp)
        # Lowercase string answers for consistency
        for c in CRITERIA_BIN:
            df[c] = df[c].astype(str).str.lower().str.strip()
        df[SCORE_CRITERION] = pd.to_numeric(df[SCORE_CRITERION], errors="coerce")
        judges[name] = df
        print(f"  judge_{name}: {len(df)} rows")
    return judges


def build_panel_consensus(judges, conversation_order):
    """Aggregate per-judge ratings into a single panel consensus per conversation.
       Q1-Q8: majority vote (tie-break: yes > no > na)
       Q9: mean across judges (rounded to 2 decimals)
    """
    rows = []
    judge_names = list(judges.keys())
    for conv_id in conversation_order:
        row = {"conversation_id": conv_id, "n_judges": len(judges)}
        # Binary criteria
        for crit in CRITERIA_BIN:
            votes = []
            for jn in judge_names:
                jdf = judges[jn]
                hit = jdf[jdf["conversation_id"] == conv_id]
                if len(hit) > 0:
                    votes.append(str(hit.iloc[0][crit]).lower())
            if not votes:
                row[crit] = "na"
                continue
            counts = {v: votes.count(v) for v in ["yes", "no", "na"]}
            max_count = max(counts.values())
            winners = [v for v, c in counts.items() if c == max_count]
            if len(winners) == 1:
                row[crit] = winners[0]
            else:
                row[crit] = "yes" if "yes" in winners else ("no" if "no" in winners else "na")
        # Q9: mean
        q9_vals = []
        for jn in judge_names:
            jdf = judges[jn]
            hit = jdf[jdf["conversation_id"] == conv_id]
            if len(hit) > 0 and not pd.isna(hit.iloc[0][SCORE_CRITERION]):
                q9_vals.append(float(hit.iloc[0][SCORE_CRITERION]))
        row[SCORE_CRITERION] = round(np.mean(q9_vals), 2) if q9_vals else np.nan
        rows.append(row)
    return pd.DataFrame(rows)


# ───────────────────────────────────────────────────────────────────────────
# Correlation metrics
# ───────────────────────────────────────────────────────────────────────────

def pearson_with_ci(x, y, n_boot=N_BOOTSTRAP):
    x, y = np.array(x, dtype=float), np.array(y, dtype=float)
    valid = ~(np.isnan(x) | np.isnan(y))
    x, y = x[valid], y[valid]
    if len(x) < 3 or np.std(x) == 0 or np.std(y) == 0:
        return np.nan, (np.nan, np.nan), np.nan
    r, p = stats.pearsonr(x, y)
    boots = []
    n = len(x)
    for _ in range(n_boot):
        idx = RNG.choice(n, n, replace=True)
        if np.std(x[idx]) == 0 or np.std(y[idx]) == 0:
            continue
        boots.append(stats.pearsonr(x[idx], y[idx])[0])
    if not boots:
        return r, (np.nan, np.nan), p
    ci = tuple(np.percentile(boots, [2.5, 97.5]))
    return r, ci, p


def spearman_kendall(x, y):
    x, y = np.array(x, dtype=float), np.array(y, dtype=float)
    valid = ~(np.isnan(x) | np.isnan(y))
    x, y = x[valid], y[valid]
    if len(x) < 3:
        return np.nan, np.nan
    rho, _ = stats.spearmanr(x, y)
    tau, _ = stats.kendalltau(x, y)
    return rho, tau


def mae_rmse(x, y):
    x, y = np.array(x, dtype=float), np.array(y, dtype=float)
    valid = ~(np.isnan(x) | np.isnan(y))
    x, y = x[valid], y[valid]
    if len(x) < 1:
        return np.nan, np.nan
    mae = float(np.mean(np.abs(x - y)))
    rmse = float(np.sqrt(np.mean((x - y) ** 2)))
    return mae, rmse


def cohen_kappa_for_categorical(human_vals, llm_vals):
    """Cohen's kappa with yes/no/na encoded to ints."""
    h = [CAT_MAP.get(str(v).lower(), -1) for v in human_vals]
    l = [CAT_MAP.get(str(v).lower(), -1) for v in llm_vals]
    h, l = np.array(h), np.array(l)
    valid = (h != -1) & (l != -1)
    h, l = h[valid], l[valid]
    if len(h) < 2 or len(np.unique(h)) < 2 and len(np.unique(l)) < 2:
        return np.nan
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        k = cohen_kappa_score(h, l)
    return float(k) if not np.isnan(k) else np.nan


def accuracy_categorical(human_vals, llm_vals):
    h = [str(v).lower() for v in human_vals]
    l = [str(v).lower() for v in llm_vals]
    if len(h) == 0:
        return np.nan
    matches = sum(1 for a, b in zip(h, l) if a == b)
    return matches / len(h)


# ───────────────────────────────────────────────────────────────────────────
# Tables
# ───────────────────────────────────────────────────────────────────────────

def per_criterion_table(human_df, panel_df):
    """Per-criterion correlation between LLM panel consensus and human consensus."""
    rows = []
    for crit in ALL_CRITERIA:
        h_vals = human_df[crit].values
        l_vals = panel_df[crit].values

        if crit == SCORE_CRITERION:
            r, ci, _ = pearson_with_ci(h_vals, l_vals)
            rho, tau = spearman_kendall(h_vals, l_vals)
            mae, rmse = mae_rmse(h_vals, l_vals)
            rows.append({
                "criterion": crit,
                "metric_type": "interval",
                "pearson_r": round(r, 3) if not np.isnan(r) else np.nan,
                "pearson_ci_low": round(ci[0], 3) if not np.isnan(ci[0]) else np.nan,
                "pearson_ci_high": round(ci[1], 3) if not np.isnan(ci[1]) else np.nan,
                "spearman_rho": round(rho, 3) if not np.isnan(rho) else np.nan,
                "kendall_tau": round(tau, 3) if not np.isnan(tau) else np.nan,
                "MAE": round(mae, 3) if not np.isnan(mae) else np.nan,
                "RMSE": round(rmse, 3) if not np.isnan(rmse) else np.nan,
                "cohen_kappa": np.nan,
                "accuracy": np.nan,
            })
        else:
            k = cohen_kappa_for_categorical(h_vals, l_vals)
            acc = accuracy_categorical(h_vals, l_vals)
            rows.append({
                "criterion": crit,
                "metric_type": "categorical",
                "pearson_r": np.nan, "pearson_ci_low": np.nan, "pearson_ci_high": np.nan,
                "spearman_rho": np.nan, "kendall_tau": np.nan,
                "MAE": np.nan, "RMSE": np.nan,
                "cohen_kappa": round(k, 3) if not np.isnan(k) else np.nan,
                "accuracy": round(acc, 3) if not np.isnan(acc) else np.nan,
            })
    return pd.DataFrame(rows)


def per_judge_table(human_df, judges):
    """Each judge separately vs. human consensus."""
    rows = []
    for jn, jdf in judges.items():
        merged = human_df.merge(jdf, on="conversation_id", suffixes=("_h", "_l"))
        # Q9
        r, ci, _ = pearson_with_ci(merged[f"{SCORE_CRITERION}_h"], merged[f"{SCORE_CRITERION}_l"])
        rho, tau = spearman_kendall(merged[f"{SCORE_CRITERION}_h"], merged[f"{SCORE_CRITERION}_l"])
        mae, rmse = mae_rmse(merged[f"{SCORE_CRITERION}_h"], merged[f"{SCORE_CRITERION}_l"])
        # Mean kappa across binary criteria
        kappas = []
        for crit in CRITERIA_BIN:
            k = cohen_kappa_for_categorical(merged[f"{crit}_h"], merged[f"{crit}_l"])
            if not np.isnan(k):
                kappas.append(k)
        mean_kappa = float(np.mean(kappas)) if kappas else np.nan
        rows.append({
            "judge": jn,
            "Q9_pearson_r": round(r, 3) if not np.isnan(r) else np.nan,
            "Q9_pearson_ci_low": round(ci[0], 3) if not np.isnan(ci[0]) else np.nan,
            "Q9_pearson_ci_high": round(ci[1], 3) if not np.isnan(ci[1]) else np.nan,
            "Q9_spearman_rho": round(rho, 3) if not np.isnan(rho) else np.nan,
            "Q9_kendall_tau": round(tau, 3) if not np.isnan(tau) else np.nan,
            "Q9_MAE": round(mae, 3) if not np.isnan(mae) else np.nan,
            "Q9_RMSE": round(rmse, 3) if not np.isnan(rmse) else np.nan,
            "mean_kappa_Q1Q8": round(mean_kappa, 3) if not np.isnan(mean_kappa) else np.nan,
        })
    return pd.DataFrame(rows)


def inter_judge_agreement(judges, conversation_order):
    """Krippendorff's alpha across judges (do they agree with each other)."""
    rows = []
    judge_names = list(judges.keys())
    for crit in ALL_CRITERIA:
        # Build (n_judges x n_items) matrix
        mat = np.full((len(judge_names), len(conversation_order)), np.nan)
        for j_idx, jn in enumerate(judge_names):
            jdf = judges[jn].set_index("conversation_id")
            for c_idx, conv in enumerate(conversation_order):
                if conv in jdf.index:
                    val = jdf.loc[conv, crit]
                    if crit == SCORE_CRITERION:
                        mat[j_idx, c_idx] = float(val) if not pd.isna(val) else np.nan
                    else:
                        mat[j_idx, c_idx] = CAT_MAP.get(str(val).lower(), np.nan)
        # Compute alpha
        flat = mat[~np.isnan(mat)]
        if len(np.unique(flat)) < 2:
            alpha = np.nan
        else:
            level = "interval" if crit == SCORE_CRITERION else "nominal"
            try:
                alpha = krippendorff.alpha(reliability_data=mat, level_of_measurement=level)
            except Exception:
                alpha = np.nan
        rows.append({
            "criterion": crit,
            "level": "interval" if crit == SCORE_CRITERION else "nominal",
            "inter_judge_alpha": round(alpha, 3) if not np.isnan(alpha) else np.nan,
            "n_judges": len(judge_names),
        })
    return pd.DataFrame(rows)


def per_stratum_table(human_df, panel_df):
    """Anchors (multi-rater humans) vs. Unique items (single-rater humans).
    Tells us if LLM-human correlation generalizes from the multi-rater anchors
    to the single-rater unique items."""
    # panel_df already has its own is_anchor column from the previous merge,
    # which would clash. Drop it before merging.
    panel_for_merge = panel_df.drop(columns=["is_anchor"], errors="ignore")
    merged = human_df.merge(panel_for_merge, on="conversation_id", suffixes=("_h", "_l"))
    rows = []
    for stratum_name, mask in [
        ("All 120", np.ones(len(merged), dtype=bool)),
        ("Anchors (15, multi-rater)", merged["is_anchor"] == True),
        ("Unique (105, single-rater)", merged["is_anchor"] == False),
    ]:
        sub = merged[mask]
        if len(sub) < 3:
            continue
        r, ci, _ = pearson_with_ci(sub[f"{SCORE_CRITERION}_h"], sub[f"{SCORE_CRITERION}_l"])
        rho, tau = spearman_kendall(sub[f"{SCORE_CRITERION}_h"], sub[f"{SCORE_CRITERION}_l"])
        mae, rmse = mae_rmse(sub[f"{SCORE_CRITERION}_h"], sub[f"{SCORE_CRITERION}_l"])
        rows.append({
            "stratum": stratum_name,
            "n": len(sub),
            "Q9_pearson_r": round(r, 3) if not np.isnan(r) else np.nan,
            "Q9_ci_low": round(ci[0], 3) if not np.isnan(ci[0]) else np.nan,
            "Q9_ci_high": round(ci[1], 3) if not np.isnan(ci[1]) else np.nan,
            "Q9_spearman_rho": round(rho, 3) if not np.isnan(rho) else np.nan,
            "Q9_kendall_tau": round(tau, 3) if not np.isnan(tau) else np.nan,
            "Q9_MAE": round(mae, 3) if not np.isnan(mae) else np.nan,
        })
    return pd.DataFrame(rows)


def loo_sensitivity(human_df, judges, conversation_order):
    """Drop one judge at a time and recompute panel correlation. Tests robustness."""
    rows = []
    judge_names = list(judges.keys())
    # Full panel baseline
    full_panel = build_panel_consensus(judges, conversation_order)
    merged = human_df.merge(full_panel, on="conversation_id", suffixes=("_h", "_l"))
    full_r, _, _ = pearson_with_ci(merged[f"{SCORE_CRITERION}_h"], merged[f"{SCORE_CRITERION}_l"], n_boot=200)
    rows.append({"left_out_judge": "(none / full panel)", "Q9_pearson_r": round(full_r, 3),
                 "delta_from_full": 0.0})
    # LOO
    for skip in judge_names:
        sub_judges = {k: v for k, v in judges.items() if k != skip}
        sub_panel = build_panel_consensus(sub_judges, conversation_order)
        merged = human_df.merge(sub_panel, on="conversation_id", suffixes=("_h", "_l"))
        r, _, _ = pearson_with_ci(merged[f"{SCORE_CRITERION}_h"], merged[f"{SCORE_CRITERION}_l"], n_boot=200)
        rows.append({"left_out_judge": skip, "Q9_pearson_r": round(r, 3),
                     "delta_from_full": round(r - full_r, 3)})
    return pd.DataFrame(rows)


# ───────────────────────────────────────────────────────────────────────────
# Plots
# ───────────────────────────────────────────────────────────────────────────

def plot_per_judge_correlation(per_judge_df, out_path):
    """Bar chart: each judge's Pearson r against humans on Q9."""
    fig, ax = plt.subplots(figsize=(8, 5))
    df = per_judge_df.sort_values("Q9_pearson_r", ascending=True).reset_index(drop=True)
    y = np.arange(len(df))
    rs = df["Q9_pearson_r"].values
    err_low = rs - df["Q9_pearson_ci_low"].values
    err_high = df["Q9_pearson_ci_high"].values - rs

    colors = ["#2d6a4f" if r >= 0.7 else ("#d4a017" if r >= 0.5 else "#b03030") for r in rs]
    ax.barh(y, rs, xerr=[err_low, err_high], color=colors, edgecolor="#1a1a1a",
            linewidth=0.8, capsize=4, error_kw={"linewidth": 1.0})
    ax.set_yticks(y)
    ax.set_yticklabels(df["judge"], fontsize=10)
    ax.set_xlabel("Pearson r vs. human consensus (Q9, 1–5 scale)", fontsize=11)
    ax.set_title("Per-judge correlation with human consensus", fontsize=12, pad=12)
    ax.axvline(0.7, color="#2d6a4f", linestyle="--", alpha=0.5, label="Strong validation (r ≥ 0.7)")
    ax.axvline(0.5, color="#b03030", linestyle="--", alpha=0.5, label="Minimum acceptable (r ≥ 0.5)")
    ax.set_xlim(0, 1.0)
    ax.legend(fontsize=9, loc="lower right")
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="x", linestyle=":", alpha=0.4)
    plt.tight_layout()
    plt.savefig(out_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  ✔ Saved {out_path.name}")


def plot_per_criterion_correlation(per_crit_df, out_path):
    """Bar chart: per-criterion Pearson r (Q9) and Cohen's kappa (Q1-Q8)."""
    fig, ax = plt.subplots(figsize=(9, 5.5))
    rows = []
    for _, r in per_crit_df.iterrows():
        if r["criterion"] == SCORE_CRITERION:
            rows.append((r["criterion"], r["pearson_r"], "Pearson r"))
        else:
            rows.append((r["criterion"], r["cohen_kappa"], "Cohen's κ"))
    df = pd.DataFrame(rows, columns=["criterion", "value", "metric"]).sort_values("value", ascending=True).reset_index(drop=True)
    y = np.arange(len(df))
    vals = df["value"].fillna(0).values
    colors = ["#2d6a4f" if v >= 0.7 else ("#d4a017" if v >= 0.5 else "#b03030") for v in vals]

    ax.barh(y, vals, color=colors, edgecolor="#1a1a1a", linewidth=0.8)
    for i, (v, m) in enumerate(zip(vals, df["metric"])):
        ax.text(v + 0.02 if v >= 0 else v - 0.02, i, f"{v:.2f} ({m})",
                va="center", fontsize=9, color="#1a1a1a")
    ax.set_yticks(y)
    ax.set_yticklabels([c.replace("_", " ").title() for c in df["criterion"]], fontsize=10)
    ax.set_xlabel("LLM panel vs. human consensus (Pearson r for Q9, Cohen's κ for Q1–Q8)", fontsize=10)
    ax.set_title("Per-criterion LLM–human agreement", fontsize=12, pad=12)
    ax.axvline(0.7, color="#2d6a4f", linestyle="--", alpha=0.5, label="Strong (≥ 0.7)")
    ax.axvline(0.5, color="#d4a017", linestyle="--", alpha=0.5, label="Acceptable (≥ 0.5)")
    ax.set_xlim(min(0, vals.min() - 0.05), 1.05)
    ax.legend(fontsize=9, loc="lower right")
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="x", linestyle=":", alpha=0.4)
    plt.tight_layout()
    plt.savefig(out_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  ✔ Saved {out_path.name}")


def plot_bland_altman(human_df, panel_df, out_path):
    """Bland-Altman: difference vs. mean. Reveals systematic bias direction."""
    panel_for_merge = panel_df.drop(columns=["is_anchor"], errors="ignore")
    merged = human_df.merge(panel_for_merge, on="conversation_id", suffixes=("_h", "_l"))
    h_q9 = pd.to_numeric(merged[f"{SCORE_CRITERION}_h"], errors="coerce").values
    l_q9 = pd.to_numeric(merged[f"{SCORE_CRITERION}_l"], errors="coerce").values
    valid = ~(np.isnan(h_q9) | np.isnan(l_q9))
    h_q9, l_q9 = h_q9[valid], l_q9[valid]
    is_anchor = merged.loc[valid, "is_anchor"].values
    diff = l_q9 - h_q9          # LLM minus human
    mean = (l_q9 + h_q9) / 2.0

    mean_diff = np.mean(diff)
    sd_diff = np.std(diff, ddof=1)
    upper = mean_diff + 1.96 * sd_diff
    lower = mean_diff - 1.96 * sd_diff

    fig, ax = plt.subplots(figsize=(9, 5.5))
    ax.scatter(mean[is_anchor], diff[is_anchor], s=60, c="#8b1e1e", alpha=0.8,
               edgecolor="#1a1a1a", linewidth=0.5, label="Anchor (multi-rater)")
    ax.scatter(mean[~is_anchor], diff[~is_anchor], s=30, c="#1a1a1a", alpha=0.5,
               edgecolor="none", label="Unique (single-rater)")
    ax.axhline(mean_diff, color="#2d6a4f", linestyle="-", linewidth=1.5,
               label=f"Mean diff = {mean_diff:+.2f}")
    ax.axhline(upper, color="#d4a017", linestyle="--", linewidth=1.0,
               label=f"95% LoA = [{lower:+.2f}, {upper:+.2f}]")
    ax.axhline(lower, color="#d4a017", linestyle="--", linewidth=1.0)
    ax.axhline(0, color="#999", linestyle=":", linewidth=0.8)
    ax.set_xlabel("Mean of LLM and human Q9 scores", fontsize=11)
    ax.set_ylabel("LLM − human (Q9 difference)", fontsize=11)
    ax.set_title("Bland–Altman analysis: LLM panel vs. human consensus on Q9", fontsize=12, pad=12)
    ax.legend(fontsize=9, loc="best")
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(linestyle=":", alpha=0.4)
    plt.tight_layout()
    plt.savefig(out_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  ✔ Saved {out_path.name}")
    return mean_diff, lower, upper


def plot_scatter(human_df, panel_df, out_path):
    """Scatter plot: human Q9 vs. LLM panel Q9 with diagonal."""
    panel_for_merge = panel_df.drop(columns=["is_anchor"], errors="ignore")
    merged = human_df.merge(panel_for_merge, on="conversation_id", suffixes=("_h", "_l"))
    h_q9 = pd.to_numeric(merged[f"{SCORE_CRITERION}_h"], errors="coerce").values
    l_q9 = pd.to_numeric(merged[f"{SCORE_CRITERION}_l"], errors="coerce").values
    valid = ~(np.isnan(h_q9) | np.isnan(l_q9))
    h_q9, l_q9 = h_q9[valid], l_q9[valid]
    is_anchor = merged.loc[valid, "is_anchor"].values

    # Add small jitter so overlapping points are visible
    jitter_x = h_q9 + RNG.uniform(-0.08, 0.08, size=len(h_q9))
    jitter_y = l_q9 + RNG.uniform(-0.08, 0.08, size=len(l_q9))

    r, _, _ = pearson_with_ci(h_q9, l_q9, n_boot=200)

    fig, ax = plt.subplots(figsize=(7, 6))
    ax.plot([1, 5], [1, 5], color="#999", linestyle="--", linewidth=0.8, label="y = x (perfect agreement)")
    ax.scatter(jitter_x[~is_anchor], jitter_y[~is_anchor], s=30, c="#1a1a1a", alpha=0.5,
               edgecolor="none", label="Unique (single-rater)")
    ax.scatter(jitter_x[is_anchor], jitter_y[is_anchor], s=70, c="#8b1e1e", alpha=0.8,
               edgecolor="#1a1a1a", linewidth=0.5, label="Anchor (multi-rater)")
    ax.set_xlabel("Human consensus Q9", fontsize=11)
    ax.set_ylabel("LLM panel consensus Q9", fontsize=11)
    ax.set_title(f"Human vs. LLM panel on Q9 (Pearson r = {r:.2f})", fontsize=12, pad=12)
    ax.set_xlim(0.5, 5.5)
    ax.set_ylim(0.5, 5.5)
    ax.set_xticks([1, 2, 3, 4, 5])
    ax.set_yticks([1, 2, 3, 4, 5])
    ax.legend(fontsize=9, loc="lower right")
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(linestyle=":", alpha=0.4)
    plt.tight_layout()
    plt.savefig(out_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  ✔ Saved {out_path.name}")


# ───────────────────────────────────────────────────────────────────────────
# Report
# ───────────────────────────────────────────────────────────────────────────

def write_report(out_path, n_judges, judge_names, per_crit, per_judge,
                 inter_judge, per_stratum, loo_df, ba_stats):
    lines = []
    lines.append("# LLM-Judge Validation Report")
    lines.append("")
    lines.append(f"**Setup:** {n_judges} LLM judges (`{', '.join(judge_names)}`) compared against human consensus on 120 conversations.")
    lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("## 1. Headline numbers")
    lines.append("")
    q9_row = per_crit[per_crit["criterion"] == SCORE_CRITERION].iloc[0]
    q9_r = q9_row["pearson_r"]
    q9_ci_low = q9_row["pearson_ci_low"]
    q9_ci_high = q9_row["pearson_ci_high"]
    q9_rho = q9_row["spearman_rho"]
    q9_tau = q9_row["kendall_tau"]
    q9_mae = q9_row["MAE"]
    bin_kappas = per_crit[per_crit["criterion"] != SCORE_CRITERION]["cohen_kappa"]
    mean_kappa = bin_kappas.mean()

    lines.append(f"- **LLM panel ↔ human consensus on Q9:** Pearson r = **{q9_r:.3f}** [95% CI: {q9_ci_low:.2f}, {q9_ci_high:.2f}]")
    lines.append(f"- Spearman ρ = {q9_rho:.3f}, Kendall τ = {q9_tau:.3f}")
    lines.append(f"- Mean absolute error (Q9): **{q9_mae:.3f}** points on the 1–5 scale")
    lines.append(f"- **Mean Cohen's κ across binary criteria (Q1–Q8): {mean_kappa:.3f}**")
    lines.append("")
    lines.append("**Interpretation:**")
    if q9_r >= 0.7:
        lines.append("- ✔ Q9 correlation is **strong** (r ≥ 0.7) — supports use of LLM panel as proxy for human evaluation on overall quality.")
    elif q9_r >= 0.5:
        lines.append("- ⚠ Q9 correlation is **acceptable** (0.5 ≤ r < 0.7) — usable as proxy with caveats; report transparently.")
    else:
        lines.append("- ✗ Q9 correlation is **weak** (r < 0.5) — LLM panel does not reliably approximate human judgment on overall quality. Investigate prompt design or judge selection.")
    if mean_kappa >= 0.6:
        lines.append("- ✔ Mean κ on binary criteria is **substantial** (≥ 0.6) — strong category agreement.")
    elif mean_kappa >= 0.4:
        lines.append("- ⚠ Mean κ is **moderate** (0.4 ≤ κ < 0.6) — usable but report per-criterion variation.")
    else:
        lines.append("- ✗ Mean κ is **low** (< 0.4) — substantial category-level disagreement; reconsider judge prompts.")
    lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("## 2. Per-criterion validation")
    lines.append("")
    lines.append("| Criterion | Pearson r | 95% CI | Spearman ρ | Kendall τ | MAE | Cohen's κ | Accuracy |")
    lines.append("|---|---|---|---|---|---|---|---|")
    for _, r in per_crit.iterrows():
        ci = f"[{r['pearson_ci_low']:.2f}, {r['pearson_ci_high']:.2f}]" if not pd.isna(r['pearson_ci_low']) else "—"
        lines.append(f"| {r['criterion']} | {r['pearson_r']:.3f} | {ci} | {r['spearman_rho']:.3f} | {r['kendall_tau']:.3f} | {r['MAE']:.3f} | {r['cohen_kappa']:.3f} | {r['accuracy']:.3f} |".replace("nan", "—"))
    lines.append("")
    lines.append("**What to look for:**")
    lines.append("- Concrete protocol criteria (Q1 location, Q8 callback) typically show highest agreement")
    lines.append("- Subjective criteria (Q7 affective calibration) typically show lowest agreement — same pattern as inter-human agreement")
    lines.append("- Wide gap between Pearson r and Spearman ρ on Q9 indicates non-linearity worth investigating")
    lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("## 3. Per-judge correlation (each LLM vs. humans, separately)")
    lines.append("")
    lines.append("| Judge | Q9 Pearson r | 95% CI | Spearman ρ | Kendall τ | Q9 MAE | Mean κ on Q1–Q8 |")
    lines.append("|---|---|---|---|---|---|---|")
    for _, r in per_judge.iterrows():
        ci = f"[{r['Q9_pearson_ci_low']:.2f}, {r['Q9_pearson_ci_high']:.2f}]" if not pd.isna(r['Q9_pearson_ci_low']) else "—"
        lines.append(f"| {r['judge']} | {r['Q9_pearson_r']:.3f} | {ci} | {r['Q9_spearman_rho']:.3f} | {r['Q9_kendall_tau']:.3f} | {r['Q9_MAE']:.3f} | {r['mean_kappa_Q1Q8']:.3f} |".replace("nan", "—"))
    lines.append("")
    best_judge = per_judge.iloc[per_judge["Q9_pearson_r"].idxmax()]
    worst_judge = per_judge.iloc[per_judge["Q9_pearson_r"].idxmin()]
    lines.append(f"**Best individual judge:** {best_judge['judge']} (r = {best_judge['Q9_pearson_r']:.3f})")
    lines.append(f"**Weakest individual judge:** {worst_judge['judge']} (r = {worst_judge['Q9_pearson_r']:.3f})")
    if q9_r > best_judge["Q9_pearson_r"]:
        lines.append(f"✔ **Aggregate panel (r = {q9_r:.3f}) outperforms any individual judge** — supports multi-judge protocol.")
    else:
        lines.append(f"⚠ Best single judge ({best_judge['judge']}) outperforms aggregate. Consider weighted aggregation.")
    lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("## 4. Inter-judge agreement (do LLMs agree with each other?)")
    lines.append("")
    lines.append("Krippendorff's α across the LLM panel, per criterion:")
    lines.append("")
    lines.append("| Criterion | Level | Inter-judge α | n judges |")
    lines.append("|---|---|---|---|")
    for _, r in inter_judge.iterrows():
        a = f"{r['inter_judge_alpha']:.3f}" if not pd.isna(r['inter_judge_alpha']) else "—"
        lines.append(f"| {r['criterion']} | {r['level']} | {a} | {r['n_judges']} |")
    lines.append("")
    mean_inter = inter_judge["inter_judge_alpha"].mean()
    lines.append(f"**Mean inter-judge α: {mean_inter:.3f}**")
    lines.append("")
    if mean_inter >= 0.7 and q9_r >= 0.7:
        lines.append("✔ Both inter-judge and LLM-human agreement are strong — robust validation.")
    elif mean_inter >= 0.7 and q9_r < 0.7:
        lines.append("⚠ Judges agree with each other but disagree with humans — possible shared LLM bias. Investigate.")
    elif mean_inter < 0.5:
        lines.append("⚠ Judges disagree with each other substantially — panel aggregation may be averaging noise. Consider revising judge prompt.")
    lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("## 5. Per-stratum analysis (anchors vs. unique items)")
    lines.append("")
    lines.append("Tells us whether LLM-human agreement on the multi-rater anchor subset generalizes to the single-rater unique items.")
    lines.append("")
    lines.append("| Stratum | n | Q9 Pearson r | 95% CI | Spearman ρ | Kendall τ | MAE |")
    lines.append("|---|---|---|---|---|---|---|")
    for _, r in per_stratum.iterrows():
        ci = f"[{r['Q9_ci_low']:.2f}, {r['Q9_ci_high']:.2f}]" if not pd.isna(r['Q9_ci_low']) else "—"
        lines.append(f"| {r['stratum']} | {r['n']} | {r['Q9_pearson_r']:.3f} | {ci} | {r['Q9_spearman_rho']:.3f} | {r['Q9_kendall_tau']:.3f} | {r['Q9_MAE']:.3f} |".replace("nan", "—"))
    lines.append("")
    if len(per_stratum) >= 3:
        anchor_r = per_stratum.iloc[1]["Q9_pearson_r"]
        unique_r = per_stratum.iloc[2]["Q9_pearson_r"]
        if not pd.isna(anchor_r) and not pd.isna(unique_r):
            gap = abs(anchor_r - unique_r)
            if gap < 0.1:
                lines.append(f"✔ Anchor r ({anchor_r:.2f}) ≈ Unique r ({unique_r:.2f}) — LLM-human agreement is consistent across both subsets.")
            else:
                lines.append(f"⚠ Anchor r ({anchor_r:.2f}) differs from Unique r ({unique_r:.2f}) by {gap:.2f} — investigate why.")
    lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("## 6. Bland–Altman analysis (systematic bias direction)")
    lines.append("")
    md, lo, hi = ba_stats
    lines.append(f"- **Mean (LLM − human) on Q9:** {md:+.3f}")
    lines.append(f"- **95% Limits of Agreement:** [{lo:+.3f}, {hi:+.3f}]")
    lines.append("")
    if abs(md) < 0.15:
        lines.append("✔ No meaningful systematic bias — LLM panel is calibrated to human consensus.")
    elif md > 0:
        lines.append(f"⚠ LLM panel is systematically more lenient than humans by {md:+.2f} Q9 points on average.")
    else:
        lines.append(f"⚠ LLM panel is systematically harsher than humans by {md:+.2f} Q9 points on average.")
    lines.append("")
    lines.append("See `bland_altman.png` for the visualization.")
    lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("## 7. Leave-one-out sensitivity")
    lines.append("")
    lines.append("Drop one judge at a time and recompute panel-vs-human r. Tests whether any single judge dominates the panel.")
    lines.append("")
    lines.append("| Left-out judge | Panel r vs. humans | Δ from full panel |")
    lines.append("|---|---|---|")
    for _, r in loo_df.iterrows():
        delta_str = f"{r['delta_from_full']:+.3f}"
        lines.append(f"| {r['left_out_judge']} | {r['Q9_pearson_r']:.3f} | {delta_str} |")
    lines.append("")
    max_abs_delta = loo_df["delta_from_full"].abs().max()
    if max_abs_delta < 0.05:
        lines.append(f"✔ Maximum |Δ| = {max_abs_delta:.3f} — panel is robust to any single judge being removed.")
    elif max_abs_delta < 0.10:
        lines.append(f"⚠ Maximum |Δ| = {max_abs_delta:.3f} — moderate sensitivity. Note which judge most influences results.")
    else:
        lines.append(f"✗ Maximum |Δ| = {max_abs_delta:.3f} — single judge significantly influences panel verdict. Reconsider panel.")
    lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("## 8. Paper-ready paragraph")
    lines.append("")
    lines.append("> **LLM-judge validation.** We validate a panel of "
                 f"{n_judges} LLM judges ({', '.join(judge_names)}) against the 120-item human evaluation set. "
                 f"On the overall quality score, panel mean ratings correlated with human consensus at "
                 f"Pearson r = {q9_r:.2f} [95% CI: {q9_ci_low:.2f}, {q9_ci_high:.2f}], "
                 f"Spearman ρ = {q9_rho:.2f}, and Kendall τ = {q9_tau:.2f}. "
                 f"Mean absolute error was {q9_mae:.2f} on the 1–5 scale. "
                 f"Per-criterion Cohen's κ on the binary criteria (Q1–Q8) ranged from "
                 f"{bin_kappas.min():.2f} to {bin_kappas.max():.2f} (mean κ = {mean_kappa:.2f}). "
                 f"Per-judge correlations with human consensus ranged from "
                 f"{per_judge['Q9_pearson_r'].min():.2f} to {per_judge['Q9_pearson_r'].max():.2f}, "
                 f"with the aggregate panel score "
                 f"{'exceeding' if q9_r > per_judge['Q9_pearson_r'].max() else 'comparable to'} "
                 f"any individual judge. "
                 f"Bland–Altman analysis revealed mean difference of {md:+.2f} (LLM − human) with 95% limits "
                 f"of agreement [{lo:+.2f}, {hi:+.2f}]. "
                 f"Leave-one-out sensitivity showed panel correlation remained stable "
                 f"(max |Δr| = {max_abs_delta:.2f}) under removal of any single judge.")
    lines.append("")
    out_path.write_text("\n".join(lines), encoding="utf-8")
    print(f"  ✔ Saved {out_path.name}")


# ───────────────────────────────────────────────────────────────────────────
# Main
# ───────────────────────────────────────────────────────────────────────────

def main():
    print("=" * 70)
    print("LLM-Judge Validation Pipeline")
    print("=" * 70)

    print("\n[1/8] Loading data...")
    if not HUMAN_CONSENSUS_FILE.exists():
        print(f"  ✗ Cannot find {HUMAN_CONSENSUS_FILE}. Run analyze_human_eval.py first.")
        sys.exit(1)
    human_df = load_human_consensus()
    judges = load_judges()
    n_judges = len(judges)
    judge_names = list(judges.keys())

    print("\n[2/8] Building panel consensus...")
    conv_order = human_df["conversation_id"].tolist()
    panel_df = build_panel_consensus(judges, conv_order)
    panel_df = panel_df.merge(human_df[["conversation_id", "is_anchor"]], on="conversation_id", how="left")
    panel_df.to_csv(OUT / "llm_consensus_120.csv", index=False)
    print(f"  ✔ Saved llm_consensus_120.csv ({len(panel_df)} rows)")

    print("\n[3/8] Per-criterion correlation (LLM panel vs. humans)...")
    per_crit = per_criterion_table(human_df, panel_df)
    per_crit.to_csv(OUT / "per_criterion_correlation.csv", index=False)
    print(f"  ✔ Saved per_criterion_correlation.csv")

    print("\n[4/8] Per-judge correlation (each LLM vs. humans)...")
    per_judge = per_judge_table(human_df, judges)
    per_judge.to_csv(OUT / "per_judge_correlation.csv", index=False)
    print(f"  ✔ Saved per_judge_correlation.csv")

    print("\n[5/8] Inter-judge agreement (Krippendorff's α across LLMs)...")
    inter_judge = inter_judge_agreement(judges, conv_order)
    inter_judge.to_csv(OUT / "inter_judge_agreement.csv", index=False)
    print(f"  ✔ Saved inter_judge_agreement.csv")

    print("\n[6/8] Per-stratum analysis (anchors vs. unique)...")
    per_stratum = per_stratum_table(human_df, panel_df)
    per_stratum.to_csv(OUT / "per_stratum_correlation.csv", index=False)
    print(f"  ✔ Saved per_stratum_correlation.csv")

    print("\n[7/8] Leave-one-out sensitivity analysis...")
    loo = loo_sensitivity(human_df, judges, conv_order)
    loo.to_csv(OUT / "sensitivity_loo.csv", index=False)
    print(f"  ✔ Saved sensitivity_loo.csv")

    print("\n[8/8] Building plots and report...")
    plot_per_judge_correlation(per_judge, OUT / "per_judge_correlation.png")
    plot_per_criterion_correlation(per_crit, OUT / "per_criterion_correlation.png")
    ba_stats = plot_bland_altman(human_df, panel_df, OUT / "bland_altman.png")
    plot_scatter(human_df, panel_df, OUT / "scatter_human_vs_llm.png")
    write_report(OUT / "LLM_VALIDATION_REPORT.md", n_judges, judge_names,
                 per_crit, per_judge, inter_judge, per_stratum, loo, ba_stats)

    print("\n" + "=" * 70)
    print("Validation complete. Outputs in:", OUT)
    print("=" * 70)


if __name__ == "__main__":
    main()
