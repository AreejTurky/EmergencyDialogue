"""
Judge 3: ALLaM-7B-Instruct (SDAIA / IBM)
=========================================

Saudi-developed Arabic-first model. Smallest of the 5 judges (~14GB bf16),
runs comfortably on a single V100 or A100.

Default: ALLaM-AI/ALLaM-7B-Instruct-preview

Dtype:
  Set JUDGE_DTYPE=float16 on V100/T4. Default bfloat16 for Ampere+.

Output: judge_outputs/judge_ALLaM.csv
"""
import os
from judge_common import TransformersJudge, run_judge

JUDGE_NAME = "ALLaM"
MODEL_ID = os.getenv("ALLAM_MODEL", "ALLaM-AI/ALLaM-7B-Instruct-preview")


def main():
    with TransformersJudge(MODEL_ID) as judge:
        run_judge(JUDGE_NAME, judge.call)


if __name__ == "__main__":
    main()
