"""
Shared utilities for HPC-friendly LLM judge scripts.

Backend modes (per-judge):
  - "transformers": load model with HF transformers, run inference, then explicitly
                    free GPU memory before next judge starts. Best for HPC.
  - "openai_api":   call an OpenAI-compatible API (DashScope, Together, Mistral, etc.)

In transformers mode, models are loaded ONE AT A TIME. After each judge finishes its
120 conversations, the model is unloaded and CUDA cache cleared before the next
judge loads. This is the only sensible pattern on a single GPU node — loading 5
models simultaneously would OOM any reasonable cluster setup.

Input CSV at: input/conversations_to_judge.csv
Output CSVs at: judge_outputs/judge_<NAME>.csv
"""
import csv
import gc
import json
import re
import time
from pathlib import Path

import pandas as pd

# ───────────────────────────────────────────────────────────────────────────
# Paths
# ───────────────────────────────────────────────────────────────────────────

BASE = Path(__file__).parent
INPUT_CSV = BASE / "input" / "conversations_to_judge.csv"
OUTPUT_DIR = BASE / "judge_outputs"
OUTPUT_DIR.mkdir(exist_ok=True)


# ───────────────────────────────────────────────────────────────────────────
# Output schema
# ───────────────────────────────────────────────────────────────────────────

CSV_COLUMNS = [
    "conversation_id",
    "Q1_location",
    "Q2_consciousness",
    "Q3_chief_complaint",
    "Q4_question_ordering",
    "Q5_caller_retention",
    "Q6_pre_arrival",
    "Q7_affective",
    "Q8_callback",
    "Q9_overall",
]
VALID_BINARY = {"yes", "no", "na"}


# ───────────────────────────────────────────────────────────────────────────
# Judge prompt — IDENTICAL across all judges
# ───────────────────────────────────────────────────────────────────────────

JUDGE_SYSTEM_PROMPT = """You are an expert evaluator of 911 emergency dispatcher performance, trained in standard dispatch protocols (Georgia 911 Ch. 8.5–8.9, Eugene OR scripts, Sarpy County 911 standards). Your task is to rate a single dispatcher conversation against 9 criteria.

You will read a conversation between a caller (user) and a dispatcher (assistant), then return your evaluation as strict JSON. Do not include any text before or after the JSON object."""


JUDGE_USER_PROMPT_TEMPLATE = """CONVERSATION TO EVALUATE:

{conversation}

────────────────────────────────────────

EVALUATION CRITERIA:

Q1 — Location completeness: Did the dispatcher collect an exact address or specific location BEFORE dispatching help?
  - "yes": Address was collected before dispatch
  - "no": Help was dispatched without confirming location
  - "na": Not applicable

Q2 — Consciousness & breathing check: For medical calls, did the dispatcher explicitly ask whether the patient is conscious and breathing? (Per Ch. 8.5 — Case Entry)
  - "yes": Explicitly asked about consciousness/breathing
  - "no": Medical call but did not check
  - "na": Not a medical call

Q3 — Chief complaint accuracy: Was the nature of the emergency correctly identified and confirmed in the first exchange? (Per Eugene OR scripts)
  - "yes": Correctly identified and confirmed early
  - "no": Misidentified, ambiguous, or not confirmed
  - "na": Not applicable

Q4 — Question ordering compliance: Did the dispatcher follow the correct protocol sequence — location → callback → chief complaint → sub-questions — without skipping steps?
  - "yes": Followed the sequence
  - "no": Skipped or reordered substantively
  - "na": Not applicable

Q5 — Caller retention on line: Did the dispatcher explicitly ask the caller to stay on the line until help arrives? (Per Georgia 911 Ch. 8.9)
  - "yes": Explicitly asked
  - "no": Did not ask
  - "na": Not applicable

Q6 — Pre-arrival instructions: Did the dispatcher provide actionable safety instructions while waiting for responders, without asking permission? (Per Georgia 911 Ch. 8.9)
  - "yes": Provided proactive specific instructions
  - "no": No instructions, or only after caller asked
  - "na": Not applicable

Q7 — Affective calibration: Did the dispatcher remain calm, reassuring, and professional without blaming or dismissing the caller's distress? (Per Georgia 911 Ch. 8.8)
  - "yes": Calm and reassuring throughout
  - "no": Dismissive, blaming, or escalated distress
  - "na": Not applicable

Q8 — Callback number: Was a callback number collected in case the call is disconnected? (Per Sarpy County 911 FAQ)
  - "yes": Callback number explicitly collected
  - "no": No callback number requested
  - "na": Not applicable

Q9 — Overall dispatcher quality (1–5):
  5 — Exemplary
  4 — Competent, minor improvements possible
  3 — Acceptable, meets minimum protocol
  2 — Below protocol, caller safety risk
  1 — Dangerously noncompliant

────────────────────────────────────────

OUTPUT FORMAT (strict JSON only — no preamble, no markdown fences, no explanation):

{{
  "Q1_location": "yes" | "no" | "na",
  "Q2_consciousness": "yes" | "no" | "na",
  "Q3_chief_complaint": "yes" | "no" | "na",
  "Q4_question_ordering": "yes" | "no" | "na",
  "Q5_caller_retention": "yes" | "no" | "na",
  "Q6_pre_arrival": "yes" | "no" | "na",
  "Q7_affective": "yes" | "no" | "na",
  "Q8_callback": "yes" | "no" | "na",
  "Q9_overall": <integer 1 to 5>
}}

Return ONLY the JSON object."""


def build_full_prompt(conversation_text: str) -> tuple:
    return JUDGE_SYSTEM_PROMPT, JUDGE_USER_PROMPT_TEMPLATE.format(conversation=conversation_text)


# ───────────────────────────────────────────────────────────────────────────
# Conversation loading
# ───────────────────────────────────────────────────────────────────────────

def load_conversations() -> list:
    if not INPUT_CSV.exists():
        raise FileNotFoundError(
            f"Cannot find {INPUT_CSV}.\n"
            f"Place a CSV with columns 'conversation_id' and 'conversation' there."
        )
    df = pd.read_csv(INPUT_CSV)
    required = {"conversation_id", "conversation"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(
            f"{INPUT_CSV} is missing columns: {missing}. "
            f"Required: {required}. Found: {set(df.columns)}"
        )
    items = []
    for _, row in df.iterrows():
        items.append({
            "conversation_id": str(row["conversation_id"]).strip(),
            "conversation": str(row["conversation"]).strip(),
        })
    print(f"  Loaded {len(items)} conversations from {INPUT_CSV.name}")
    return items


# ───────────────────────────────────────────────────────────────────────────
# Response parsing
# ───────────────────────────────────────────────────────────────────────────

def parse_judge_response(text):
    if not text:
        return None
    s = text.strip()
    s = re.sub(r"^```(?:json)?\s*", "", s)
    s = re.sub(r"\s*```$", "", s)
    try:
        return _validate_ratings(json.loads(s))
    except json.JSONDecodeError:
        pass
    match = re.search(r"\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}", s, re.DOTALL)
    if match:
        candidate = match.group(0).replace("“", '"').replace("”", '"').replace("’", "'")
        try:
            return _validate_ratings(json.loads(candidate))
        except json.JSONDecodeError:
            pass
    return None


def _validate_ratings(obj):
    if not isinstance(obj, dict):
        return None
    out = {}
    for col in CSV_COLUMNS[1:]:
        if col not in obj:
            return None
        val = obj[col]
        if col == "Q9_overall":
            try:
                v = int(val)
                if not 1 <= v <= 5:
                    return None
                out[col] = v
            except (ValueError, TypeError):
                return None
        else:
            v = str(val).strip().lower()
            if v not in VALID_BINARY:
                return None
            out[col] = v
    return out


# ───────────────────────────────────────────────────────────────────────────
# CSV writing
# ───────────────────────────────────────────────────────────────────────────

def output_path(judge_name: str) -> Path:
    return OUTPUT_DIR / f"judge_{judge_name}.csv"


def init_csv(judge_name: str) -> Path:
    fp = output_path(judge_name)
    with open(fp, "w", newline="", encoding="utf-8") as f:
        csv.writer(f).writerow(CSV_COLUMNS)
    return fp


def append_row(judge_name: str, conversation_id: str, ratings):
    fp = output_path(judge_name)
    if ratings is None:
        row = [conversation_id] + ["na"] * 8 + [3]
        print(f"    ⚠ {judge_name}: failed to parse rating for {conversation_id}; using placeholders.")
    else:
        row = [conversation_id] + [ratings[c] for c in CSV_COLUMNS[1:]]
    with open(fp, "a", newline="", encoding="utf-8") as f:
        csv.writer(f).writerow(row)


def already_rated_ids(judge_name: str):
    fp = output_path(judge_name)
    if not fp.exists():
        return set()
    try:
        df = pd.read_csv(fp)
        return set(df["conversation_id"].astype(str))
    except Exception:
        return set()


# ───────────────────────────────────────────────────────────────────────────
# Transformers backend — load, run, free GPU memory
# ───────────────────────────────────────────────────────────────────────────

class TransformersJudge:
    """Loads a model with HF transformers, runs inference, then frees GPU memory.

    Use as a context manager:

        with TransformersJudge("meta-llama/Llama-3.3-70B-Instruct") as judge:
            run_judge("Llama33", judge.call)
        # at this point the model is gone from GPU memory
    """

    def __init__(self, model_id, *, dtype=None, trust_remote_code=False,
                 max_new_tokens=512, device_map="auto", tokenizer_kwargs=None):
        # Default dtype from env var so users can swap globally for V100/older GPUs.
        # bfloat16 needs Ampere (A100, A10, A40, RTX 30xx+).
        # float16 works on Volta (V100), Turing (T4, RTX 20xx), and newer.
        # On V100s, set: export JUDGE_DTYPE=float16
        import os
        if dtype is None:
            dtype = os.getenv("JUDGE_DTYPE", "bfloat16")
        self.model_id = model_id
        self.dtype = dtype
        self.trust_remote_code = trust_remote_code
        self.max_new_tokens = max_new_tokens
        self.device_map = device_map
        self.tokenizer_kwargs = tokenizer_kwargs or {}
        self.tokenizer = None
        self.model = None
        self._has_chat_template = False

    def __enter__(self):
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer

        print(f"  Loading {self.model_id} (dtype={self.dtype}) ...", flush=True)
        t0 = time.time()
        torch_dtype = getattr(torch, self.dtype)

        self.tokenizer = AutoTokenizer.from_pretrained(
            self.model_id,
            trust_remote_code=self.trust_remote_code,
            **self.tokenizer_kwargs,
        )
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token

        # transformers >=4.46 prefers `dtype=` over `torch_dtype=`
        try:
            self.model = AutoModelForCausalLM.from_pretrained(
                self.model_id,
                dtype=torch_dtype,
                device_map=self.device_map,
                trust_remote_code=self.trust_remote_code,
            )
        except TypeError:
            # Older transformers — fall back to torch_dtype
            self.model = AutoModelForCausalLM.from_pretrained(
                self.model_id,
                torch_dtype=torch_dtype,
                device_map=self.device_map,
                trust_remote_code=self.trust_remote_code,
            )
        self.model.eval()
        self._has_chat_template = (
            getattr(self.tokenizer, "chat_template", None) is not None
        )
        print(f"  Model loaded in {time.time() - t0:.1f}s. "
              f"Chat template: {'yes' if self._has_chat_template else 'no (using fallback format)'}",
              flush=True)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        # Critical: free GPU memory so the next judge can load
        import torch
        print(f"  Unloading {self.model_id} from GPU ...", flush=True)
        if self.model is not None:
            del self.model
            self.model = None
        if self.tokenizer is not None:
            del self.tokenizer
            self.tokenizer = None
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            torch.cuda.synchronize()
        print(f"  GPU memory freed.", flush=True)
        return False

    def call(self, system_prompt: str, user_prompt: str) -> str:
        import torch

        attention_mask = None

        if self._has_chat_template:
            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ]
            try:
                tok_out = self.tokenizer.apply_chat_template(
                    messages,
                    return_tensors="pt",
                    add_generation_prompt=True,
                    return_dict=True,  # always returns dict; uniform handling
                )
            except Exception:
                # Some models don't accept system in chat template; merge it
                merged = f"{system_prompt}\n\n{user_prompt}"
                tok_out = self.tokenizer.apply_chat_template(
                    [{"role": "user", "content": merged}],
                    return_tensors="pt",
                    add_generation_prompt=True,
                    return_dict=True,
                )
            # tok_out can be a dict (BatchEncoding) or sometimes a Tensor
            if isinstance(tok_out, dict) or hasattr(tok_out, "input_ids"):
                input_ids = tok_out["input_ids"] if "input_ids" in tok_out else tok_out.input_ids
                attention_mask = tok_out.get("attention_mask") if isinstance(tok_out, dict) else getattr(tok_out, "attention_mask", None)
            else:
                input_ids = tok_out
        else:
            # Fallback for models without a chat template
            text = (
                f"### Instruction: {system_prompt}\n\n"
                f"### Input: {user_prompt}\n\n"
                f"### Response:"
            )
            tok_out = self.tokenizer(text, return_tensors="pt")
            input_ids = tok_out.input_ids
            attention_mask = tok_out.attention_mask

        # Ensure tensor (some chat templates return lists)
        if not isinstance(input_ids, torch.Tensor):
            input_ids = torch.tensor(input_ids)
        if input_ids.dim() == 1:
            input_ids = input_ids.unsqueeze(0)

        input_ids = input_ids.to(self.model.device)
        if attention_mask is not None:
            if not isinstance(attention_mask, torch.Tensor):
                attention_mask = torch.tensor(attention_mask)
            if attention_mask.dim() == 1:
                attention_mask = attention_mask.unsqueeze(0)
            attention_mask = attention_mask.to(self.model.device)
        else:
            # Build attention mask manually if tokenizer didn't produce one
            attention_mask = torch.ones_like(input_ids)

        # Resolve pad_token_id robustly
        pad_id = self.tokenizer.pad_token_id
        if pad_id is None:
            pad_id = self.tokenizer.eos_token_id

        gen_kwargs = {
            "input_ids": input_ids,
            "attention_mask": attention_mask,
            "max_new_tokens": self.max_new_tokens,
            "temperature": 0.1,
            "do_sample": True,
            "top_p": 0.95,
            "pad_token_id": pad_id,
        }

        with torch.no_grad():
            outputs = self.model.generate(**gen_kwargs)
        new_tokens = outputs[0, input_ids.shape[1]:]
        return self.tokenizer.decode(new_tokens, skip_special_tokens=True)


# ───────────────────────────────────────────────────────────────────────────
# Generic run loop
# ───────────────────────────────────────────────────────────────────────────

def run_judge(judge_name, call_model_fn, *, sleep_between=0.0, resume=True):
    """Run a single judge over all input conversations."""
    items = load_conversations()
    fp = output_path(judge_name)
    done = already_rated_ids(judge_name) if resume and fp.exists() else set()
    if not fp.exists():
        init_csv(judge_name)
    if done:
        print(f"  Resuming: {len(done)} done, {len(items) - len(done)} remaining", flush=True)

    n_done = 0
    n_failed = 0
    n_traceback_printed = 0
    t0 = time.time()
    for i, item in enumerate(items, 1):
        conv_id = item["conversation_id"]
        if conv_id in done:
            continue
        sys_prompt, user_prompt = build_full_prompt(item["conversation"])
        try:
            raw = call_model_fn(sys_prompt, user_prompt)
        except Exception as e:
            print(f"    ✗ [{i}/{len(items)}] {conv_id}: {type(e).__name__}: {e}", flush=True)
            # Print full traceback for the first 3 failures so we can diagnose
            if n_traceback_printed < 3:
                import traceback
                traceback.print_exc()
                n_traceback_printed += 1
                print(f"    (full traceback above; suppressing for further failures)", flush=True)
            append_row(judge_name, conv_id, None)
            n_failed += 1
            continue
        ratings = parse_judge_response(raw)
        if ratings is None:
            print(f"    ⚠ [{i}/{len(items)}] {conv_id}: unparseable: {raw[:120]!r}", flush=True)
            append_row(judge_name, conv_id, None)
            n_failed += 1
        else:
            append_row(judge_name, conv_id, ratings)
            n_done += 1
            if n_done % 10 == 0 or i == len(items):
                elapsed = time.time() - t0
                rate = n_done / max(elapsed, 0.001)
                remaining = len(items) - len(done) - n_done
                eta = remaining / max(rate, 0.001)
                print(f"    [{i}/{len(items)}] {n_done} ok / {n_failed} fail "
                      f"({rate:.1f} items/s, ETA {eta:.0f}s)", flush=True)
        if sleep_between > 0:
            time.sleep(sleep_between)

    elapsed = time.time() - t0
    print(f"\n  ✔ {judge_name}: {n_done} success, {n_failed} fail in {elapsed:.0f}s", flush=True)
    print(f"  → {fp}", flush=True)
    return fp
