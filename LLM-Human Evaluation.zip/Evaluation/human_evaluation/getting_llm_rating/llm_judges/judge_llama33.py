"""
Judge 2: Llama-3.3-70B-Instruct (Meta)
=======================================

Backend: HuggingFace transformers.

Default: meta-llama/Llama-3.3-70B-Instruct (~140GB bf16, 2× A100-80GB)
On 8× V100 (32GB each), use:
    LLAMA_MODEL=meta-llama/Llama-3.1-8B-Instruct python judge_llama33.py
    (or meta-llama/Llama-3.1-70B-Instruct if you want the bigger model — it'll
     spread across ~5 V100s and run slowly but it works)

Dtype:
  Set JUDGE_DTYPE=float16 on V100/T4. Default bfloat16 for Ampere+.

License: Llama-3.3 requires accepting Meta's license on Hugging Face.
Run `huggingface-cli login` or set HF_TOKEN before launching.

Output: judge_outputs/judge_Llama33.csv
"""
import os
from judge_common import TransformersJudge, run_judge

JUDGE_NAME = "Llama33"
MODEL_ID = os.getenv("LLAMA_MODEL", "meta-llama/Llama-3.3-70B-Instruct")


def main():
    with TransformersJudge(MODEL_ID) as judge:
        run_judge(JUDGE_NAME, judge.call)


if __name__ == "__main__":
    main()
