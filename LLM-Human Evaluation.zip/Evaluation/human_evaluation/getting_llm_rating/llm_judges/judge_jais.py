"""
Judge 4: Jais (Inception / G42 / MBZUAI)
=========================================

UAE-developed bilingual Arabic-English model.

Default: inceptionai/jais-13b-chat
Larger:  inceptionai/jais-30b-chat-v3 (set JAIS_MODEL=...)

╔═══════════════════════════════════════════════════════════════════════╗
║ IMPORTANT: Jais is a GATED repository on HuggingFace.                ║
║                                                                       ║
║ Before running this judge:                                            ║
║   1. Visit https://huggingface.co/inceptionai/jais-13b-chat          ║
║      (log in to HuggingFace, then click                              ║
║      "Agree and access repository")                                   ║
║   2. Get a token from https://huggingface.co/settings/tokens         ║
║   3. Set the env var:                                                 ║
║         export HF_TOKEN=hf_your_token_here                           ║
║      (or run `huggingface-cli login` once)                           ║
╚═══════════════════════════════════════════════════════════════════════╝

Dtype:
    Set JUDGE_DTYPE=float16 on V100/T4. Default bfloat16 for Ampere+.

Output: judge_outputs/judge_Jais.csv
"""
import os
import sys
from judge_common import TransformersJudge, run_judge

JUDGE_NAME = "Jais"
MODEL_ID = os.getenv("JAIS_MODEL", "inceptionai/jais-13b-chat")


def main():
    # Sanity check for the most common cause of failure
    if not os.getenv("HF_TOKEN") and not os.path.exists(
        os.path.expanduser("~/.cache/huggingface/token")
    ):
        print("⚠ Warning: no HF_TOKEN set and no cached HF login found.", flush=True)
        print("  Jais is a gated repo. If model loading fails with 401:", flush=True)
        print("  1. Accept terms at https://huggingface.co/inceptionai/jais-13b-chat", flush=True)
        print("  2. export HF_TOKEN=hf_your_token_here", flush=True)
        print("", flush=True)

    with TransformersJudge(MODEL_ID, trust_remote_code=True) as judge:
        run_judge(JUDGE_NAME, judge.call)


if __name__ == "__main__":
    main()
