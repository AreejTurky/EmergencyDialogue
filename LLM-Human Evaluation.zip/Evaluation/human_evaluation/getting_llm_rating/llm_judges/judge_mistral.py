"""
Judge 5: Mistral (Mistral AI, France)
=======================================

European multilingual model — provides bias decorrelation from US (Llama),
Chinese (Qwen), and Gulf (ALLaM, Jais) judges.

Default: mistralai/Mistral-Small-24B-Instruct-2501 (~48GB bf16, ~24GB fp16)

For smaller GPUs (single 32GB V100): mistralai/Mistral-7B-Instruct-v0.3 (~14GB)

Override:
    MISTRAL_MODEL=mistralai/Mistral-7B-Instruct-v0.3 python judge_mistral.py

Dtype:
    Set JUDGE_DTYPE=float16 on V100/T4. Default bfloat16 for Ampere+.

Note: Mistral-Small-24B-2501 has a known tokenizer regex issue. We pass
fix_mistral_regex=True to load the corrected tokenizer.

Output: judge_outputs/judge_Mistral.csv
"""
import os
from judge_common import TransformersJudge, run_judge

JUDGE_NAME = "Mistral"
MODEL_ID = os.getenv("MISTRAL_MODEL", "mistralai/Mistral-Small-24B-Instruct-2501")


def main():
    # fix_mistral_regex=True silences the tokenizer warning and uses the correct pattern
    tk_kwargs = {"fix_mistral_regex": True} if "Mistral" in MODEL_ID else {}
    with TransformersJudge(MODEL_ID, tokenizer_kwargs=tk_kwargs) as judge:
        run_judge(JUDGE_NAME, judge.call)


if __name__ == "__main__":
    main()
