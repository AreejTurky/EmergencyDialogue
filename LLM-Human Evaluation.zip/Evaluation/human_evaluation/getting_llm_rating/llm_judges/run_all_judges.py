"""
run_all_judges.py — Orchestrator (HPC-friendly)
================================================

Runs all 5 LLM judges sequentially. Each judge runs in a SEPARATE PYTHON
SUBPROCESS, which guarantees complete GPU memory release between judges
(transformers/torch sometimes leak memory even after del + empty_cache).
This is the safest way on a shared HPC node.

Models load ONE AT A TIME — never two simultaneously. The order is:
  1. ALLaM (smallest, ~14GB)
  2. Jais (~26GB)
  3. Mistral (~48GB)
  4. Qwen3 (~145GB or 65GB)
  5. Llama-3.3 (~140GB)

Usage:
    python run_all_judges.py                # All 5
    python run_all_judges.py --only ALLaM Qwen3
    python run_all_judges.py --skip Mistral
    python run_all_judges.py --list

After all judges finish, copy judge_outputs/judge_*.csv to your validation
pipeline's input_llm/ folder.
"""
import argparse
import csv
import subprocess
import sys
import time
from pathlib import Path

# Ordered smallest-first so a small model failure (cheap to retry) is caught
# before committing to loading a 70B model.
JUDGES = [
    ("ALLaM",   "judge_allam.py",   "ALLaM-7B (Saudi SDAIA/IBM) — Arabic-native, ~14GB"),
    ("Jais",    "judge_jais.py",    "Jais-13B (UAE Inception/G42) — Arabic-native, ~26GB"),
    ("Mistral", "judge_mistral.py", "Mistral-Small-24B (France) — European multilingual, ~48GB"),
    ("Qwen3",   "judge_qwen3.py",   "Qwen2.5-72B (Alibaba) — multilingual, ~145GB"),
    ("Llama33", "judge_llama33.py", "Llama-3.3-70B (Meta) — general baseline, ~140GB"),
]


def main():
    parser = argparse.ArgumentParser(description="Run all 5 LLM judges sequentially.")
    parser.add_argument("--only", nargs="+", metavar="NAME",
                        help="Run only these judges")
    parser.add_argument("--skip", nargs="+", metavar="NAME",
                        help="Skip these judges")
    parser.add_argument("--list", action="store_true", help="List available judges")
    args = parser.parse_args()

    if args.list:
        print("Available judges (run order, smallest first):")
        for name, _, desc in JUDGES:
            print(f"  {name:10s} — {desc}")
        return

    selected = JUDGES
    if args.only:
        selected = [j for j in JUDGES if j[0] in args.only]
        if not selected:
            print(f"No judges match --only {args.only}. Available: {[j[0] for j in JUDGES]}")
            sys.exit(1)
    if args.skip:
        selected = [j for j in selected if j[0] not in args.skip]

    print("=" * 70)
    print("  LLM JUDGE PIPELINE (transformers backend, sequential)")
    print("=" * 70)
    print(f"  Running {len(selected)} judge(s): {', '.join(j[0] for j in selected)}")
    print(f"  Each judge runs in its own subprocess — clean GPU between judges.")
    print("=" * 70)

    summary = []
    t_start = time.time()

    for name, script, desc in selected:
        script_path = Path(__file__).parent / script
        if not script_path.exists():
            print(f"\n  ✗ {name}: script not found: {script_path}")
            summary.append((name, "missing_script", 0))
            continue

        print(f"\n{'─' * 70}")
        print(f"  ▶ {name}: {desc}")
        print(f"  Subprocess: {sys.executable} {script_path.name}")
        print(f"{'─' * 70}", flush=True)
        t0 = time.time()
        try:
            # Run as subprocess — when this returns, the OS has reclaimed all GPU
            # memory used by the model. The next judge starts from a clean slate.
            result = subprocess.run(
                [sys.executable, str(script_path)],
                cwd=str(script_path.parent),
                capture_output=False,
                check=False,
            )
            elapsed = time.time() - t0
            if result.returncode == 0:
                summary.append((name, "ok", elapsed))
            else:
                summary.append((name, f"exit_code_{result.returncode}", elapsed))
        except Exception as e:
            elapsed = time.time() - t0
            print(f"  ✗ {name} crashed: {type(e).__name__}: {e}")
            summary.append((name, f"crashed:{type(e).__name__}", elapsed))

    total = time.time() - t_start

    print("\n" + "=" * 70)
    print("  SUMMARY")
    print("=" * 70)
    for name, status, elapsed in summary:
        icon = "✔" if status == "ok" else "✗"
        m, s = divmod(int(elapsed), 60)
        print(f"  {icon} {name:10s} {status:25s} {m}m {s}s")
    tm, ts = divmod(int(total), 60)
    print(f"\n  Total wall clock: {tm}m {ts}s")
    print("=" * 70)

    print("\n  Output files:")
    out_dir = Path(__file__).parent / "judge_outputs"
    if out_dir.exists():
        for f in sorted(out_dir.glob("judge_*.csv")):
            try:
                with open(f) as fh:
                    n = sum(1 for _ in csv.reader(fh)) - 1
                print(f"    ✔ {f.name} — {n} rows")
            except Exception:
                print(f"    {f.name}")

    print("\n  Next: copy judge_outputs/judge_*.csv to llm_validation/input_llm/")
    print("        then run validate_llm_judges.py")


if __name__ == "__main__":
    main()
