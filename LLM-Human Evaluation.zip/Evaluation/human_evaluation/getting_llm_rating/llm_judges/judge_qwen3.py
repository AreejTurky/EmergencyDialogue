"""
Judge 1: Qwen3 (Alibaba)
========================

Backend: HuggingFace transformers, loads on local GPUs.

Default model: Qwen/Qwen2.5-72B-Instruct
  - Strong multilingual including Arabic
  - ~145GB in bf16 → fits on 2× A100-80GB
  - On 8× V100 (32GB each), use the smaller variant:
    QWEN_MODEL=Qwen/Qwen2.5-32B-Instruct python judge_qwen3.py

Dtype:
  Set JUDGE_DTYPE=float16 on V100/T4 (Volta/Turing — no bf16 hardware).
  Default bfloat16 works on A100/A10/RTX 30xx+ (Ampere or newer).

Output: judge_outputs/judge_Qwen3.csv
"""
import os
from judge_common import TransformersJudge, run_judge

JUDGE_NAME = "Qwen3"
MODEL_ID = os.getenv("QWEN_MODEL", "Qwen/Qwen2.5-72B-Instruct")


def main():
    with TransformersJudge(MODEL_ID) as judge:
        run_judge(JUDGE_NAME, judge.call)


if __name__ == "__main__":
    main()
