# LLM Judge Pipeline (HPC / transformers backend)

Runs 5 open-source LLM judges over your dispatcher conversations using HuggingFace transformers. Designed for HPC clusters: models load **one at a time** with full GPU cleanup between judges.

## The 5 judges (run order: smallest first)

| Order | Judge | Model | Approx VRAM (bf16) | Family |
|---|---|---|---|---|
| 1 | **ALLaM** | `ALLaM-AI/ALLaM-7B-Instruct-preview` | ~14 GB | Saudi (SDAIA/IBM) |
| 2 | **Jais** | `inceptionai/jais-13b-chat` | ~26 GB | UAE (Inception/G42/MBZUAI) |
| 3 | **Mistral** | `mistralai/Mistral-Small-24B-Instruct-2501` | ~48 GB | France (Mistral AI) |
| 4 | **Qwen3** | `Qwen/Qwen2.5-72B-Instruct` | ~145 GB (2× A100-80GB) | China (Alibaba) |
| 5 | **Llama33** | `meta-llama/Llama-3.3-70B-Instruct` | ~140 GB (2× A100-80GB) | USA (Meta) |

Smallest first: if Llama loading fails near the end, you still have 4 judges' worth of data.

## Architecture — one model at a time, no overhead

```
Each judge runs as its own Python subprocess.
The OS reclaims all GPU memory when the subprocess exits — guaranteed clean state.

t=0      ┌──── ALLaM (subprocess) ────┐
         │ load weights  → 120 calls  │
         │ → judge_ALLaM.csv          │
         │ subprocess exits           │
         └────────────────────────────┘  GPU clean
t+10min  ┌──── Jais (subprocess) ─────┐
         │ load → 120 calls → CSV     │
         └────────────────────────────┘  GPU clean
t+25min  ┌──── Mistral ────────────────┐
            ...                         
```

This is more reliable than `torch.cuda.empty_cache()` inside one long-running process — transformers and torch occasionally hold onto memory even after `del`.

## File layout

```
llm_judges/
├── judge_common.py          ← shared prompt, parser, TransformersJudge class
├── judge_allam.py           ← Judge 1
├── judge_jais.py            ← Judge 2
├── judge_mistral.py         ← Judge 3
├── judge_qwen3.py           ← Judge 4
├── judge_llama33.py         ← Judge 5
├── run_all_judges.py        ← orchestrator (subprocess-based)
├── run_all_judges.slurm     ← SLURM job template
├── input/
│   └── conversations_to_judge.csv     ← YOUR INPUT
└── judge_outputs/
    └── judge_*.csv          ← OUTPUT (5 CSVs)
```

## Step 1 — Install dependencies

```bash
pip install -r requirements.txt
```

If your cluster has CUDA 12.4 modules:
```bash
module load python/3.11 cuda/12.4
pip install -r requirements.txt
```

## Step 2 — Prepare input

Place `input/conversations_to_judge.csv` with two columns: `conversation_id`, `conversation`.

## Step 3 — HuggingFace token (for Llama-3.3 only)

Llama-3.3 weights require accepting Meta's license on Hugging Face:

1. Go to https://huggingface.co/meta-llama/Llama-3.3-70B-Instruct → click "Accept license"
2. Run `huggingface-cli login` and paste your token, **OR** `export HF_TOKEN=hf_...`

The other 4 models are publicly downloadable.

## Step 4 — Run

### Interactively on a GPU node:

```bash
python run_all_judges.py                # all 5
python run_all_judges.py --only ALLaM   # one judge
python run_all_judges.py --skip Llama33 # skip the slowest
python run_all_judges.py --list         # show available
```

### Via SLURM:

Edit `run_all_judges.slurm` to match your cluster (partition name, GPU type), then:

```bash
sbatch run_all_judges.slurm
```

Watch progress:

```bash
tail -f logs/llm_judges_<JOBID>.out
```

## Resumable

Each judge's CSV is appended row-by-row. If a job dies, re-running picks up where it left off — already-rated conversations are skipped automatically.

## Memory tuning per cluster

If your GPUs are smaller than expected (40GB instead of 80GB), use smaller variants by setting env vars:

```bash
QWEN_MODEL=Qwen/Qwen2.5-32B-Instruct python judge_qwen3.py
LLAMA_MODEL=meta-llama/Llama-3.1-8B-Instruct python judge_llama33.py
JAIS_MODEL=inceptionai/jais-13b-chat python judge_jais.py    # this is already the default
MISTRAL_MODEL=mistralai/Mistral-7B-Instruct-v0.3 python judge_mistral.py
```

The 5-family diversity argument still holds; only the parameter counts shrink.

## Output

Each CSV: `conversation_id`, `Q1_location`, ..., `Q8_callback`, `Q9_overall`. Q1–Q8 are `yes`/`no`/`na`, Q9 is integer 1–5.

## Hand off to validation pipeline

```bash
cp judge_outputs/judge_*.csv ../llm_validation/input_llm/
cd ../llm_validation
python validate_llm_judges.py
```

## Time and resource estimates

For 120 conversations on 2× A100-80GB:

| Judge | Model load | Inference | Total |
|---|---|---|---|
| ALLaM (7B) | ~30s | ~3 min | ~3.5 min |
| Jais (13B) | ~1 min | ~5 min | ~6 min |
| Mistral (24B) | ~2 min | ~7 min | ~9 min |
| Qwen3 (72B) | ~5 min | ~15 min | ~20 min |
| Llama-3.3 (70B) | ~5 min | ~15 min | ~20 min |
| **Total** | | | **~60 min** |

If you have only 1× A100-80GB, swap Qwen3 and Llama for their smaller siblings (32B and 8B), bringing total to ~30 min.
