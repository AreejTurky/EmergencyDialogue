import json
import pandas as pd

input_file = "/Users/linaalqahtani/Desktop/neurips_human_eval/sft_chatml.jsonl"
output_file = "output.csv"

# Load JSONL
data = []
with open(input_file, "r", encoding="utf-8") as f:
    for line in f:
        data.append(json.loads(line))

# Convert to DataFrame
df = pd.DataFrame(data)

# Save as CSV
df.to_csv(output_file, index=False, encoding="utf-8-sig")

print(f"✅ Saved to {output_file}")