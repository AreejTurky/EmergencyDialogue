# LLM-Judge Validation — Paper-Ready Report

**Setup:** 3 LLM judges (ALLaM, Llama33, Qwen3) compared against human consensus on 120 dispatcher conversations.

---

## Table 1 — Per-judge and panel agreement with human consensus

| Judge | n | Pearson r (Q9) | 95% CI | Mean κ (Q1–Q8) | MAE (Q9) |
|---|---|---|---|---|---|
| ALLaM | 119 | 0.109 | [-0.07, 0.29] | 0.166 | 1.412 |
| Llama33 | 119 | 0.705 | [0.59, 0.79] | 0.422 | 0.529 |
| Qwen3 | 119 | 0.577 | [0.45, 0.69] | 0.395 | 0.706 |
| PANEL (consensus) | 132 | 0.554 | [0.42, 0.66] | 0.433 | 0.722 |

---

## Table 2 — Per-criterion agreement (LLM panel vs. humans)

| Criterion | Metric | Value | 95% CI | MAE |
|---|---|---|---|---|
| Q1_location | Cohen's κ | 0.632 | — | — |
| Q2_consciousness | Cohen's κ | 0.509 | — | — |
| Q3_chief_complaint | Cohen's κ | 0.332 | — | — |
| Q4_question_ordering | Cohen's κ | 0.254 | — | — |
| Q5_caller_retention | Cohen's κ | 0.575 | — | — |
| Q6_pre_arrival | Cohen's κ | 0.542 | — | — |
| Q7_affective | Cohen's κ | 0.169 | — | — |
| Q8_callback | Cohen's κ | 0.453 | — | — |
| Q9_overall | Pearson r | 0.554 | [0.43, 0.67] | 0.722 |

---

## Figure 1 — Bland-Altman plot

See `figure1_bland_altman.png`. Mean difference (LLM − human) = +0.10, 95% Limits of Agreement = [-1.71, +1.91]

---

## Per-stratum analysis (the asymmetry justified)

Human consensus on the 15 anchor conversations aggregates 7 raters (high-reliability). 
Human consensus on the 105 unique conversations is a single rater (lower reliability). 
LLM panel agreement should be higher on anchors if the methodology is sound.

- LLM panel ↔ human consensus on **15 anchors** (multi-rater human side): r = **0.665**
- LLM panel ↔ human consensus on **105 unique** (single-rater human side): r = **0.542**

✔ Anchor r > Unique r — confirms expected pattern: LLM-human correlation rises when human ratings are more reliable.

---

## Paper-ready paragraph

> **LLM-judge validation.** We validate a panel of 3 LLM judges (ALLaM, Llama33, Qwen3) against the human consensus on 120 dispatcher conversations. On the overall quality score (Q9), the panel correlated with human consensus at Pearson r = 0.55 [95% CI: 0.42, 0.66], with mean absolute error 0.72 on the 1–5 scale. Per-criterion Cohen's κ on the binary criteria (Q1–Q8) ranged from 0.17 to 0.63 (mean κ = 0.43). Per-judge correlations with human consensus ranged from 0.11 to 0.70, with the aggregate panel matching any individual judge — supporting the use of a multi-judge panel over single-judge evaluation. Bland–Altman analysis revealed a mean difference of +0.10 (LLM − human) with 95% limits of agreement [-1.71, +1.91], indicating no systematic bias. Per-stratum analysis confirmed that LLM-human agreement was higher on the 15-item multi-rater anchor subset (r = 0.67) than on the 105 single-rater subset (r = 0.54), as expected when human ratings themselves vary in reliability. We treat these results as sufficient to position the LLM panel as a scalable proxy for human evaluation across the broader benchmark.
