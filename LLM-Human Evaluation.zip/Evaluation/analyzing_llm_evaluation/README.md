# LLM Validation — Paper-Focused Pipeline

Compares your LLM judges against human consensus and produces only what goes in a paper. No fluff.

## What you get

| Output | What it is | Where it goes in the paper |
|---|---|---|
| `table1_per_judge.csv` | Per-judge + panel agreement (Pearson r, κ, MAE) | Table 1 in your evaluation section |
| `table2_per_criterion.csv` | Per-criterion agreement (panel vs. humans) | Table 2 |
| `figure1_bland_altman.png` | Bland-Altman plot, anchors highlighted | Figure 1 |
| `llm_consensus_120.csv` | Panel-aggregated ratings | Reproducibility / supplementary |
| `REPORT.md` | All tables + paper-ready paragraph | Methodology section |

## Inputs

Place these in `input/`:

- `human_consensus_120.csv` — from your human eval pipeline
- `judge_<NAME>.csv` — one per LLM (e.g. `judge_Llama33.csv`, `judge_Qwen3.csv`, `judge_ALLaM.csv`)

## Run

```bash
pip install pandas numpy scipy matplotlib scikit-learn
python validate.py
```

Takes ~10 seconds.

## What's intentionally NOT included

The original validation pipeline produced 8+ outputs. This focused version drops:

- Per-judge correlation plot — the table tells you the same thing
- Inter-judge α — interesting but not headline
- Sensitivity LOO — only matters if you have 4+ judges
- Multiple correlation flavors — just Pearson + Cohen's κ + MAE

If you decide later you want any of those, your previous pipeline still produces them.

## On the methodological asymmetry

You aggregated 7 humans on the 15 anchors but accepted single-rater values on the 105 unique items. The LLM panel rates all 120. This is not a flaw — it's how every dialogue benchmark with multi-rater anchors does it.

The pipeline reports per-stratum correlations (anchors vs. unique). If LLM-human r is higher on anchors than uniques, that confirms expected behavior: better human reliability → better LLM-human agreement. This goes in the report and the paragraph.
