# Human Evaluation Reliability Analysis

End-to-end pipeline that takes 7 reviewer CSVs (one per bin) and produces all reliability metrics, plots, and a publication-ready report.

## What it computes

1. **Krippendorff's α per criterion** with 95% bootstrap confidence intervals
2. **Fleiss' κ on Q1–Q8** (binary criteria, familiar metric for cross-validation)
3. **ICC(2,7) on Q9** (reliability of the averaged 1–5 score)
4. **Pairwise Cohen's κ** between every rater pair (detects outlier raters)
5. **Per-rater bias analysis** on the anchor set
6. **Highest-variance items** for qualitative disagreement analysis
7. **Aggregated human consensus table** — one consensus value per conversation per criterion, ready for LLM-as-judge comparison

## Setup

```bash
pip install -r requirements.txt
```

## Run

```bash
# 1. Drop your 7 CSV files into ./input/
#    (named bin_1.csv through bin_7.csv, or any pattern matching bin_*.csv)

# 2. Run the analysis
python analyze_human_eval.py
```

## Input format

Each CSV (one per bin/reviewer) must have these columns:

```
conversation_id, is_anchor, reviewer_name,
Q1_location, Q2_consciousness, Q3_chief_complaint, Q4_question_ordering,
Q5_caller_retention, Q6_pre_arrival, Q7_affective, Q8_callback,
Q9_overall, timestamp
```

- 30 rows per CSV (15 anchors with `is_anchor=TRUE`, 15 unique with `is_anchor=FALSE`)
- The 15 anchor `conversation_id` values **must be identical** across all 7 CSVs (they're the shared items)
- Q1–Q8: values `yes` / `no` / `na`
- Q9: integer 1–5

## Output files (in `./output/`)

| File | Contents |
|---|---|
| `RELIABILITY_REPORT.md` | Full markdown report with all metrics + paper-ready paragraph |
| `reliability_table.csv` | Per-criterion α, Fleiss κ, ICC, with CIs |
| `per_rater_bias.csv` | Per-rater anchor mean Q9, deviation from group mean, per-criterion yes-rates |
| `pairwise_cohen_kappa.csv` | 7×7 matrix of pairwise rater agreement |
| `anchor_item_variance.csv` | All 15 anchors ranked by disagreement; top 5 are paper-ready qualitative analysis candidates |
| `human_consensus_120.csv` | One consensus value per conversation per criterion (anchors aggregated, unique passed through). **Use this for LLM comparison later.** |
| `alpha_per_criterion.png` | Bar chart of α per criterion with CIs (paper figure) |
| `pairwise_cohen_kappa.png` | Heatmap of rater-rater agreement (paper figure) |

## What to do with the output

1. **Read `RELIABILITY_REPORT.md`** — section 5 contains a paragraph you can paste straight into your paper's Reliability section
2. **Read the 3–5 conversations with highest variance** in `anchor_item_variance.csv` — characterize *why* reviewers disagreed. This becomes your qualitative disagreement analysis section
3. **Use `human_consensus_120.csv`** as the human-side input when you compare against LLM-as-judge ratings later

## Interpretation thresholds (Krippendorff 2018)

| α range | Interpretation |
|---|---|
| ≥ 0.80 | Reliable |
| 0.67 – 0.80 | Tentative (acceptable in NLP) |
| 0.40 – 0.67 | Moderate |
| < 0.40 | Low |

For NLP benchmark papers, α ≥ 0.6 is typically reported as acceptable, with explicit acknowledgment that this is below Krippendorff's strict threshold but consistent with the inherent subjectivity of dialogue quality judgments (and consistent with comparable benchmarks: MT-Bench, HELM, WMT).

## When α is missing from a criterion

Krippendorff's α is undefined when there is no variance in the data — for example, if all 7 raters gave the same answer ("yes") on every anchor for one criterion. The report flags these criteria as "—" and notes "no variance" on the plot. This is descriptive ("everyone agreed perfectly") rather than a failure.
