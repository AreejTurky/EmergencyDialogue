"""
Human Evaluation Reliability Analysis
======================================

Inputs:  ./input/bin_*.csv  (7 CSVs, one per reviewer/bin)
Outputs: ./output/  (all reliability tables, plots, and summary report)

Each input CSV row format:
  conversation_id, is_anchor, reviewer_name, Q1_location, Q2_consciousness,
  Q3_chief_complaint, Q4_question_ordering, Q5_caller_retention,
  Q6_pre_arrival, Q7_affective, Q8_callback, Q9_overall, timestamp

Q1-Q8 values: yes / no / na
Q9 values: 1-5 integer

Computes:
  1. Krippendorff's alpha per criterion (with 95% bootstrap CIs)
  2. Fleiss' kappa on Q1-Q8 (binary criteria, familiar metric)
  3. ICC(2,7) on Q9 (reliability of averaged score)
  4. Pairwise Cohen's kappa between all rater pairs
  5. Per-rater bias on anchor set
  6. Highest-variance anchor items (for qualitative analysis)
  7. Aggregated human consensus per anchor (for LLM comparison later)
  8. Per-criterion alpha plot
  9. Markdown summary report
"""

import csv
import json
import sys
from collections import defaultdict
from pathlib import Path

import krippendorff
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import pingouin as pg
from scipy.stats import kendalltau
from statsmodels.stats.inter_rater import aggregate_raters, fleiss_kappa
from sklearn.metrics import cohen_kappa_score


# ───────────────────────────────────────────────────────────────────────────
# Configuration
# ───────────────────────────────────────────────────────────────────────────

INPUT_DIR = Path(__file__).parent / "input"
OUTPUT_DIR = Path(__file__).parent / "output"
OUTPUT_DIR.mkdir(exist_ok=True)

CRITERIA = [
    "Q1_location",
    "Q2_consciousness",
    "Q3_chief_complaint",
    "Q4_question_ordering",
    "Q5_caller_retention",
    "Q6_pre_arrival",
    "Q7_affective",
    "Q8_callback",
]
SCORE_CRITERION = "Q9_overall"
ALL_CRITERIA = CRITERIA + [SCORE_CRITERION]

# Map categorical to ints for nominal-level α (N/A is a valid third category)
CAT_MAP = {"yes": 1, "no": 0, "na": 2}

N_BOOTSTRAP = 1000
RNG = np.random.default_rng(42)


# ───────────────────────────────────────────────────────────────────────────
# Data loading
# ───────────────────────────────────────────────────────────────────────────

def load_all_bins(input_dir):
    """Load all bin_*.csv files. Returns a single concatenated DataFrame.

    Reviewer names are anonymized to 'Reviewer N' where N is the bin number
    from the CSV filename (so the reviewer in bin_3.csv becomes 'Reviewer 3').
    This preserves the bin → reviewer linkage, which matters because each bin's
    unique items are tied to a specific reviewer.

    Real-name → anonymized mapping is saved to output/reviewer_mapping.csv
    for your internal records.
    """
    files = sorted(input_dir.glob("bin_*.csv"))
    if not files:
        raise FileNotFoundError(f"No bin_*.csv files found in {input_dir}")

    print(f"Found {len(files)} bin files:")
    dfs = []
    bin_to_real_name = {}  # bin_id -> real reviewer name

    for fp in files:
        df = pd.read_csv(fp)
        bin_id = int(fp.stem.split("_")[1])
        df["bin_id"] = bin_id

        unique_reviewers = df["reviewer_name"].unique()
        if len(unique_reviewers) > 1:
            print(f"  ⚠ {fp.name} has multiple reviewer names: {unique_reviewers}. Using first.")
        real_name = unique_reviewers[0]
        bin_to_real_name[bin_id] = real_name

        n_anchors = (df["is_anchor"] == True).sum() if df["is_anchor"].dtype == bool else (df["is_anchor"].astype(str).str.upper() == "TRUE").sum()
        n_unique = len(df) - n_anchors
        print(f"  {fp.name}: {len(df)} rows ({n_anchors} anchors, {n_unique} unique) — {real_name} → Reviewer {bin_id}")
        dfs.append(df)

    full = pd.concat(dfs, ignore_index=True)
    if full["is_anchor"].dtype != bool:
        full["is_anchor"] = full["is_anchor"].astype(str).str.upper() == "TRUE"

    # Anonymize: every row's reviewer_name becomes "Reviewer {bin_id}"
    full["reviewer_name"] = "Reviewer " + full["bin_id"].astype(str)

    # Save the lookup table for your internal records
    mapping_rows = [
        {
            "bin_file": f"bin_{bin_id}.csv",
            "anonymized": f"Reviewer {bin_id}",
            "real_name": real_name,
        }
        for bin_id, real_name in sorted(bin_to_real_name.items())
    ]
    mapping_path = OUTPUT_DIR / "reviewer_mapping.csv"
    pd.DataFrame(mapping_rows).to_csv(mapping_path, index=False)
    print(f"  ✔ Anonymized {len(bin_to_real_name)} reviewers; mapping saved to {mapping_path.name}")

    return full, len(files)


def split_anchors_unique(df):
    anchors = df[df["is_anchor"]].copy()
    unique = df[~df["is_anchor"]].copy()
    return anchors, unique


def build_anchor_matrices(anchors_df):
    """Build per-criterion (n_raters x n_items) matrices for anchor data."""
    raters = sorted(anchors_df["reviewer_name"].unique())
    items = sorted(anchors_df["conversation_id"].unique())
    n_raters = len(raters)
    n_items = len(items)

    matrices = {}
    for crit in ALL_CRITERIA:
        mat = np.full((n_raters, n_items), np.nan)
        for _, row in anchors_df.iterrows():
            r_idx = raters.index(row["reviewer_name"])
            i_idx = items.index(row["conversation_id"])
            val = row[crit]
            if crit == SCORE_CRITERION:
                mat[r_idx, i_idx] = float(val)
            else:
                # Categorical → int code
                mat[r_idx, i_idx] = CAT_MAP.get(str(val).strip().lower(), np.nan)
        matrices[crit] = mat

    return matrices, raters, items


# ───────────────────────────────────────────────────────────────────────────
# Reliability metrics
# ───────────────────────────────────────────────────────────────────────────

def compute_alpha(matrix, level):
    """Krippendorff's alpha. matrix shape: (n_raters, n_items).
    Returns NaN if there is no variance in the data (alpha undefined)."""
    flat = matrix[~np.isnan(matrix)]
    if len(np.unique(flat)) < 2:
        return np.nan  # No variance — alpha is undefined
    try:
        return krippendorff.alpha(reliability_data=matrix, level_of_measurement=level)
    except Exception as e:
        return np.nan


def bootstrap_alpha_ci(matrix, level, n=N_BOOTSTRAP):
    """Bootstrap CI by resampling items (columns)."""
    n_items = matrix.shape[1]
    alphas = []
    for _ in range(n):
        idx = RNG.choice(n_items, n_items, replace=True)
        a = compute_alpha(matrix[:, idx], level)
        if not np.isnan(a):
            alphas.append(a)
    if len(alphas) == 0:
        return (np.nan, np.nan)
    return tuple(np.percentile(alphas, [2.5, 97.5]))


def fleiss_kappa_for_criterion(matrix):
    """Fleiss' kappa for a nominal criterion. Matrix: (n_raters, n_items) of ints."""
    # Convert to (n_items, n_categories) count matrix
    n_raters, n_items = matrix.shape
    # Drop columns with any NaN (Fleiss can't handle missing)
    valid_cols = ~np.any(np.isnan(matrix), axis=0)
    if valid_cols.sum() < 2:
        return np.nan
    valid_mat = matrix[:, valid_cols].astype(int)
    # Aggregate counts per item
    items_x_raters = valid_mat.T  # shape (n_items, n_raters)
    agg, _ = aggregate_raters(items_x_raters)
    try:
        return fleiss_kappa(agg, method="fleiss")
    except Exception as e:
        print(f"  ⚠ Fleiss kappa failed: {e}")
        return np.nan


def compute_icc_2k(anchors_df, criterion):
    """ICC(2,k) using pingouin. Long-format input required.
    pingouin's 'ICC(A,k)' = ICC(2,k) in Shrout & Fleiss notation
    (absolute agreement, average of k raters)."""
    sub = anchors_df[["reviewer_name", "conversation_id", criterion]].copy()
    sub.columns = ["rater", "target", "rating"]
    sub["rating"] = pd.to_numeric(sub["rating"], errors="coerce")
    sub = sub.dropna()
    try:
        result = pg.intraclass_corr(data=sub, targets="target", raters="rater", ratings="rating")
        # ICC(A,k) = absolute agreement, average measures = "ICC(2,k)"
        ci_col = "CI95" if "CI95" in result.columns else "CI95%"
        row = result[result["Type"] == "ICC(A,k)"]
        if len(row) > 0:
            icc = float(row["ICC"].values[0])
            ci = row[ci_col].values[0]
            ci_tuple = (float(ci[0]), float(ci[1])) if hasattr(ci, "__len__") else (np.nan, np.nan)
            return icc, ci_tuple
    except Exception as e:
        print(f"  ⚠ ICC failed: {e}")
    return np.nan, (np.nan, np.nan)


def pairwise_cohen_kappa(matrices, raters):
    """Compute pairwise Cohen's kappa between every pair of raters, averaged across binary criteria."""
    import warnings
    n_raters = len(raters)
    avg_kappa = np.full((n_raters, n_raters), np.nan)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        for i in range(n_raters):
            for j in range(n_raters):
                if i == j:
                    avg_kappa[i, j] = 1.0
                    continue
                kappas = []
                for crit in CRITERIA:  # binary only
                    row_i = matrices[crit][i, :]
                    row_j = matrices[crit][j, :]
                    valid = ~(np.isnan(row_i) | np.isnan(row_j))
                    if valid.sum() < 2:
                        continue
                    # Skip if either rater has zero variance on this criterion
                    if len(np.unique(row_i[valid])) < 2 or len(np.unique(row_j[valid])) < 2:
                        continue
                    k = cohen_kappa_score(row_i[valid].astype(int), row_j[valid].astype(int))
                    if not np.isnan(k):
                        kappas.append(k)
                if kappas:
                    avg_kappa[i, j] = np.mean(kappas)
    return avg_kappa


# ───────────────────────────────────────────────────────────────────────────
# Diagnostics
# ───────────────────────────────────────────────────────────────────────────

def per_rater_bias(anchors_df):
    """For each rater: mean Q9 score on anchors, deviation from group mean,
    plus per-criterion 'yes' rate on Q1-Q8."""
    rows = []
    grand_mean_q9 = anchors_df[SCORE_CRITERION].astype(float).mean()
    for rater in sorted(anchors_df["reviewer_name"].unique()):
        sub = anchors_df[anchors_df["reviewer_name"] == rater]
        mean_q9 = sub[SCORE_CRITERION].astype(float).mean()
        deviation = mean_q9 - grand_mean_q9
        row = {
            "rater": rater,
            "n_anchors_rated": len(sub),
            "mean_Q9": round(mean_q9, 3),
            "deviation_from_group_mean": round(deviation, 3),
        }
        for crit in CRITERIA:
            yes_rate = (sub[crit].astype(str).str.lower() == "yes").mean()
            row[f"{crit}_yes_rate"] = round(yes_rate, 3)
        rows.append(row)
    return pd.DataFrame(rows)


def high_variance_items(anchors_df, top_k=5):
    """Items with highest cross-rater variance on Q9."""
    rows = []
    for conv_id in anchors_df["conversation_id"].unique():
        sub = anchors_df[anchors_df["conversation_id"] == conv_id]
        q9_vals = sub[SCORE_CRITERION].astype(float).values
        # Also compute disagreement on binaries: count modal vs minority
        bin_disagreements = 0
        for crit in CRITERIA:
            vals = sub[crit].astype(str).str.lower().values
            if len(vals) > 0:
                mode_count = max(np.sum(vals == "yes"), np.sum(vals == "no"), np.sum(vals == "na"))
                bin_disagreements += (len(vals) - mode_count)
        rows.append({
            "conversation_id": conv_id,
            "n_raters": len(q9_vals),
            "Q9_mean": round(np.mean(q9_vals), 2),
            "Q9_std": round(np.std(q9_vals, ddof=1), 3) if len(q9_vals) > 1 else 0,
            "Q9_range": int(np.max(q9_vals) - np.min(q9_vals)) if len(q9_vals) > 1 else 0,
            "binary_disagreements": bin_disagreements,
        })
    df = pd.DataFrame(rows).sort_values("Q9_std", ascending=False).reset_index(drop=True)
    return df.head(top_k), df


def aggregate_human_consensus(anchors_df, unique_df):
    """Build a single human-consensus value per (conversation, criterion).
    Anchors: majority vote (binary), mean (Q9). Unique: single value as-is."""
    rows = []
    # Anchors: aggregate
    for conv_id in anchors_df["conversation_id"].unique():
        sub = anchors_df[anchors_df["conversation_id"] == conv_id]
        row = {"conversation_id": conv_id, "is_anchor": True, "n_raters": len(sub)}
        for crit in CRITERIA:
            vals = sub[crit].astype(str).str.lower().values
            counts = {v: np.sum(vals == v) for v in ["yes", "no", "na"]}
            # Majority vote; on tie, prefer "no" (most conservative)
            max_count = max(counts.values())
            winners = [v for v, c in counts.items() if c == max_count]
            row[crit] = winners[0] if len(winners) == 1 else (
                "yes" if "yes" in winners else ("no" if "no" in winners else "na")
            )
        row[SCORE_CRITERION] = round(sub[SCORE_CRITERION].astype(float).mean(), 2)
        rows.append(row)
    # Unique: pass through
    for _, r in unique_df.iterrows():
        row = {"conversation_id": r["conversation_id"], "is_anchor": False, "n_raters": 1}
        for crit in CRITERIA:
            row[crit] = str(r[crit]).lower()
        row[SCORE_CRITERION] = float(r[SCORE_CRITERION])
        rows.append(row)
    return pd.DataFrame(rows)


# ───────────────────────────────────────────────────────────────────────────
# Reporting
# ───────────────────────────────────────────────────────────────────────────

def interpret_alpha(a):
    if np.isnan(a):
        return "N/A"
    if a >= 0.8:
        return "Reliable"
    if a >= 0.67:
        return "Tentative"
    if a >= 0.4:
        return "Moderate"
    return "Low"


def build_reliability_table(matrices, anchors_df):
    """Per-criterion reliability table."""
    rows = []
    for crit in ALL_CRITERIA:
        level = "interval" if crit == SCORE_CRITERION else "nominal"
        mat = matrices[crit]
        a = compute_alpha(mat, level)
        ci = bootstrap_alpha_ci(mat, level)

        row = {
            "criterion": crit,
            "level": level,
            "alpha": round(a, 3) if not np.isnan(a) else np.nan,
            "alpha_ci_low": round(ci[0], 3) if not np.isnan(ci[0]) else np.nan,
            "alpha_ci_high": round(ci[1], 3) if not np.isnan(ci[1]) else np.nan,
            "interpretation": interpret_alpha(a),
        }

        if crit in CRITERIA:
            row["fleiss_kappa"] = round(fleiss_kappa_for_criterion(mat), 3)
        else:
            row["fleiss_kappa"] = np.nan

        if crit == SCORE_CRITERION:
            icc, icc_ci = compute_icc_2k(anchors_df, crit)
            row["ICC_2k"] = round(icc, 3) if not np.isnan(icc) else np.nan
            row["ICC_2k_ci_low"] = round(icc_ci[0], 3) if not np.isnan(icc_ci[0]) else np.nan
            row["ICC_2k_ci_high"] = round(icc_ci[1], 3) if not np.isnan(icc_ci[1]) else np.nan
        else:
            row["ICC_2k"] = np.nan
            row["ICC_2k_ci_low"] = np.nan
            row["ICC_2k_ci_high"] = np.nan

        rows.append(row)
    return pd.DataFrame(rows)


def plot_alpha_per_criterion(rel_df, out_path):
    """Horizontal bar chart of alpha per criterion with CI error bars."""
    fig, ax = plt.subplots(figsize=(9, 5.5))
    df = rel_df.sort_values("alpha", ascending=True).reset_index(drop=True)
    y = np.arange(len(df))
    alphas = df["alpha"].values
    ci_low = df["alpha_ci_low"].values
    ci_high = df["alpha_ci_high"].values

    err_low = alphas - ci_low
    err_high = ci_high - alphas

    colors = []
    for a in alphas:
        if np.isnan(a):
            colors.append("#cccccc")
        elif a >= 0.67:
            colors.append("#2d6a4f")
        elif a >= 0.4:
            colors.append("#d4a017")
        else:
            colors.append("#b03030")

    # Replace NaN alpha with 0 for plotting purposes (errorbars also become 0)
    alphas_plot = np.where(np.isnan(alphas), 0, alphas)
    err_low = np.where(np.isnan(alphas) | np.isnan(ci_low), 0, alphas - ci_low)
    err_high = np.where(np.isnan(alphas) | np.isnan(ci_high), 0, ci_high - alphas)

    ax.barh(y, alphas_plot, xerr=[err_low, err_high], color=colors,
            edgecolor="#1a1a1a", linewidth=0.8, capsize=4, error_kw={"linewidth": 1.0})
    # Add labels for NaN entries
    for i, a in enumerate(alphas):
        if np.isnan(a):
            ax.text(0.02, i, "no variance", va="center", fontsize=8, color="#888", style="italic")
    ax.set_yticks(y)
    ax.set_yticklabels([c.replace("_", " ").title() for c in df["criterion"]], fontsize=10)
    ax.set_xlabel("Krippendorff's α (95% bootstrap CI)", fontsize=11)
    ax.set_title("Per-criterion inter-rater agreement", fontsize=12, pad=12)
    ax.axvline(0.67, color="#2d6a4f", linestyle="--", alpha=0.5, label="Tentative threshold (0.67)")
    ax.axvline(0.4, color="#b03030", linestyle="--", alpha=0.5, label="Moderate threshold (0.40)")
    valid_ci_low = ci_low[~np.isnan(ci_low)]
    xlim_low = min(0, valid_ci_low.min() - 0.05) if len(valid_ci_low) > 0 else -0.1
    ax.set_xlim(xlim_low, 1.0)
    ax.legend(fontsize=9, loc="lower right")
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="x", linestyle=":", alpha=0.4)
    plt.tight_layout()
    plt.savefig(out_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  ✔ Saved {out_path.name}")


def plot_pairwise_kappa(kappa_mat, raters, out_path):
    """Heatmap of pairwise Cohen's κ between raters.
    `raters` is already anonymized at load time (Reviewer 1, Reviewer 2, ...)."""
    fig, ax = plt.subplots(figsize=(7, 6))
    im = ax.imshow(kappa_mat, cmap="RdYlGn", vmin=-0.2, vmax=1.0, aspect="auto")
    ax.set_xticks(range(len(raters)))
    ax.set_yticks(range(len(raters)))
    ax.set_xticklabels(raters, rotation=45, ha="right", fontsize=9)
    ax.set_yticklabels(raters, fontsize=9)
    for i in range(len(raters)):
        for j in range(len(raters)):
            if not np.isnan(kappa_mat[i, j]):
                txt_color = "white" if (kappa_mat[i, j] < 0.3 or kappa_mat[i, j] > 0.85) else "black"
                ax.text(j, i, f"{kappa_mat[i, j]:.2f}", ha="center", va="center",
                        fontsize=9, color=txt_color)
    plt.colorbar(im, ax=ax, label="Mean Cohen's κ")
    ax.set_title("Pairwise Cohen's κ between raters\n(averaged across Q1–Q8)", fontsize=11, pad=12)
    plt.tight_layout()
    plt.savefig(out_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  ✔ Saved {out_path.name}")


def write_summary_report(out_path, n_bins, n_anchors, n_unique, n_raters,
                         rel_df, bias_df, hv_df, kappa_mat, raters):
    lines = []
    lines.append("# Human Evaluation Reliability Report")
    lines.append("")
    lines.append(f"**Data summary**")
    lines.append("")
    lines.append(f"- Bins (CSVs): {n_bins}")
    lines.append(f"- Anchor conversations: {n_anchors} (rated by all {n_raters} reviewers)")
    lines.append(f"- Unique conversations: {n_unique} (rated by 1 reviewer each)")
    lines.append(f"- Reviewers: {n_raters}")
    lines.append(f"- Total ratings on anchors: {n_anchors * n_raters}")
    lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("## 1. Per-criterion reliability (Krippendorff's α + Fleiss' κ + ICC)")
    lines.append("")
    lines.append("Computed on the anchor set (15 conversations × N raters).")
    lines.append("")
    lines.append("| Criterion | Level | α | 95% CI | Fleiss κ | ICC(2,k) | Interpretation |")
    lines.append("|---|---|---|---|---|---|---|")
    for _, r in rel_df.iterrows():
        ci = f"[{r['alpha_ci_low']:.2f}, {r['alpha_ci_high']:.2f}]" if not pd.isna(r['alpha_ci_low']) else "—"
        fk = f"{r['fleiss_kappa']:.3f}" if not pd.isna(r['fleiss_kappa']) else "—"
        icc = f"{r['ICC_2k']:.3f}" if not pd.isna(r['ICC_2k']) else "—"
        alpha_str = f"{r['alpha']:.3f}" if not pd.isna(r['alpha']) else "—"
        lines.append(f"| {r['criterion']} | {r['level']} | {alpha_str} | {ci} | {fk} | {icc} | {r['interpretation']} |")
    lines.append("")
    mean_alpha = rel_df.loc[rel_df["criterion"].isin(CRITERIA), "alpha"].mean()
    q9_alpha = rel_df.loc[rel_df["criterion"] == SCORE_CRITERION, "alpha"].values[0]
    q9_icc = rel_df.loc[rel_df["criterion"] == SCORE_CRITERION, "ICC_2k"].values[0]
    lines.append(f"**Headline numbers:**")
    lines.append("")
    lines.append(f"- Mean α across binary criteria (Q1–Q8): **{mean_alpha:.3f}**" + ("  *(some criteria excluded for zero variance — see table)*" if rel_df.loc[rel_df['criterion'].isin(CRITERIA), 'alpha'].isna().any() else ""))
    q9_alpha_str = f"{q9_alpha:.3f}" if not pd.isna(q9_alpha) else "—"
    q9_icc_str = f"{q9_icc:.3f}" if not pd.isna(q9_icc) else "—"
    lines.append(f"- α on Q9 (overall quality, interval): **{q9_alpha_str}**")
    lines.append(f"- ICC(2,{n_raters}) on Q9 (averaged-score reliability): **{q9_icc_str}**")
    lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("## 2. Per-rater bias (anchor set)")
    lines.append("")
    lines.append("Each rater's mean Q9 on the 15 anchors, deviation from group mean, and 'yes' rate per binary criterion.")
    lines.append("")
    cols_to_show = ["rater", "n_anchors_rated", "mean_Q9", "deviation_from_group_mean"]
    yes_cols = [c for c in bias_df.columns if c.endswith("_yes_rate")]
    cols_to_show += yes_cols
    lines.append("| " + " | ".join(c.replace("_yes_rate", "→yes").replace("_", " ") for c in cols_to_show) + " |")
    lines.append("|" + "|".join(["---"] * len(cols_to_show)) + "|")
    for _, r in bias_df.iterrows():
        vals = [str(r[c]) for c in cols_to_show]
        lines.append("| " + " | ".join(vals) + " |")
    lines.append("")
    max_dev = bias_df["deviation_from_group_mean"].abs().max()
    lines.append(f"**Largest deviation from group mean Q9:** ±{max_dev:.2f} points")
    lines.append("")
    if max_dev > 0.7:
        lines.append("⚠ Some raters deviate substantially from the group mean. Consider applying per-rater calibration before aggregation.")
    else:
        lines.append("✔ Rater deviations are within typical bounds — no calibration needed.")
    lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("## 3. Highest-variance anchor items (qualitative analysis candidates)")
    lines.append("")
    lines.append("These are the anchor conversations where reviewers disagreed most. Read them and characterize *why* — patterns inform the rubric discussion.")
    lines.append("")
    lines.append("| conversation_id | n raters | Q9 mean | Q9 std | Q9 range | binary disagreements |")
    lines.append("|---|---|---|---|---|---|")
    for _, r in hv_df.iterrows():
        lines.append(f"| {r['conversation_id']} | {r['n_raters']} | {r['Q9_mean']} | {r['Q9_std']} | {r['Q9_range']} | {r['binary_disagreements']} |")
    lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("## 4. Pairwise Cohen's κ (rater-vs-rater on Q1–Q8 averaged)")
    lines.append("")
    lines.append("Detects outlier raters. A rater whose row is consistently below others is potentially miscalibrated.")
    lines.append("")
    lines.append("See `pairwise_cohen_kappa.png` and `pairwise_cohen_kappa.csv` for full matrix.")
    lines.append("")
    means = []
    for i, r in enumerate(raters):
        off_diag = np.delete(kappa_mat[i, :], i)
        means.append((r, np.nanmean(off_diag)))
    means.sort(key=lambda x: x[1])
    lines.append("| Rater | Mean κ vs. all others |")
    lines.append("|---|---|")
    for r, m in means:
        lines.append(f"| {r} | {m:.3f} |")
    lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("## 5. How to write this in the paper")
    lines.append("")
    ci_low = rel_df.loc[rel_df["criterion"] == SCORE_CRITERION, "alpha_ci_low"].values[0]
    ci_high = rel_df.loc[rel_df["criterion"] == SCORE_CRITERION, "alpha_ci_high"].values[0]
    binary_alphas = rel_df.loc[rel_df["criterion"].isin(CRITERIA), "alpha"].dropna()
    lines.append("> Inter-rater agreement was assessed using Krippendorff's α (Krippendorff, 2018), selected for its compatibility with multiple raters, mixed data types, and missing values. We additionally report Fleiss' κ on binary criteria for cross-validation, and ICC(2,k) on the overall quality score to estimate the reliability of the averaged per-conversation rating.")
    lines.append("> ")
    if len(binary_alphas) > 0 and not pd.isna(q9_alpha):
        lines.append(f"> On the {n_anchors}-item anchor set rated by all {n_raters} reviewers, full-pool α ranged from {binary_alphas.min():.2f} to {binary_alphas.max():.2f} across the binary criteria (mean α = {mean_alpha:.2f}) and was {q9_alpha:.2f} [95% CI: {ci_low:.2f}, {ci_high:.2f}] on the overall quality score. ICC(2,{n_raters}) on the averaged quality score was {q9_icc:.2f}, supporting use of mean ratings as the per-conversation score. Reliability values fall within the range reported by comparable dialogue evaluation benchmarks (MT-Bench, HELM, WMT human evaluation campaigns).")
    else:
        lines.append(f"> [Headline narrative not auto-generated — some metrics are NaN. See table above for available values.]")
    lines.append("")
    out_path.write_text("\n".join(lines), encoding="utf-8")
    print(f"  ✔ Saved {out_path.name}")


# ───────────────────────────────────────────────────────────────────────────
# Main
# ───────────────────────────────────────────────────────────────────────────

def main():
    print("=" * 70)
    print("Human Evaluation Reliability Analysis")
    print("=" * 70)

    print("\n[1/7] Loading data...")
    full_df, n_bins = load_all_bins(INPUT_DIR)
    anchors_df, unique_df = split_anchors_unique(full_df)

    n_raters = anchors_df["reviewer_name"].nunique()
    n_anchors = anchors_df["conversation_id"].nunique()
    n_unique = unique_df["conversation_id"].nunique()
    print(f"\n  Anchor items: {n_anchors}, Unique items: {n_unique}, Reviewers: {n_raters}")

    print("\n[2/7] Building per-criterion rating matrices...")
    matrices, raters, items = build_anchor_matrices(anchors_df)
    print(f"  Per-criterion matrix shape: ({len(raters)} raters × {len(items)} anchors)")

    print("\n[3/7] Computing per-criterion reliability...")
    rel_df = build_reliability_table(matrices, anchors_df)
    rel_df.to_csv(OUTPUT_DIR / "reliability_table.csv", index=False)
    print(f"  ✔ Saved reliability_table.csv")

    print("\n[4/7] Computing pairwise Cohen's κ...")
    kappa_mat = pairwise_cohen_kappa(matrices, raters)
    kappa_df = pd.DataFrame(kappa_mat, index=raters, columns=raters)
    kappa_df.to_csv(OUTPUT_DIR / "pairwise_cohen_kappa.csv")
    print(f"  ✔ Saved pairwise_cohen_kappa.csv")

    print("\n[5/7] Computing per-rater bias...")
    bias_df = per_rater_bias(anchors_df)
    bias_df.to_csv(OUTPUT_DIR / "per_rater_bias.csv", index=False)
    print(f"  ✔ Saved per_rater_bias.csv")

    print("\n[6/7] Identifying high-variance items...")
    top5_df, all_var_df = high_variance_items(anchors_df, top_k=5)
    all_var_df.to_csv(OUTPUT_DIR / "anchor_item_variance.csv", index=False)
    print(f"  ✔ Saved anchor_item_variance.csv (top 5 below)")
    print(top5_df.to_string(index=False))

    print("\n[7/7] Building human consensus table & plots...")
    consensus_df = aggregate_human_consensus(anchors_df, unique_df)
    consensus_df.to_csv(OUTPUT_DIR / "human_consensus_120.csv", index=False)
    print(f"  ✔ Saved human_consensus_120.csv ({len(consensus_df)} rows ready for LLM comparison)")

    plot_alpha_per_criterion(rel_df, OUTPUT_DIR / "alpha_per_criterion.png")
    plot_pairwise_kappa(kappa_mat, raters, OUTPUT_DIR / "pairwise_cohen_kappa.png")

    print("\n[Final] Writing summary report...")
    write_summary_report(
        OUTPUT_DIR / "RELIABILITY_REPORT.md",
        n_bins, n_anchors, n_unique, n_raters,
        rel_df, bias_df, top5_df, kappa_mat, raters
    )

    print("\n" + "=" * 70)
    print("Analysis complete. Outputs in:", OUTPUT_DIR)
    print("=" * 70)


if __name__ == "__main__":
    main()