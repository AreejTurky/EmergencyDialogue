"""
Judge 5: Mistral (Mistral AI, France)
=======================================

European multilingual model — provides bias decorrelation from US (Llama),
Chinese (Qwen), and Gulf (ALLaM, Jais) judges.

Default: mistralai/Mistral-Small-24B-Instruct-2501 (~48GB bf16, ~24GB fp16)

For smaller GPUs (single 32GB V100): mistralai/Mistral-7B-Instruct-v0.3 (~14GB)

Override:
    MISTRAL_MODEL=mistralai/Mistral-7B-Instruct-v0.3 python judge_mistral.py

Dtype:
    Set JUDGE_DTYPE=float16 on V100/T4. Default bfloat16 for Ampere+.

Note: We do NOT pass fix_mistral_regex=True — that flag has a known issue
where it causes BPE byte symbols (Ġ, Ċ) to leak through decode(). The
tokenizer warning that appears at load time is harmless.

Output: judge_outputs/judge_Mistral.csv
"""
import os
from judge_common import TransformersJudge, run_judge

JUDGE_NAME = "Mistral"
MODEL_ID = os.getenv("MISTRAL_MODEL", "mistralai/Mistral-Small-24B-Instruct-2501")


def main():
    with TransformersJudge(MODEL_ID) as judge:
        run_judge(JUDGE_NAME, judge.call)


if __name__ == "__main__":
    main()
