#!/bin/bash
#SBATCH --job-name=llm_judges
#SBATCH --partition=THK_V100
#SBATCH --gres=gpu:8
#SBATCH --nodes=1
#SBATCH --nodelist=mlqhpc-v100-node27
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=16
#SBATCH --time=7-00:00:00
#SBATCH --output=logs/llm_judges_%j.out





# ─────────────────────────────────────────────────────────────────────────
# 911 Dispatcher Evaluation — LLM Judge Pipeline (SLURM)
# ─────────────────────────────────────────────────────────────────────────
# Adjust the SBATCH lines above for your cluster, then submit with:
#     sbatch run_all_judges.slurm
# Watch progress with:
#     tail -f logs/llm_judges_<JOBID>.out
# ─────────────────────────────────────────────────────────────────────────

set -euo pipefail

mkdir -p logs

echo "Job started: $(date)"
echo "Node: $(hostname)"
echo "GPUs visible: ${CUDA_VISIBLE_DEVICES:-none}"
echo ""

# Activate your environment
# Choose ONE of these patterns based on your cluster's setup:

# Option A — conda
# module load anaconda3
# conda activate llm-judges

# Option B — virtualenv
# source ~/envs/llm-judges/bin/activate

# Option C — module + pip user-install (already installed)
# module load python/3.11 cuda/12.4

# Make sure your environment has:
#   pip install -r requirements.txt
#   pip install accelerate  # for device_map="auto"

# ─────────────────────────────────────────────────────────────────────────
# Optional: HuggingFace setup
# ─────────────────────────────────────────────────────────────────────────
# Llama 3.3 requires you to accept the Meta license on HF and have a token.
# Set HF_TOKEN as an environment variable or run `huggingface-cli login` once.
# Cache models to a shared scratch dir to avoid re-downloading:
export HF_HOME="${SCRATCH:-$HOME}/hf_cache"
mkdir -p "$HF_HOME"

export HF_TOKEN=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

# ─────────────────────────────────────────────────────────────────────────
# Run the pipeline
# ─────────────────────────────────────────────────────────────────────────
echo "Starting pipeline at $(date)"
python run_all_judges.py --only Mistral Qwen3 Llama33

echo ""
echo "Job finished: $(date)"
echo "Output CSVs:"
ls -la judge_outputs/
