# 911 Agent Dataset Pipeline

This repository contains the data curation pipeline used to construct the 911 Agent dataset (EmergencyDialogue-Real) — a curated collection of real 911 emergency call transcripts in English and translated to Arabic, designed for evaluating LLM-based dispatcher agents.

## Dataset Overview

Each entry in the final dataset represents a single 911 call and contains:

- `file_name` — unique call identifier
- `dialogue` — list of turns with `role` (`user`/`assistant`) and `content` fields
- `transcription_metadata` — incident category, incident type, dialogue quality (1–5), and completeness
- `translation` — Arabic translation of the full dialogue
- `summary` — 2-sentence English summary of the incident

Arabic translations follow role-based dialect rules: dispatcher turns use Modern Standard Arabic (فصحى); caller turns use Saudi Arabic dialect (عامية سعودية). US place names are localized to Saudi equivalents.

## Pre-Pipeline Utility

Before running the pipeline, raw recordings must be partitioned by duration using `split_by_duration.py`. Recordings within the threshold are treated as single calls; longer recordings are multi-call compilations that require segmentation (Step 7).

```bash
python code/pipeline/split_by_duration.py \
  --input_dir  path/to/raw_mp3s \
  --normal_dir path/to/single_calls \
  --large_dir  path/to/compilations \
  --threshold_minutes 10
```

This writes the files into two separate directories and produces a `manifest.csv` in each with file names and durations. The pipeline then runs on `single_calls/`; `compilations/` is processed after Step 5 via Step 7.

> **Note:** Duration reading uses `mutagen` (no system dependency). `pydub` is listed as a fallback for unusual formats and requires [ffmpeg](https://ffmpeg.org/) on `PATH` only if mutagen fails.

## Pipeline Architecture

The pipeline processes raw audio through 7 sequential steps:

```
MP3 audio files (split by duration — see Pre-Pipeline Utility above)
      │
      ▼
Step 1: transcribe_only.py       — Transcribe audio → speaker-labeled text (Gemini)
      │
      ▼
Step 2: extract_quality.py       — Extract quality metadata per transcript (Gemini)
      │
      ▼
Step 3.1: proofread_transcripts.py — Identify high-confidence STT errors (Gemini)
Step 3.2: combine_changes.py       — Apply accepted corrections
      │
      ▼
Step 4: clean_dialogue.py        — Remove system/sound-only turns, merge consecutive speakers
      │
      ▼
Step 5: translate_transcripts.py — Translate English → Arabic with dialect rules (GPT)
      │
      ▼
Step 6: filter_dialogues.py      — Classify dialogues as suitable/not-suitable (GPT)
      │
      ▼
Step 7: process_compilations.py  — Segment multi-call compilations into individual calls (GPT)
      │
      ▼
extract_incident_summaries.py    — Generate 2-sentence English summaries (GPT)
```

Steps 1–4 use the **Google Gemini API**. Steps 5–7 and summary extraction use the **Azure OpenAI API** (GPT).

All steps support **resume**: already-processed files are skipped automatically. Steps 1–3 also support **API token rotation** across multiple Gemini accounts to stay within rate limits.

## Setup

### 1. Clone the repository

```bash
git clone <repo-url>
cd 911_agent
```

### 2. Install dependencies

```bash
conda create -n 911-pipeline python=3.11 -y
conda activate 911-pipeline
pip install -r requirements.txt
```

### 3. Configure API keys

Copy `.env.example` to `.env` at the repo root and fill in your credentials:

```bash
cp .env.example .env
```

```dotenv
# Gemini API keys (Steps 1–4: transcription, proofreading, metadata)
# Comma-separated. Multiple keys enable automatic rotation across quota limits.
GEMINI_API_TOKENS=your_gemini_key_1,your_gemini_key_2

# Azure OpenAI (Steps 5–7: translation, filtering, segmentation, summaries)
AZURE_OPENAI_API_KEY=your_azure_openai_key
AZURE_OPENAI_BASE_URL=https://your-resource.cognitiveservices.azure.com/openai/v1/
```

The `.env` file is loaded automatically by every pipeline script and is listed in `.gitignore` so it is never committed.

## Running the Pipeline

All scripts are in `code/pipeline/`. Run them from the repo root. Each step reads from a previous step's output directory.

### Pre-pipeline — Split recordings by duration

```bash
python code/pipeline/split_by_duration.py \
  --input_dir         path/to/raw_mp3s \
  --normal_dir        path/to/single_calls \
  --large_dir         path/to/compilations \
  --threshold_minutes 10
```

Run the pipeline steps below on `single_calls/`. The `compilations/` directory feeds into Step 7 after Step 5.

### Step 1 — Transcribe audio

```bash
python code/pipeline/transcribe_only.py \
  --input_dir  path/to/mp3_files \
  --output_dir path/to/transcriptions
```

### Step 2 — Extract quality metadata

```bash
python code/pipeline/extract_quality.py \
  --input_dir  path/to/transcriptions \
  --output_dir path/to/metadata
```

### Step 3.1 — Proofread transcripts

```bash
python code/pipeline/proofread_transcripts.py \
  --input_dir  path/to/transcriptions \
  --output_dir path/to/proofread_results
```

### Step 3.2 — Apply corrections

```bash
python code/pipeline/combine_changes.py \
  --transcripts path/to/transcriptions \
  --notes       path/to/proofread_results \
  --output      path/to/combined
```

### Step 4 — Clean dialogue

```bash
python code/pipeline/clean_dialogue.py \
  --input  path/to/combined \
  --output path/to/cleaned
```

### Step 5 — Translate to Arabic

```bash
python code/pipeline/translate_transcripts.py \
  --input_dir  path/to/cleaned \
  --output_dir path/to/arabic_translations \
  --translate_model gpt-4o
```

### Step 6 — Filter dialogues

```bash
python code/pipeline/filter_dialogues.py \
  --input_dir  path/to/arabic_translations \
  --output_dir path/to/classifications \
  --model_name gpt-4o
```

### Step 7 — Process compilations

```bash
python code/pipeline/process_compilations.py \
  --input_dir      path/to/classifications \
  --transcript_dir path/to/arabic_translations \
  --output_dir     path/to/segmented_compilations
```

### Extract summaries

```bash
python code/pipeline/extract_incident_summaries.py \
  --input-dir  path/to/final_dataset \
  --output-dir path/to/summaries
```

## Command-line Arguments

Each script accepts `--help` for a full list of arguments. Key shared arguments:

| Argument | Default | Description |
|---|---|---|
| `--sleep_seconds` | 2–6 | Seconds to wait between API calls |
| `--files_per_token` | 100 | Files per Gemini token before rotation |
| `--temperature` | 0.1–0.2 | Sampling temperature |

## Output Format

Each pipeline step saves one JSON file per call. The final dataset entry structure:

```json
{
  "file_name": "call_123",
  "dialogue": [
    {"role": "assistant", "content": "911, what is your emergency?"},
    {"role": "user",      "content": "There's been an accident on the highway."}
  ],
  "transcription_metadata": {
    "incident_category": "Police",
    "incident_type": "traffic accident",
    "dialogue_quality": "4",
    "dialogue_completeness": "complete"
  },
  "translation": "DISPATCHER: ...\nCALLER: ...",
  "summary": "A two-car collision was reported on King Fahd Road. The caller requested immediate police and medical assistance."
}
```

## Ethical Considerations

The audio recordings used to build this dataset are sourced from publicly available 911 call recordings released under open licenses. The dataset is intended solely for research purposes — specifically, for training and evaluating LLM-based emergency dispatch agents. No personally identifiable information is retained in the final dataset. US-based place names are replaced with Saudi equivalents during translation.

## Dependencies

| Package | Purpose |
|---|---|
| `mutagen` | Audio duration reading without ffmpeg (pre-pipeline utility) |
| `pydub` | Fallback audio reader (pre-pipeline utility; requires ffmpeg on PATH) |
| `google-genai` | Gemini API client (transcription, proofreading, metadata) |
| `openai` | Azure OpenAI client (translation, filtering, segmentation) |
| `python-dotenv` | Loads `.env` credentials into environment variables |
| `tqdm` | Progress bars |
| `pandas` | Data handling |
| `numpy` | Numerical utilities |
