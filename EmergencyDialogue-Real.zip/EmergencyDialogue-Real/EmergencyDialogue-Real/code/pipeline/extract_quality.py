"""
Pipeline Step 2: Extract quality metadata.

Brief: Reads transcripts and produces structured quality-related metadata
(incident category/type, dialogue quality and completeness) into separate
`*_metadata.json` files.
"""

import os
import argparse
import time
from typing import Dict, Any, List

from tqdm import tqdm

from utils import (
    load_api_tokens,
    build_client,
    extract_metadata_from_transcript,
    list_json_files,
    load_json_file,
    save_metadata_to_json,
    load_existing_metadata_results,
    get_failed_metadata_files,
)


METADATA_SYSTEM_PROMPT = """
You are an analyst extracting structured metadata about quality of 911 call transcripts. Read the transcript and respond with STRICT JSON matching the schema below. Do not include any prose outside JSON.

Return JSON with these keys:
- incident_category: string (e.g., Police, Fire, Ambulance)
- incident_type: string (e.g., medical emergency, domestic disturbance, traffic accident, fire, burglary)
- dialogue_quality_reason: string (in short, explain whether the dialogue is suitable for an LLM to understand and respond if it was in place of the dispatcher, and that if flow is logical, or there is something looks missing from the transcript, or speaker label is mistaken)
- dialogue_quality: string (dialogue quality score based on dialogue_quality_reason [from 1 to 5, 5 is the highest quality])
- dialogue_completeness: string (one of: complete, partial, fragmentary)

Rules:
- If uncertain, make best-effort estimates rather than leaving fields empty.
- Do not include any keys other than those specified.
"""


def run_metadata_extraction_pipeline(
    input_dir: str,
    output_dir: str,
    api_tokens: List[str],
    metadata_model: str,
    temperature: float = 0.1,
    sleep_seconds: float = 2,
    files_per_token: int = 100,
) -> None:
    if not api_tokens:
        raise RuntimeError("No API tokens provided")

    current_token_index = 0
    client = build_client(api_tokens[current_token_index])
    files_processed_with_current_token = 0
    transcription_files = list_json_files(input_dir)

    if not transcription_files:
        print(f"No .json transcription files found in {input_dir}")
        return

    existing_results = load_existing_metadata_results(output_dir)
    failed_files = get_failed_metadata_files(existing_results)

    print(f"Found {len(failed_files)} failed metadata extractions to retry")
    print(f"Found {len(transcription_files)} total transcription files")

    existing_file_names = set(existing_results.keys())
    all_file_names = {os.path.basename(path).replace('.json', '') for path in transcription_files}
    files_to_process = all_file_names - (existing_file_names - failed_files)
    remaining_paths = [path for path in transcription_files if os.path.basename(path).replace('.json', '') in files_to_process]

    if not remaining_paths:
        print("All files have already been processed for metadata extraction!")
        return

    print(f"Remaining files to process: {len(remaining_paths)}")

    pbar = tqdm(remaining_paths, desc="Extracting metadata", unit="file")
    successful_count = 0
    error_count = 0

    for transcription_path in pbar:
        file_name = os.path.basename(transcription_path).replace('.json', '')
        pbar.set_description(f"Processing {file_name} (Token {current_token_index + 1}/{len(api_tokens)})")

        if files_processed_with_current_token >= files_per_token:
            current_token_index = (current_token_index + 1) % len(api_tokens)
            client = build_client(api_tokens[current_token_index])
            files_processed_with_current_token = 0
            print(f"\nSwitched to API token {current_token_index + 1}/{len(api_tokens)}")

        transcription_data = load_json_file(transcription_path)
        if not transcription_data:
            print(f"ERROR: Could not load transcription for {file_name}")
            error_count += 1
            continue

        transcript_text = transcription_data.get('transcribe_output', '')
        if not transcript_text or transcript_text.startswith('ERROR:'):
            print(f"ERROR: Invalid transcript for {file_name}")
            error_count += 1
            continue

        try:
            metadata = extract_metadata_from_transcript(client, metadata_model, transcript_text, METADATA_SYSTEM_PROMPT, temperature)
        except Exception as e:
            print(f"ERROR: {e} for {file_name}")
            metadata = {"metadata_error": str(e)}

        result = {
            "file_name": file_name,
            "transcript_file": os.path.basename(transcription_path),
            "metadata_model": metadata_model,
            **metadata,
        }

        save_metadata_to_json(output_dir, file_name, result)

        if 'metadata_error' in metadata:
            error_count += 1
        else:
            successful_count += 1

        files_processed_with_current_token += 1
        time.sleep(sleep_seconds)

    pbar.close()

    print(f"\nSummary:")
    print(f"  Total files processed: {len(existing_results) + len(remaining_paths)}")
    print(f"  Successful metadata extractions: {successful_count}")
    print(f"  Errors: {error_count}")
    print(f"  Results saved to: {output_dir}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Metadata extraction pipeline for existing transcriptions")
    parser.add_argument("--input_dir", type=str, required=True, help="Directory containing transcription JSON files")
    parser.add_argument("--output_dir", type=str, default="metadata_results", help="Directory to save metadata JSON results")
    parser.add_argument("--metadata_model", type=str, default="gemini-2.5-flash", help="Model name for metadata extraction step")
    parser.add_argument("--temperature", type=float, default=0.1, help="Decoding temperature for metadata extraction")
    parser.add_argument("--sleep_seconds", type=float, default=2, help="Sleep between API calls to avoid rate limits")
    parser.add_argument("--files_per_token", type=int, default=100, help="Number of files to process before switching API token")
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()

    api_tokens = load_api_tokens()
    if not api_tokens:
        raise RuntimeError("GEMINI_API_TOKENS is not set. Add it to your .env file.")

    run_metadata_extraction_pipeline(
        input_dir=args.input_dir,
        output_dir=args.output_dir,
        api_tokens=api_tokens,
        metadata_model=args.metadata_model,
        temperature=args.temperature,
        sleep_seconds=args.sleep_seconds,
        files_per_token=args.files_per_token,
    )
