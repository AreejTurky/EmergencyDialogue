"""
Pipeline Step 6: Classify translated dialogues for suitability.

Brief: Uses an LLM to label each Arabic translation as
"suitable"/"not-suitable" for benchmarking and optionally tag reasons (e.g.,
"compilation"). Saves the raw model output per file.
"""

import os
import argparse
import time
from pathlib import Path
from typing import Dict, Any, List, Set

from dotenv import load_dotenv
from tqdm import tqdm

load_dotenv(Path(__file__).resolve().parents[2] / ".env")

from utils import (
    build_client,
    list_json_files,
    load_json_file,
    save_result_to_json,
    load_existing_results,
    translate_transcript_gpt5,
)


SYSTEM_PROMPT = """Developer: Role: AI developer evaluating transcribed Arabic 911 call dialogues for inclusion as benchmark data for LLMs simulating 911 dispatchers.

Instructions:
- For each input dialogue, assess suitability based on these criteria:
  1. Mark as "not-suitable" if the dialogue is a compilation of multiple calls, as suggested by the flow.
  2. Exclude if the context is inappropriate (e.g., misuse of 911 services, implausible scenarios).
  3. Exclude if the dispatcher acts uncharacteristically or inappropriately, or if the interaction is a poor example of 911 behavior.
  4. Exclude for any other compelling reason; clearly justify such exclusions.

- After evaluation, validate that your output matches the required format and that exclusions have clear reasons. If validation fails, self-correct as needed.

Output Format:
- For each dialogue, return a single JSON object with:
  - "label": "suitable" or "not-suitable"
  - "reason": Brief justification for the label
  - "type" (optional): Reason type if "not-suitable" (e.g., "dispatcher behaviour", "compilation", "out of context"); "None" if "suitable"
- If the input is empty or malformed, respond with: {"label": "not-suitable", "reason": "Input dialogue is empty or malformed", "type": "input error"}

Example:
Input dialogue:
  Dispatcher: hello 911 here
  Caller: I want you to help me fix my car's tires. I am on the side of the road
  Dispatcher: sir, we are not a maintenance workshop
Output:
  {"label": "not-suitable", "reason": "The dispatcher is rude", "type": "Dispatcher behaviour"}
"""


def get_failed_filtration_files(existing_results: Dict[str, Dict[str, Any]]) -> Set[str]:
    """Return file names that failed filtration or have no output field."""
    failed = set()
    for file_name, result in existing_results.items():
        if 'error' in result or 'output' not in result:
            failed.add(file_name)
    return failed


def run_filtration_pipeline(
    input_dir: str,
    output_dir: str,
    api_key: str,
    model_name: str,
    sleep_seconds: float = 6,
) -> None:
    client = build_client(api_key, model_name=model_name)

    transcription_files = list_json_files(input_dir)
    if not transcription_files:
        print(f"No .json transcription files found in {input_dir}")
        return

    existing_results = load_existing_results(output_dir)
    failed_files = get_failed_filtration_files(existing_results)

    print(f"Found {len(failed_files)} failed filtration files to retry")
    print(f"Found {len(transcription_files)} total translation files")

    existing_file_names = set(existing_results.keys())
    all_file_names = {os.path.basename(path).replace('.json', '') for path in transcription_files}
    files_to_process = all_file_names - (existing_file_names - failed_files)
    remaining_paths = [
        path for path in transcription_files
        if os.path.basename(path).replace('.json', '') in files_to_process
    ]

    if not remaining_paths:
        print("All files have already been filtered!")
        return

    print(f"Remaining files to filter: {len(remaining_paths)}")

    pbar = tqdm(remaining_paths, desc="Filtering dialogues", unit="file")
    successful_count = 0
    error_count = 0

    for transcription_path in pbar:
        file_name = os.path.basename(transcription_path).replace('.json', '')
        pbar.set_description(f"Filtering {file_name}")

        transcription_data = load_json_file(transcription_path)
        if not transcription_data:
            print(f"ERROR: Could not load file for {file_name}")
            save_result_to_json(output_dir, file_name, {
                "file_name": file_name,
                "translation_file": os.path.basename(transcription_path),
                "filtering_model": model_name,
                "error": "Could not load transcription JSON",
            })
            error_count += 1
            time.sleep(sleep_seconds)
            continue

        transcript_text = transcription_data.get('translation_output', '')
        if not transcript_text or (isinstance(transcript_text, str) and transcript_text.startswith('ERROR:')):
            print(f"ERROR: Invalid transcript for {file_name}")
            save_result_to_json(output_dir, file_name, {
                "file_name": file_name,
                "translation_file": os.path.basename(transcription_path),
                "filtering_model": model_name,
                "error": "Invalid or empty translation_output",
            })
            error_count += 1
            time.sleep(sleep_seconds)
            continue

        try:
            output = translate_transcript_gpt5(
                client=client,
                deployment_name=model_name,
                english_transcript=transcript_text,
                system_prompt=SYSTEM_PROMPT,
            )
            if not output or output.strip() == "":
                raise RuntimeError("Empty response from API")
            filtration_result: Dict[str, Any] = {"output": output}
        except Exception as e:
            print(f"ERROR: {e} for {file_name}")
            filtration_result = {"error": str(e)}

        result = {
            "file_name": file_name,
            "translation_file": os.path.basename(transcription_path),
            "filtering_model": model_name,
            **filtration_result,
        }
        save_result_to_json(output_dir, file_name, result)

        if 'error' in filtration_result:
            error_count += 1
        else:
            successful_count += 1

        time.sleep(sleep_seconds)

    pbar.close()

    total_files = len(load_existing_results(output_dir))
    print(f"\nSummary:")
    print(f"  Total files processed: {total_files}")
    print(f"  Successful filtrations: {successful_count}")
    print(f"  Errors: {error_count}")
    print(f"  Results saved to: {output_dir}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Filter 911 dialogues based on LLM suitability assessment")
    parser.add_argument("--input_dir", type=str, required=True, help="Directory containing Arabic translation JSON files")
    parser.add_argument("--output_dir", type=str, required=True, help="Directory to save filtration results")
    parser.add_argument("--model_name", type=str, default="gpt-4o", help="Model deployment name for filtration")
    parser.add_argument("--sleep_seconds", type=float, default=6, help="Sleep between API calls to avoid rate limits")
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()

    api_key = os.environ.get("AZURE_OPENAI_API_KEY", "")
    if not api_key:
        raise RuntimeError("AZURE_OPENAI_API_KEY is not set. Add it to your .env file.")

    run_filtration_pipeline(
        input_dir=args.input_dir,
        output_dir=args.output_dir,
        api_key=api_key,
        model_name=args.model_name,
        sleep_seconds=args.sleep_seconds,
    )
