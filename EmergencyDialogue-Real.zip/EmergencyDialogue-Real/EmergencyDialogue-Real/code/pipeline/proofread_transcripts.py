"""
Pipeline Step 3.1: Proofread transcripts and propose fixes.

Brief: Reviews `transcribe_output` text and returns a JSON list of high-
confidence, context-based correction suggestions (no grammar fixes). Pairs with
the combine step to apply accepted changes.
"""

import os
import json
import argparse
import time
from typing import Dict, Any, List, Set

from tqdm import tqdm
from google.genai import types

from utils import (
    load_api_tokens,
    build_client,
    list_json_files,
    load_json_file,
    save_result_to_json,
    load_existing_results,
    get_failed_files,
)


PROOFREAD_SYSTEM_PROMPT = """You are a proofreader for 911 call transcripts. Your task is to review the following transcript and identify likely speech-to-text transcription errors based on conversational context. The goal is to have cleaner transcript for building an evaluation dataset for 911 agent.

**Instructions:**
1.  Read the entire conversation to understand the context.
2.  Identify words that are phonetically similar to a correct word but don't make sense in the context.
3.  Suggest a correction ONLY if you have very high confidence.
4.  IGNORE GRAMMAR AND PUNCTUATION ERRORS, focus ONLY on the contextual errors.
5.  Ignore minor errors that does not affect the overall meaning of the line.
6.  If the transcript line seems correct, ignore it, only state changes to lines that are clearly wrong.

Provide your output as a list of suggested changes in JSON format. If no changes, return an empty list.

**Example Format:**
[
  {
    "original_phrase": "There's blood on the plant",
    "suggested_correction": "There's blood on the blanket",
    "confidence": "High",
    "reasoning": "The conversation is about a bedroom scene. 'Blanket' is more contextually probable than 'plant'."
  }
]
"""


def proofread_transcript(client, model_name: str, transcript_text: str, system_prompt: str, temperature: float = 0.1) -> Dict[str, Any]:
    """Proofread a transcript using the Gemini API."""
    if not transcript_text or transcript_text.strip() == "":
        return {"proofread_error": "Empty transcript"}

    try:
        response = client.models.generate_content(
            model=model_name,
            contents=transcript_text,
            config=types.GenerateContentConfig(
                system_instruction=system_prompt,
                thinking_config=types.ThinkingConfig(thinking_budget=0),
                temperature=temperature,
            ),
        )

        text = getattr(response, "text", "") or ""

        if not text or text.strip() == "":
            return {"proofread_error": "Empty response from API"}

        cleaned_text = text.strip()

        if cleaned_text.startswith("```json"):
            cleaned_text = cleaned_text[7:]
        elif cleaned_text.startswith("```"):
            cleaned_text = cleaned_text[3:]

        if cleaned_text.endswith("```"):
            cleaned_text = cleaned_text[:-3]

        cleaned_text = cleaned_text.strip()

        try:
            data = json.loads(cleaned_text)
            if isinstance(data, list):
                return {"suggestions": data}
            return {"proofread_raw": text, "proofread_error": "Response is not a valid JSON array"}
        except json.JSONDecodeError as e:
            return {"proofread_raw": text, "proofread_error": f"JSON decode error: {e}"}

    except Exception as e:
        return {"proofread_error": f"API error: {e}"}


def get_failed_proofread_files(existing_results: Dict[str, Dict[str, Any]]) -> Set[str]:
    """Get set of file names that have failed proofreading."""
    failed = set()

    for file_name, result in existing_results.items():
        if 'proofread_error' in result or not any(key.startswith('proofread_') for key in result.keys()):
            failed.add(file_name)

    return failed


def run_proofread_pipeline(
    input_dir: str,
    output_dir: str,
    api_tokens: List[str],
    proofread_model: str,
    temperature: float = 0.1,
    sleep_seconds: float = 2,
    files_per_token: int = 100,
) -> None:
    if not api_tokens:
        raise RuntimeError("No API tokens provided")

    current_token_index = 0
    client = build_client(api_tokens[current_token_index])
    files_processed_with_current_token = 0
    transcription_files = list_json_files(input_dir)

    if not transcription_files:
        print(f"No .json transcription files found in {input_dir}")
        return

    existing_results = load_existing_results(output_dir)
    failed_files = get_failed_proofread_files(existing_results)

    print(f"Found {len(failed_files)} failed proofreading files to retry")
    print(f"Found {len(transcription_files)} total transcription files")

    existing_file_names = set(existing_results.keys())
    all_file_names = {os.path.basename(path).replace('.json', '') for path in transcription_files}
    files_to_process = all_file_names - (existing_file_names - failed_files)
    remaining_paths = [path for path in transcription_files if os.path.basename(path).replace('.json', '') in files_to_process]

    if not remaining_paths:
        print("All files have already been proofread!")
        return

    print(f"Remaining files to proofread: {len(remaining_paths)}")

    pbar = tqdm(remaining_paths, desc="Proofreading transcripts", unit="file")
    successful_count = 0
    error_count = 0

    for transcription_path in pbar:
        file_name = os.path.basename(transcription_path).replace('.json', '')
        pbar.set_description(f"Proofreading {file_name} (Token {current_token_index + 1}/{len(api_tokens)})")

        if files_processed_with_current_token >= files_per_token:
            current_token_index = (current_token_index + 1) % len(api_tokens)
            client = build_client(api_tokens[current_token_index])
            files_processed_with_current_token = 0
            print(f"\nSwitched to API token {current_token_index + 1}/{len(api_tokens)}")

        transcription_data = load_json_file(transcription_path)
        if not transcription_data:
            print(f"ERROR: Could not load transcription for {file_name}")
            error_count += 1
            continue

        transcript_text = transcription_data.get('transcribe_output', '')
        if not transcript_text or transcript_text.startswith('ERROR:'):
            print(f"ERROR: Invalid transcript for {file_name}")
            error_count += 1
            continue

        try:
            proofread_result = proofread_transcript(client, proofread_model, transcript_text, PROOFREAD_SYSTEM_PROMPT, temperature)
        except Exception as e:
            print(f"ERROR: {e} for {file_name}")
            proofread_result = {"proofread_error": str(e)}

        result = {
            "file_name": file_name,
            "transcript_file": os.path.basename(transcription_path),
            "proofread_model": proofread_model,
            **proofread_result,
        }

        save_result_to_json(output_dir, file_name, result)

        if 'proofread_error' in proofread_result:
            error_count += 1
        else:
            successful_count += 1

        files_processed_with_current_token += 1
        time.sleep(sleep_seconds)

    pbar.close()

    print(f"\nSummary:")
    print(f"  Total files processed: {len(existing_results) + len(remaining_paths)}")
    print(f"  Successful proofreading: {successful_count}")
    print(f"  Errors: {error_count}")
    print(f"  Results saved to: {output_dir}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="911 transcript proofreading pipeline with resume capability")
    parser.add_argument("--input_dir", type=str, required=True, help="Directory containing transcription JSON files")
    parser.add_argument("--output_dir", type=str, required=True, help="Directory to save proofread JSON results")
    parser.add_argument("--proofread_model", type=str, default="gemini-2.5-flash", help="Model name for proofreading step")
    parser.add_argument("--temperature", type=float, default=0.1, help="Decoding temperature for proofreading")
    parser.add_argument("--sleep_seconds", type=float, default=2, help="Sleep between API calls to avoid rate limits")
    parser.add_argument("--files_per_token", type=int, default=100, help="Number of files to process before switching API token")
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()

    api_tokens = load_api_tokens()
    if not api_tokens:
        raise RuntimeError("GEMINI_API_TOKENS is not set. Add it to your .env file.")

    run_proofread_pipeline(
        input_dir=args.input_dir,
        output_dir=args.output_dir,
        api_tokens=api_tokens,
        proofread_model=args.proofread_model,
        temperature=args.temperature,
        sleep_seconds=args.sleep_seconds,
        files_per_token=args.files_per_token,
    )
