"""
Pipeline Step 1: Transcribe audio to speaker-labeled text.

Brief: Transcribes .mp3 files into JSON with a line-per-utterance
"SPEAKER: text" format under the key `transcribe_output`. Supports resume,
API token rotation, and basic error handling.
"""

import os
import argparse
import time
from typing import List

from tqdm import tqdm

from utils import (
    load_api_tokens,
    build_client,
    transcribe_file,
    list_audio_files,
    save_result_to_json,
    load_existing_results,
    get_failed_files,
)


TRANSCRIPTION_SYSTEM_PROMPT = """You are an advanced AI audio transcription and speaker diarization service. Your sole purpose is to accurately transcribe the provided audio file of an emergency call while identifying and labeling each distinct speaker.

**Key Instructions:**

1.  **Speaker Identification:**
    *   Assign a unique, consistent label to each speaker detected in the audio: CALLER, DISPATCHER, SYSTEM (if applicable), or a third person if also applicable.
    *   Maintain the same label for the same speaker throughout the entire transcript.

2.  **Output Format:**
    *   Each new utterance or change in speaker must start on a new line.
    *   The format for each line must be: `SPEAKER_LABEL: Transcribed text`
    *   Timestamps are not required.

3.  **Transcription Rules:**
    *   Transcribe the speech verbatim, including filler words (e.g., "um," "uh," "like") as they are spoken.
    *   Use correct capitalization and punctuation (periods, commas, question marks) to reflect the natural flow and pauses of the conversation.
    *   If a word or phrase is unclear or inaudible, use `[unintelligible]`.
    *   Indicate significant non-speech sounds in brackets, such as `[laughter]`, `[applause]`, `[music]`, `[crosstalk]`, or `[phone ringing]`.

**Constraints:**
*   Do not summarize, interpret, or add any information not present in the audio.
*   Do not add any introductory or concluding remarks. Your output should begin directly with the first transcribed line.

**Example Output:**
DISPATCHER: 911, what is your emergency?
CALLER: Hi, um, I need help. There's been a car accident on the highway.
DISPATCHER: What's your location?
CALLER: I'm at mile marker 42 on I-95, there's, uh, two cars involved.

Begin transcription of the provided audio now."""


def run_transcription_pipeline(
    input_dir: str,
    output_dir: str,
    api_tokens: List[str],
    transcribe_model: str,
    temperature: float = 0.2,
    thinking_budget: int = 0,
    sleep_seconds: float = 2,
    files_per_token: int = 100,
) -> None:
    if not api_tokens:
        raise RuntimeError("No API tokens provided")

    current_token_index = 0
    client = build_client(api_tokens[current_token_index])
    files_processed_with_current_token = 0
    audio_paths = list_audio_files(input_dir)

    if not audio_paths:
        print(f"No .mp3 files found in {input_dir}")
        return

    existing_results = load_existing_results(output_dir)
    failed_files = get_failed_files(existing_results)

    print(f"Found {len(failed_files)} failed files to retry")
    print(f"Found {len(audio_paths)} total audio files")

    existing_file_names = set(existing_results.keys())
    all_file_names = {os.path.basename(path) for path in audio_paths}
    files_to_process = all_file_names - (existing_file_names - failed_files)
    remaining_paths = [path for path in audio_paths if os.path.basename(path) in files_to_process]

    if not remaining_paths:
        print("All files have already been transcribed!")
        return

    print(f"Remaining files to transcribe: {len(remaining_paths)}")

    pbar = tqdm(remaining_paths, desc="Transcribing audio files", unit="file")
    successful_count = 0
    error_count = 0

    for audio_path in pbar:
        file_name = os.path.basename(audio_path)
        pbar.set_description(f"Transcribing {file_name} (Token {current_token_index + 1}/{len(api_tokens)})")

        if files_processed_with_current_token >= files_per_token:
            current_token_index = (current_token_index + 1) % len(api_tokens)
            client = build_client(api_tokens[current_token_index])
            files_processed_with_current_token = 0
            print(f"\nSwitched to API token {current_token_index + 1}/{len(api_tokens)}")

        try:
            transcript_text = transcribe_file(client, transcribe_model, audio_path, TRANSCRIPTION_SYSTEM_PROMPT, temperature, thinking_budget)
        except Exception as e:
            print(f"ERROR: {e} for {file_name}")
            transcript_text = f"ERROR: {e}"

        result = {
            "file_name": file_name,
            "transcribe_output": transcript_text,
            "transcribe_model": transcribe_model,
        }

        save_result_to_json(output_dir, file_name, result)

        if transcript_text.startswith('ERROR:'):
            error_count += 1
        else:
            successful_count += 1

        files_processed_with_current_token += 1
        time.sleep(sleep_seconds)

    pbar.close()

    print(f"\nSummary:")
    print(f"  Total files processed: {len(existing_results) + len(remaining_paths)}")
    print(f"  Successful transcriptions: {successful_count}")
    print(f"  Errors: {error_count}")
    print(f"  Results saved to: {output_dir}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="911 audio transcription pipeline with resume capability")
    parser.add_argument("--input_dir", type=str, required=True, help="Directory containing .mp3 files")
    parser.add_argument("--output_dir", type=str, default="transcription_results", help="Directory to save JSON results")
    parser.add_argument("--transcribe_model", type=str, default="gemini-2.5-flash", help="Model name for transcription step")
    parser.add_argument("--temperature", type=float, default=0.2, help="Decoding temperature for transcription")
    parser.add_argument("--thinking_budget", type=int, default=0, help="Thinking budget for transcription (0 to disable)")
    parser.add_argument("--sleep_seconds", type=float, default=2, help="Sleep between API calls to avoid rate limits")
    parser.add_argument("--files_per_token", type=int, default=100, help="Number of files to process before switching API token")
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()

    api_tokens = load_api_tokens()
    if not api_tokens:
        raise RuntimeError("GEMINI_API_TOKENS is not set. Add it to your .env file.")

    run_transcription_pipeline(
        input_dir=args.input_dir,
        output_dir=args.output_dir,
        api_tokens=api_tokens,
        transcribe_model=args.transcribe_model,
        temperature=args.temperature,
        thinking_budget=args.thinking_budget,
        sleep_seconds=args.sleep_seconds,
        files_per_token=args.files_per_token,
    )
