"""
Pipeline Step 4: Clean dialogue text while preserving structure.

Brief: Cleans `transcribe_output` by removing system/sound-only turns,
merging consecutive turns from the same speaker, and reconstructing the
"SPEAKER: text" lines.
"""

import os
import json
import re
import argparse
from pathlib import Path
from typing import List, Dict, Tuple


def load_transcript(file_path: Path) -> Dict:
    """Load a transcript file and return the data."""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (json.JSONDecodeError, FileNotFoundError) as e:
        print(f"Error loading transcript {file_path}: {e}")
        return {}


def parse_conversation_turns(transcribe_output: str) -> List[Tuple[str, str]]:
    """
    Parse the transcribe_output string into conversation turns.
    Returns list of (speaker, text) tuples.
    """
    turns = []

    for line in transcribe_output.split('\n'):
        line = line.strip()
        if not line:
            continue

        if ':' in line:
            speaker_part, text_part = line.split(':', 1)
            speaker = speaker_part.strip()
            text = text_part.strip()
            if text:
                turns.append((speaker, text))
        else:
            turns.append(('Unknown', line))

    return turns


def is_system_turn(speaker: str) -> bool:
    """Check if a turn is from the system (case insensitive)."""
    return speaker.lower() == 'system'


def is_sound_only_turn(text: str) -> bool:
    """
    Check if a turn contains only sounds/descriptions without spoken content.
    Examples: [phone ringing], [crashing], (background noise), etc.
    """
    text = text.strip()

    sound_patterns = [
        r'^\[.*\]$',
        r'^\(.*\)$',
        r'^<.*>$',
        r'^unintelligible.*$',
        r'^\[unintelligible\]$',
        r'^\(.*unintelligible.*\)$',
    ]

    for pattern in sound_patterns:
        if re.match(pattern, text, re.IGNORECASE):
            return True

    return False


def clean_conversation_turns(turns: List[Tuple[str, str]]) -> List[Tuple[str, str]]:
    """Remove system and sound-only turns."""
    cleaned_turns = []

    for speaker, text in turns:
        if is_system_turn(speaker):
            continue
        if is_sound_only_turn(text):
            continue
        cleaned_turns.append((speaker, text))

    return cleaned_turns


def combine_consecutive_speaker_turns(turns: List[Tuple[str, str]]) -> List[Tuple[str, str]]:
    """Combine consecutive turns from the same speaker."""
    if not turns:
        return turns

    combined_turns = []
    current_speaker = turns[0][0]
    current_text = turns[0][1]

    for speaker, text in turns[1:]:
        if speaker == current_speaker:
            current_text += " " + text
        else:
            combined_turns.append((current_speaker, current_text))
            current_speaker = speaker
            current_text = text

    combined_turns.append((current_speaker, current_text))

    return combined_turns


def reconstruct_transcribe_output(turns: List[Tuple[str, str]]) -> str:
    """Reconstruct the transcribe_output string from cleaned turns."""
    return '\n'.join(f"{speaker}: {text}" for speaker, text in turns)


def clean_transcript(transcript_data: Dict) -> Dict:
    """Clean a single transcript by processing its conversation turns."""
    original_text = transcript_data.get('transcribe_output', '')
    if not original_text:
        print("    No transcribe_output found")
        return transcript_data

    turns = parse_conversation_turns(original_text)
    cleaned_turns = clean_conversation_turns(turns)
    combined_turns = combine_consecutive_speaker_turns(cleaned_turns)
    cleaned_text = reconstruct_transcribe_output(combined_turns)

    cleaned_data = transcript_data.copy()
    cleaned_data['transcribe_output'] = cleaned_text

    return cleaned_data


def process_transcripts(input_dir: str, output_dir: str):
    """Process all transcripts in the input directory and save cleaned versions."""
    input_path = Path(input_dir)
    output_path = Path(output_dir)

    output_path.mkdir(parents=True, exist_ok=True)

    transcript_files = list(input_path.glob('*.json'))

    if not transcript_files:
        print(f"No transcript files found in {input_dir}")
        return

    print(f"Found {len(transcript_files)} transcript files")
    print("-" * 50)

    processed_files = 0
    total_original_chars = 0
    total_cleaned_chars = 0

    for transcript_file in transcript_files:
        dialogue_id = transcript_file.stem
        print(f"\nProcessing: {dialogue_id}")

        transcript_data = load_transcript(transcript_file)
        if not transcript_data:
            print(f"  Skipping {dialogue_id} - failed to load")
            continue

        original_length = len(transcript_data.get('transcribe_output', ''))
        total_original_chars += original_length

        cleaned_data = clean_transcript(transcript_data)

        cleaned_length = len(cleaned_data.get('transcribe_output', ''))
        total_cleaned_chars += cleaned_length

        output_file = output_path / f"{dialogue_id}.json"
        try:
            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump(cleaned_data, f, indent=2, ensure_ascii=False)
            print(f"  Saved cleaned transcript to {output_file}")
        except Exception as e:
            print(f"  Error saving {output_file}: {e}")

        processed_files += 1

    print("\n" + "=" * 50)
    print(f"Processing complete!")
    print(f"Files processed: {processed_files}")
    print(f"Original total characters: {total_original_chars:,}")
    print(f"Cleaned total characters: {total_cleaned_chars:,}")
    if total_original_chars > 0:
        reduction_pct = (1 - total_cleaned_chars / total_original_chars) * 100
        print(f"Character reduction: {reduction_pct:.1f}%")
    print(f"Output saved to: {output_path}")


def main():
    parser = argparse.ArgumentParser(description='Clean dialogue transcripts')
    parser.add_argument('--input', required=True, help='Path to input transcripts folder')
    parser.add_argument('--output', required=True, help='Path to output folder')

    args = parser.parse_args()
    process_transcripts(args.input, args.output)


if __name__ == "__main__":
    main()
