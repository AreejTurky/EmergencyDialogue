"""
Pipeline Step 3.2: Apply high-confidence proofreading suggestions.

Brief: Reads original transcripts and proofreading suggestions, applies
only high-confidence replacements, and writes updated JSON preserving
structure. This step pairs with the proofreading step.
"""

import os
import json
import argparse
from pathlib import Path
from typing import Dict, List, Tuple


def load_transcript(file_path: Path) -> Dict:
    """Load a transcript file and return the data."""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (json.JSONDecodeError, FileNotFoundError) as e:
        print(f"Error loading transcript {file_path}: {e}")
        return {}


def load_notes(file_path: Path) -> List[Dict]:
    """Load notes file and return high-confidence suggestions only."""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
            suggestions = data.get('suggestions', [])
            return [s for s in suggestions if s.get('confidence', '').lower() == 'high']
    except (json.JSONDecodeError, FileNotFoundError) as e:
        print(f"Error loading notes {file_path}: {e}")
        return []


def apply_suggestions(transcript_data: Dict, suggestions: List[Dict]) -> Tuple[str, int]:
    """
    Apply suggestions to the transcribe_output text.
    Returns (modified_text, number_of_changes).
    """
    original_text = transcript_data.get('transcribe_output', '')
    modified_text = original_text
    changes_count = 0

    for suggestion in suggestions:
        original_phrase = suggestion.get('original_phrase', '')
        suggested_correction = suggestion.get('suggested_correction', '')

        if original_phrase and original_phrase in modified_text:
            modified_text = modified_text.replace(original_phrase, suggested_correction)
            changes_count += 1

    return modified_text, changes_count


def save_cleaned_dialogue(transcript_data: Dict, modified_text: str, output_path: Path):
    """Save the cleaned dialogue with the same structure as original transcripts."""
    output_data = transcript_data.copy()
    output_data['transcribe_output'] = modified_text

    try:
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(output_data, f, indent=2, ensure_ascii=False)
        print(f"  Saved cleaned dialogue to {output_path}")
    except Exception as e:
        print(f"Error saving {output_path}: {e}")


def process_dialogues(transcripts_dir: str, notes_dir: str, output_dir: str):
    """
    Process all dialogues by applying high-confidence proofreading suggestions.

    Args:
        transcripts_dir: Path to transcripts folder
        notes_dir: Path to notes folder
        output_dir: Path to output folder
    """
    transcripts_path = Path(transcripts_dir)
    notes_path = Path(notes_dir)
    output_path = Path(output_dir)

    output_path.mkdir(parents=True, exist_ok=True)

    transcript_files = list(transcripts_path.glob('*.json'))

    if not transcript_files:
        print(f"No transcript files found in {transcripts_dir}")
        return

    print(f"Found {len(transcript_files)} transcript files")
    print("Only applying suggestions with 'High' confidence")
    print("-" * 50)

    total_changes = 0
    processed_files = 0

    for transcript_file in transcript_files:
        dialogue_id = transcript_file.stem
        print(f"\nProcessing: {dialogue_id}")

        transcript_data = load_transcript(transcript_file)
        if not transcript_data or 'transcribe_output' not in transcript_data:
            print(f"  Skipping {dialogue_id} - no transcribe_output content")
            continue

        notes_file = notes_path / f"{dialogue_id}.json"
        suggestions = []
        if notes_file.exists():
            suggestions = load_notes(notes_file)
        else:
            print(f"  No notes file found for {dialogue_id}")

        modified_text, changes = apply_suggestions(transcript_data, suggestions)
        total_changes += changes

        output_file = output_path / f"{dialogue_id}.json"
        save_cleaned_dialogue(transcript_data, modified_text, output_file)

        processed_files += 1
        original_length = len(transcript_data.get('transcribe_output', ''))
        print(f"  Summary: {original_length} chars, {changes} changes applied")

    print("\n" + "=" * 50)
    print(f"Processing complete!")
    print(f"Files processed: {processed_files}")
    print(f"Total changes applied: {total_changes}")
    print(f"Output saved to: {output_path}")


def main():
    parser = argparse.ArgumentParser(description='Combine dialogue transcripts with suggested changes')
    parser.add_argument('--transcripts', required=True, help='Path to transcripts folder')
    parser.add_argument('--notes', required=True, help='Path to notes folder')
    parser.add_argument('--output', required=True, help='Path to output folder')

    args = parser.parse_args()
    process_dialogues(args.transcripts, args.notes, args.output)


if __name__ == "__main__":
    main()
