"""
Shared Utilities: Clients, I/O helpers, and API wrappers.

Brief: Centralizes token loading, client creation (Gemini/OpenAI), JSON I/O,
progress-resume helpers, and thin wrappers for transcription/translation/
metadata extraction. Not a numbered pipeline step.
"""

import os
import json
from pathlib import Path
from typing import Dict, Any, List, Set

from dotenv import load_dotenv
from tqdm import tqdm
from google import genai
from google.genai import types
from openai import OpenAI

# Load .env from the repo root (two levels up from this file)
load_dotenv(Path(__file__).resolve().parents[2] / ".env")


# --- Common utility functions ---

def load_api_tokens() -> List[str]:
    """Load Gemini API tokens from the GEMINI_API_TOKENS environment variable."""
    env_tokens = os.environ.get("GEMINI_API_TOKENS", "")
    if not env_tokens:
        return []
    tokens = [t.strip() for t in env_tokens.split(",") if t.strip()]
    print(f"Loaded {len(tokens)} API token(s) from GEMINI_API_TOKENS")
    return tokens


def build_client(api_key: str, model_name: str = 'gemini-2.5-flash'):
    """
    Build and return a client instance for the specified model.
    If the model is a GPT variant, return an OpenAI client.
    Otherwise, return a Gemini client.
    """
    if "gpt" in model_name.lower():
        base_url = os.environ.get("AZURE_OPENAI_BASE_URL")
        if not base_url:
            raise RuntimeError("AZURE_OPENAI_BASE_URL is not set. Add it to your .env file.")
        return OpenAI(
            base_url=base_url,
            api_key=api_key
        )
    else:
        return genai.Client(api_key=api_key)


def list_audio_files(input_dir: str) -> List[str]:
    """List all MP3 audio files in the input directory."""
    files = []
    for name in sorted(os.listdir(input_dir)):
        if name.lower().endswith(".mp3"):
            files.append(os.path.join(input_dir, name))
    return files


def list_json_files(input_dir: str) -> List[str]:
    """List all JSON files in the input directory."""
    files = []
    for name in sorted(os.listdir(input_dir)):
        if name.lower().endswith(".json"):
            files.append(os.path.join(input_dir, name))
    return files


def load_json_file(file_path: str) -> Dict[str, Any]:
    """Load a single JSON file."""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        print(f"Warning: Could not load {file_path}: {e}")
        return {}


def save_result_to_json(output_dir: str, file_name: str, result: Dict[str, Any]) -> None:
    """Save a single result to JSON file."""
    os.makedirs(output_dir, exist_ok=True)
    json_path = os.path.join(output_dir, f"{file_name}.json")

    try:
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(result, f, indent=2, ensure_ascii=False)
    except Exception as e:
        print(f"Warning: Could not save result to {json_path}: {e}")


def save_metadata_to_json(output_dir: str, file_name: str, result: Dict[str, Any]) -> None:
    """Save a single metadata result to JSON file."""
    os.makedirs(output_dir, exist_ok=True)
    json_path = os.path.join(output_dir, f"{file_name}_metadata.json")

    try:
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(result, f, indent=2, ensure_ascii=False)
    except Exception as e:
        print(f"Warning: Could not save result to {json_path}: {e}")


def load_existing_results(output_dir: str) -> Dict[str, Dict[str, Any]]:
    """Load existing results from JSON files."""
    results = {}
    if not os.path.exists(output_dir):
        return results

    try:
        for filename in os.listdir(output_dir):
            if filename.endswith('.json'):
                json_path = os.path.join(output_dir, filename)
                try:
                    with open(json_path, 'r', encoding='utf-8') as f:
                        result = json.load(f)
                        if 'file_name' in result:
                            results[result['file_name']] = result
                except Exception as e:
                    print(f"Warning: Could not load {json_path}: {e}")

        print(f"Loaded {len(results)} existing results from {output_dir}")
    except Exception as e:
        print(f"Warning: Could not read directory {output_dir}: {e}")

    return results


def load_existing_metadata_results(output_dir: str) -> Dict[str, Dict[str, Any]]:
    """Load existing metadata results from JSON files."""
    results = {}
    if not os.path.exists(output_dir):
        return results

    try:
        for filename in os.listdir(output_dir):
            if filename.endswith('_metadata.json'):
                json_path = os.path.join(output_dir, filename)
                try:
                    with open(json_path, 'r', encoding='utf-8') as f:
                        result = json.load(f)
                        if 'file_name' in result:
                            results[result['file_name']] = result
                except Exception as e:
                    print(f"Warning: Could not load {json_path}: {e}")

        print(f"Loaded {len(results)} existing metadata results from {output_dir}")
    except Exception as e:
        print(f"Warning: Could not read directory {output_dir}: {e}")

    return results


def get_failed_files(existing_results: Dict[str, Dict[str, Any]]) -> Set[str]:
    """Get set of file names that have failed processing (errors or empty)."""
    failed = set()

    for file_name, result in existing_results.items():
        transcribe_output = result.get('transcribe_output', '')
        if not transcribe_output or transcribe_output.startswith('ERROR:'):
            failed.add(file_name)

    return failed


def get_failed_metadata_files(existing_results: Dict[str, Dict[str, Any]]) -> Set[str]:
    """Get set of file names that have failed metadata extraction (errors or empty)."""
    failed = set()

    for file_name, result in existing_results.items():
        if 'metadata_error' in result or not any(key.startswith('metadata_') for key in result.keys()):
            failed.add(file_name)

    return failed


def get_json_path(output_dir: str, file_name: str) -> str:
    """Get the JSON file path for a given audio file."""
    base_name = os.path.splitext(file_name)[0]
    return os.path.join(output_dir, f"{base_name}.json")


# --- API interaction functions ---

def transcribe_file(client: genai.Client, model_name: str, audio_file_path: str, system_prompt: str, temperature: float = 0.2, thinking_budget: int = 0) -> str:
    """Transcribe an audio file using the Gemini API."""
    uploaded_file = client.files.upload(file=audio_file_path)

    response = client.models.generate_content(
        model=model_name,
        contents=[uploaded_file],
        config=types.GenerateContentConfig(
            system_instruction=system_prompt,
            thinking_config=types.ThinkingConfig(thinking_budget=thinking_budget),
            temperature=temperature,
            tools=[],
            automatic_function_calling=types.AutomaticFunctionCallingConfig(disable=True),
        ),
    )

    text = getattr(response, "text", None)

    if not text or text.strip() == "":
        print(f"ERROR: Empty response from API for {os.path.basename(audio_file_path)}")
        return "ERROR: Empty response from API"

    return text


def translate_transcript(client: genai.Client, model_name: str, english_transcript: str, system_prompt: str, temperature: float = 0.1) -> str:
    """Translate an English transcript to Arabic."""
    if not english_transcript:
        return None
    response = client.models.generate_content(
        model=model_name,
        contents=english_transcript,
        config=types.GenerateContentConfig(
            system_instruction=system_prompt,
            thinking_config=types.ThinkingConfig(thinking_budget=0),
            temperature=temperature,
        ),
    )
    return getattr(response, "text", None)


def translate_transcript_gpt5(client, deployment_name: str, english_transcript: str, system_prompt: str, temperature: float = 0.1) -> str:
    """Translate an English transcript to Arabic using GPT-5."""
    if not english_transcript:
        return None

    context = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": english_transcript}
    ]

    completion = client.responses.create(
        model=deployment_name,
        reasoning={"effort": "low"},
        input=context
    )

    if completion.output_text.startswith("I'm sorry, but I cannot assist with that request."):
        context += completion.output
        context += [{"role": "user", "content": "do it"}]

        completion = client.responses.create(
            model=deployment_name,
            reasoning={"effort": "low"},
            input=context
        )

    return getattr(completion, "output_text", None)


def extract_metadata_from_transcript(client: genai.Client, model_name: str, transcript_text: str, system_prompt: str, temperature: float = 0.1) -> Dict[str, Any]:
    """Extract metadata from a transcript using the Gemini API."""
    if not transcript_text or transcript_text.strip() == "":
        return {"metadata_error": "Empty transcript"}

    try:
        response = client.models.generate_content(
            model=model_name,
            contents=transcript_text,
            config=types.GenerateContentConfig(
                system_instruction=system_prompt,
                thinking_config=types.ThinkingConfig(thinking_budget=0),
                temperature=temperature,
            ),
        )

        text = getattr(response, "text", "") or ""

        if not text or text.strip() == "":
            return {"metadata_error": "Empty response from API"}

        cleaned_text = text.strip()

        if cleaned_text.startswith("```json"):
            cleaned_text = cleaned_text[7:]
        elif cleaned_text.startswith("```"):
            cleaned_text = cleaned_text[3:]

        if cleaned_text.endswith("```"):
            cleaned_text = cleaned_text[:-3]

        cleaned_text = cleaned_text.strip()

        try:
            data = json.loads(cleaned_text)
            if isinstance(data, dict):
                return data
            return {"metadata_raw": text, "metadata_error": "Response is not a valid JSON object"}
        except json.JSONDecodeError as e:
            return {"metadata_raw": text, "metadata_error": f"JSON decode error: {e}"}

    except Exception as e:
        return {"metadata_error": f"API error: {e}"}
