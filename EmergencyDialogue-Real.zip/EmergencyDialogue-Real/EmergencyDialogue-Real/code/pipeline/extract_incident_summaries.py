"""
Extract Incident Summaries from 911 Call Dialogues.

Brief: Reads dialogue files from the final dataset and uses an LLM to extract
concise incident summaries (2 sentences max) for each call. Supports resume.
"""

import os
import argparse
from pathlib import Path
from typing import Dict, Any, List

from dotenv import load_dotenv
from tqdm import tqdm

load_dotenv(Path(__file__).resolve().parents[2] / ".env")

from utils import (
    build_client,
    list_json_files,
    load_json_file,
    save_result_to_json,
    load_existing_results,
)


SUMMARY_SYSTEM_PROMPT = """You are an expert at analyzing 911 emergency call dialogues and extracting concise incident summaries.

Your task is to read the Arabic dialogue between a 911 dispatcher and caller(s) and provide a clear, factual summary of the incident.

Guidelines:
1. Write the summary in English
2. Maximum 2 sentences, and as short as possible.
3. Focus on the key facts: what happened, where, and the nature of the emergency
4. Be objective and factual - avoid speculation
5. Include relevant details like type of emergency, and key circumstances
6. Do not include personal information or names unless essential to understanding the incident

Example format:
"A person is experiencing seizures at the intersection of King Fahd Road and Tahliya Street. The caller is requesting immediate medical assistance for their brother who is 23 years old."

Provide only the summary text, no additional formatting or explanations."""


def extract_dialogue_text(dialogue_data: List[Dict[str, str]]) -> str:
    """Convert dialogue list to readable text format."""
    if not dialogue_data:
        return ""

    text_lines = []
    for exchange in dialogue_data:
        role = exchange.get("role", "")
        content = exchange.get("content", "")

        if role == "assistant":
            text_lines.append(f"DISPATCHER: {content}")
        elif role == "user":
            text_lines.append(f"CALLER: {content}")
        else:
            text_lines.append(f"{role.upper()}: {content}")

    return "\n".join(text_lines)


def extract_incident_summary(client, deployment_name: str, dialogue_text: str) -> str:
    """Extract incident summary using the LLM."""
    if not dialogue_text or dialogue_text.strip() == "":
        return "ERROR: Empty dialogue"

    context = [
        {"role": "system", "content": SUMMARY_SYSTEM_PROMPT},
        {"role": "user", "content": f"Please analyze this 911 call dialogue and provide a summary:\n\n{dialogue_text}"}
    ]

    try:
        completion = client.responses.create(
            model=deployment_name,
            reasoning={"effort": "low"},
            input=context
        )

        summary = getattr(completion, "output_text", "").strip()

        if not summary or summary.startswith("I'm sorry, but I cannot assist with that request."):
            context += completion.output if hasattr(completion, 'output') else []
            context += [{"role": "user", "content": "Please provide the summary"}]

            completion = client.responses.create(
                model=deployment_name,
                reasoning={"effort": "low"},
                input=context
            )
            summary = getattr(completion, "output_text", "").strip()

        return summary if summary else "ERROR: Empty response from API"

    except Exception as e:
        return f"ERROR: API error - {str(e)}"


def process_dialogue_files(
    input_dir: str,
    output_dir: str,
    api_key: str,
    deployment_name: str,
) -> None:
    """Process all dialogue files and extract summaries."""
    existing_results = load_existing_results(output_dir)
    processed_files = set(existing_results.keys())

    dialogue_files = list_json_files(input_dir)

    files_to_process = []
    for file_path in dialogue_files:
        file_name = os.path.splitext(os.path.basename(file_path))[0]
        if file_name not in processed_files:
            files_to_process.append((file_path, file_name))

    if not files_to_process:
        print("All files have already been processed.")
        return

    print(f"Processing {len(files_to_process)} files...")

    client = build_client(api_key, deployment_name)

    for file_path, file_name in tqdm(files_to_process, desc="Extracting summaries"):
        try:
            dialogue_data = load_json_file(file_path)

            if not dialogue_data:
                print(f"Warning: Could not load {file_path}")
                continue

            dialogue_text = extract_dialogue_text(dialogue_data.get("dialogue", []))

            if not dialogue_text:
                print(f"Warning: No dialogue found in {file_path}")
                continue

            summary = extract_incident_summary(client, deployment_name, dialogue_text)

            result = {
                "file_name": file_name,
                "summary": summary
            }

            save_result_to_json(output_dir, file_name, result)

            if summary.startswith("ERROR:"):
                print(f"Error processing {file_name}: {summary}")

        except Exception as e:
            print(f"Error processing {file_path}: {str(e)}")
            continue

    print(f"Processing complete. Results saved to {output_dir}")


def main():
    parser = argparse.ArgumentParser(description="Extract incident summaries from 911 call dialogues")
    parser.add_argument("--input-dir", required=True, help="Directory containing dialogue JSON files")
    parser.add_argument("--output-dir", required=True, help="Directory to save summary JSON files")
    parser.add_argument("--deployment-name", default="gpt-4o", help="Model deployment name")

    args = parser.parse_args()

    api_key = os.environ.get("AZURE_OPENAI_API_KEY", "")
    if not api_key:
        raise RuntimeError("AZURE_OPENAI_API_KEY is not set. Add it to your .env file.")

    process_dialogue_files(
        input_dir=args.input_dir,
        output_dir=args.output_dir,
        api_key=api_key,
        deployment_name=args.deployment_name,
    )


if __name__ == "__main__":
    main()
