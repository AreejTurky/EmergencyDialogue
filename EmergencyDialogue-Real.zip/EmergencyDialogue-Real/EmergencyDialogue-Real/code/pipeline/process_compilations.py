"""
Pipeline Step 7: Split compilation dialogues into separate calls.

Brief: For items classified as "compilation", loads the source transcript and
asks the model to segment it into distinct calls, preserving line order.
Outputs a structured JSON with per-call transcripts and an explanation.
"""

import os
import json
import argparse
from pathlib import Path
from typing import Dict, Any, Tuple, Optional

from dotenv import load_dotenv
from tqdm import tqdm

load_dotenv(Path(__file__).resolve().parents[2] / ".env")

from utils import (
    list_json_files,
    load_json_file,
    save_result_to_json,
    build_client,
    load_existing_results,
    translate_transcript_gpt5,
)


SEGMENT_SYSTEM_PROMPT = """You are an assistant that segments 911 call transcripts into separate calls when a transcript is a stitched compilation.
Input: a single transcript where each line is 'LABEL: text'. Labels like DISPATCHER, 911 OPERATOR, OPERATOR, CALLER, WITNESS, etc. The content may be in Arabic or English. Do NOT translate, paraphrase, or fix typos. Keep lines exactly as-is.
Your tasks:
1) Decide boundaries between distinct calls (e.g., a new dispatcher greeting like '911' or a fresh call start, or a new caller starting a separate call).
2) Split the transcript into an ordered list of calls, preserving the original line order and content within each call.
3) Provide a one-sentence explanation describing the situation (e.g., multiple calls; callbacks for the same incident; multiple different callers about the same incident).
Output STRICT JSON only with this schema:
{
  "calls": [
    {"id": 1, "transcript": "...exact lines for call 1..."},
    {"id": 2, "transcript": "...exact lines for call 2..."}
  ],
  "explanation": "one concise English sentence"
}
Rules:
- Do NOT include any extra keys.
- Do NOT wrap JSON in markdown fences.
- If you believe it is a single call despite being marked compilation, still return one call and set explanation accordingly.
"""


def _strip_fences(text: str) -> str:
    t = (text or "").strip()
    if t.startswith("```json"):
        t = t[7:]
    if t.startswith("```"):
        t = t[3:]
    if t.endswith("```"):
        t = t[:-3]
    return t.strip()


def parse_classification_output(raw_output: str) -> Dict[str, Any]:
    if not isinstance(raw_output, str) or not raw_output.strip():
        return {}
    try:
        return json.loads(_strip_fences(raw_output))
    except Exception:
        return {}


def parse_llm_json(text: str) -> Optional[Dict[str, Any]]:
    if not text:
        return None
    try:
        data = json.loads(_strip_fences(text))
        return data if isinstance(data, dict) else None
    except Exception:
        return None


def find_transcript(file_stem: str, transcript_dir: str) -> Tuple[Optional[str], Optional[str]]:
    path = os.path.join(transcript_dir, f"{file_stem}.json")
    if not os.path.exists(path):
        return None, None
    data = load_json_file(path)
    if not data:
        return None, None
    text = data.get("translation_output") or data.get("transcribe_output")
    return (text if isinstance(text, str) and text.strip() else None, path)


def segment_with_llm(client, transcript_text: str, deployment_name: str) -> Dict[str, Any]:
    output_text = translate_transcript_gpt5(
        client=client,
        deployment_name=deployment_name,
        english_transcript=transcript_text,
        system_prompt=SEGMENT_SYSTEM_PROMPT,
    )

    data = parse_llm_json(output_text or "")
    if not data:
        raise RuntimeError("Model returned empty or non-JSON output")

    calls = data.get("calls")
    explanation = data.get("explanation")
    if not isinstance(calls, list) or not isinstance(explanation, str):
        raise RuntimeError("Model output missing 'calls' or 'explanation'")

    normalized = []
    for i, item in enumerate(calls, start=1):
        tx = item.get("transcript", "") if isinstance(item, dict) else str(item)
        normalized.append({"id": item.get("id", i) if isinstance(item, dict) else i, "transcript": tx})

    return {"calls": normalized, "explanation": explanation}


def run_compilation_processing(
    input_dir: str,
    output_dir: str,
    transcript_dir: str,
    api_key: str,
    model_name: str = "gpt-4o",
) -> None:
    os.makedirs(output_dir, exist_ok=True)
    all_files = list_json_files(input_dir)
    if not all_files:
        raise RuntimeError(f"No .json files found in {input_dir}")

    to_process = []
    for path in all_files:
        cls = load_json_file(path)
        parsed = parse_classification_output(cls.get("output", "")) if cls else {}
        if (parsed.get("type") or "").strip().lower() == "compilation":
            to_process.append(path)

    if not to_process:
        print("No 'compilation' dialogues to process.")
        return

    existing = load_existing_results(output_dir)
    pending = []
    for path in to_process:
        stem = os.path.splitext(os.path.basename(path))[0]
        prev = existing.get(stem)
        if not prev or ('error' in prev):
            pending.append(path)

    if not pending:
        print("All 'compilation' dialogues already processed without errors.")
        return

    client = build_client(api_key, model_name=model_name)

    processed = 0
    pbar = tqdm(pending, desc="Processing compilation dialogues", unit="file")
    for path in pbar:
        file_stem = os.path.splitext(os.path.basename(path))[0]
        pbar.set_description(f"Segmenting {file_stem}")

        transcript_text, source_path = find_transcript(file_stem, transcript_dir)
        if not transcript_text:
            result = {
                "file_name": file_stem,
                "source_classification_file": os.path.basename(path),
                "source_transcript_file": os.path.relpath(source_path, start=os.getcwd()) if source_path else None,
                "segmentation_method": model_name,
                "call_count": 0,
                "explanation": "Transcript missing or empty; cannot segment.",
                "calls": [],
                "error": f"Transcript missing or empty for {file_stem}",
            }
            save_result_to_json(output_dir, file_stem, result)
            processed += 1
            continue

        try:
            seg = segment_with_llm(client, transcript_text, deployment_name=model_name)
            result = {
                "file_name": file_stem,
                "source_classification_file": os.path.basename(path),
                "source_transcript_file": os.path.relpath(source_path, start=os.getcwd()) if source_path else None,
                "segmentation_method": model_name,
                "call_count": len(seg["calls"]),
                "explanation": seg["explanation"],
                "calls": seg["calls"],
            }
        except Exception as e:
            result = {
                "file_name": file_stem,
                "source_classification_file": os.path.basename(path),
                "source_transcript_file": os.path.relpath(source_path, start=os.getcwd()) if source_path else None,
                "segmentation_method": model_name,
                "call_count": 0,
                "explanation": "Segmentation failed; manual review needed.",
                "calls": [],
                "error": str(e),
            }
        save_result_to_json(output_dir, file_stem, result)
        processed += 1

    pbar.close()
    print(f"Processed {processed} compilation files. Results saved to: {output_dir}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Split 'compilation' dialogues into separate calls")
    parser.add_argument("--input_dir", type=str, required=True, help="Directory containing classification JSON files")
    parser.add_argument("--transcript_dir", type=str, required=True, help="Directory containing Arabic translation transcripts")
    parser.add_argument("--output_dir", type=str, required=True, help="Directory to save split-call JSON results")
    parser.add_argument("--model_name", type=str, default="gpt-4o", help="Deployment/model name for segmentation")
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()

    api_key = os.environ.get("AZURE_OPENAI_API_KEY", "")
    if not api_key:
        raise RuntimeError("AZURE_OPENAI_API_KEY is not set. Add it to your .env file.")

    run_compilation_processing(
        input_dir=args.input_dir,
        output_dir=args.output_dir,
        transcript_dir=args.transcript_dir,
        api_key=api_key,
        model_name=args.model_name,
    )
