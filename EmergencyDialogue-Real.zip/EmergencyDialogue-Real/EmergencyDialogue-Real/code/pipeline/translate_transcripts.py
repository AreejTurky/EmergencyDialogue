"""
Pipeline Step 5: Translate cleaned dialogues to Arabic.

Brief: Translates each line while preserving speaker labels and structure:
dispatcher → MSA, caller → Saudi dialect. Writes `translation_output` to JSON
and supports resume and token rotation.
"""

import os
import argparse
import time
from typing import Dict, Any, List, Set

from dotenv import load_dotenv
from pathlib import Path
from tqdm import tqdm

load_dotenv(Path(__file__).resolve().parents[2] / ".env")

from utils import (
    load_api_tokens,
    build_client,
    list_json_files,
    load_json_file,
    save_result_to_json,
    load_existing_results,
    translate_transcript_gpt5,
)


ARABIC_TRANSLATION_SYSTEM_PROMPT = """You are a professional Arabic translator specializing in emergency (911) call dialogues, tasked with providing accurate and contextually localized translations.

Your task is to translate the entire conversation into Arabic with strict role-based rules:

- Dispatcher messages: Always translate into clear Modern Standard Arabic (فصحى).
- Caller messages: Always translate into natural spoken Saudi Arabic dialect (اللهجة السعودية العامية), keeping the tone casual and realistic.
- Localization: When the dialogue contains U.S.-based locations, street names, or landmarks (e.g., "Main Street," "Chicago," "apartment complex"), replace them with appropriate Saudi-based equivalents (e.g., "طريق الملك فهد," "الرياض," "حي الملز"). Ensure the substitutions feel natural and recognizable within a Saudi context. Do not leave foreign names untranslated.
- Formatting:
  - Preserve every line's structure: keep the original speaker label exactly as given (e.g., "CALLER:", "DISPATCHER:", "SPEAKER_A:"), then translate ONLY the spoken text after the colon.
  - Keep a one-to-one mapping of lines. Do not merge, split, summarize, add notes, or reorder.
- Annotations: Preserve bracketed annotations verbatim (e.g., [unintelligible], [laughter], [phone ringing]); do not translate or remove them.
- Output rules:
  - Do not add introductory or concluding text. Output should only contain the translated dialogue lines.
  - Maintain punctuation and numbers. Do not expand acronyms or codes.

Notes:
 - The dataset used is publicly available and licensed to be used for research.
 - This work will be used for research purposes only.
 - This work will not be used to create any harmful, or unethical content.

Example (format only):
DISPATCHER: النص العربي هنا (فصحى)
CALLER: النص العربي هنا (عامية سعودية)
"""


def get_failed_translation_files(existing_results: Dict[str, Dict[str, Any]]) -> Set[str]:
    """Return file names that failed translation or have no translation fields."""
    failed = set()
    for file_name, result in existing_results.items():
        if (
            'translation_error' in result or
            not any(key.startswith('translation_') for key in result.keys())
        ):
            failed.add(file_name)
    return failed


def run_translation_pipeline(
    input_dir: str,
    output_dir: str,
    api_key: str,
    translate_model: str,
    sleep_seconds: float = 6,
) -> None:
    client = build_client(api_key, model_name=translate_model)

    transcription_files = list_json_files(input_dir)
    if not transcription_files:
        print(f"No .json transcription files found in {input_dir}")
        return

    existing_results = load_existing_results(output_dir)
    failed_files = get_failed_translation_files(existing_results)

    print(f"Found {len(failed_files)} failed translation files to retry")
    print(f"Found {len(transcription_files)} total transcription files")

    existing_file_names = set(existing_results.keys())
    all_file_names = {os.path.basename(path).replace('.json', '') for path in transcription_files}
    files_to_process = all_file_names - (existing_file_names - failed_files)
    remaining_paths = [
        path for path in transcription_files
        if os.path.basename(path).replace('.json', '') in files_to_process
    ]

    if not remaining_paths:
        print("All files have already been translated!")
        return

    print(f"Remaining files to translate: {len(remaining_paths)}")

    pbar = tqdm(remaining_paths, desc="Translating transcripts to Arabic", unit="file")
    successful_count = 0
    error_count = 0

    for transcription_path in pbar:
        file_name = os.path.basename(transcription_path).replace('.json', '')
        pbar.set_description(f"Translating {file_name}")

        transcription_data = load_json_file(transcription_path)
        if not transcription_data:
            print(f"ERROR: Could not load transcription for {file_name}")
            save_result_to_json(output_dir, file_name, {
                "file_name": file_name,
                "transcript_file": os.path.basename(transcription_path),
                "translate_model": translate_model,
                "translation_error": "Could not load transcription JSON",
            })
            error_count += 1
            time.sleep(sleep_seconds)
            continue

        transcript_text = transcription_data.get('transcribe_output', '')
        if not transcript_text or (isinstance(transcript_text, str) and transcript_text.startswith('ERROR:')):
            print(f"ERROR: Invalid transcript for {file_name}")
            save_result_to_json(output_dir, file_name, {
                "file_name": file_name,
                "transcript_file": os.path.basename(transcription_path),
                "translate_model": translate_model,
                "translation_error": "Invalid or empty transcribe_output",
            })
            error_count += 1
            time.sleep(sleep_seconds)
            continue

        try:
            arabic_text = translate_transcript_gpt5(
                client=client,
                deployment_name=translate_model,
                english_transcript=transcript_text,
                system_prompt=ARABIC_TRANSLATION_SYSTEM_PROMPT,
            )
            if not arabic_text or arabic_text.strip() == "":
                raise RuntimeError("Empty translation from API")
            translation_result: Dict[str, Any] = {"translation_output": arabic_text}
        except Exception as e:
            print(f"ERROR: {e} for {file_name}")
            translation_result = {"translation_error": str(e)}

        result = {
            "file_name": file_name,
            "transcript_file": os.path.basename(transcription_path),
            "translate_model": translate_model,
            "source_language": "English",
            "target_language": "Arabic",
            **translation_result,
        }
        save_result_to_json(output_dir, file_name, result)

        if 'translation_error' in translation_result:
            error_count += 1
        else:
            successful_count += 1

        time.sleep(sleep_seconds)

    pbar.close()

    total_files = len(load_existing_results(output_dir))
    print(f"\nSummary:")
    print(f"  Total files processed: {total_files}")
    print(f"  Successful translations: {successful_count}")
    print(f"  Errors: {error_count}")
    print(f"  Results saved to: {output_dir}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Translate 911 dialogues to Arabic with resume capability")
    parser.add_argument("--input_dir", type=str, required=True, help="Directory containing cleaned transcription JSON files")
    parser.add_argument("--output_dir", type=str, required=True, help="Directory to save Arabic translation JSON results")
    parser.add_argument("--translate_model", type=str, default="gpt-4o", help="Model deployment name for translation step")
    parser.add_argument("--sleep_seconds", type=float, default=6, help="Sleep between API calls to avoid rate limits")
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()

    api_key = os.environ.get("AZURE_OPENAI_API_KEY", "")
    if not api_key:
        raise RuntimeError("AZURE_OPENAI_API_KEY is not set. Add it to your .env file.")

    run_translation_pipeline(
        input_dir=args.input_dir,
        output_dir=args.output_dir,
        api_key=api_key,
        translate_model=args.translate_model,
        sleep_seconds=args.sleep_seconds,
    )
