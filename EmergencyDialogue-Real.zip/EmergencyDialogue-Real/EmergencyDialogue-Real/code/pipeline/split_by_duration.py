"""
Pre-pipeline utility: Split audio files by duration.

Partitions a directory of .mp3 files into two output directories — one for
recordings within the duration threshold (suitable for single-call transcription)
and one for long recordings that are likely multi-call compilations. The latter
feeds into Step 7 (process_compilations.py) after the main pipeline runs.

A manifest.csv is written to each output directory listing file names and
durations in seconds.
"""

import os
import shutil
import argparse
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor, as_completed
from typing import Optional, Tuple, List

from tqdm import tqdm


def get_duration_seconds(args: Tuple[str, str]) -> Tuple[str, Optional[float]]:
    """Return (file_name, duration_seconds) for a single .mp3 file.

    Uses mutagen (no ffmpeg required) with a pydub fallback for formats
    mutagen cannot handle.
    """
    file_name, source_dir = args
    if not file_name.lower().endswith(".mp3"):
        return file_name, None

    full_path = os.path.join(source_dir, file_name)

    # Primary: mutagen — pure-Python, no ffmpeg dependency
    try:
        from mutagen.mp3 import MP3
        audio = MP3(full_path)
        return file_name, float(audio.info.length)
    except Exception:
        pass

    # Fallback: pydub (requires ffmpeg on PATH)
    try:
        from pydub import AudioSegment
        audio = AudioSegment.from_file(full_path)
        return file_name, float(len(audio) / 1000.0)
    except Exception:
        return file_name, None


def copy_file(src_dir: str, dst_dir: str, file_name: str) -> bool:
    try:
        os.makedirs(dst_dir, exist_ok=True)
        src = os.path.join(src_dir, file_name)
        dst = os.path.join(dst_dir, file_name)
        if not os.path.exists(dst):
            shutil.copy2(src, dst)
        return True
    except Exception:
        return False


def write_manifest(dst_dir: str, rows: List[Tuple[str, float]]) -> None:
    if not rows:
        return
    os.makedirs(dst_dir, exist_ok=True)
    with open(os.path.join(dst_dir, "manifest.csv"), "w", encoding="utf-8") as f:
        f.write("file,duration_sec\n")
        for file_name, duration in rows:
            f.write(f"{file_name},{duration:.6f}\n")


def run_split(source_dir: str, normal_dir: str, large_dir: str, threshold_minutes: float) -> None:
    threshold_seconds = threshold_minutes * 60

    all_files = [f for f in os.listdir(source_dir) if f.lower().endswith(".mp3")]
    if not all_files:
        raise SystemExit(f"No .mp3 files found in {source_dir}")

    print(f"Computing durations for {len(all_files)} files...")
    args = [(f, source_dir) for f in all_files]
    with ProcessPoolExecutor(max_workers=os.cpu_count() or 4) as executor:
        results = list(tqdm(executor.map(get_duration_seconds, args), total=len(all_files), desc="Reading durations"))

    normal_rows: List[Tuple[str, float]] = []
    large_rows: List[Tuple[str, float]] = []
    skipped = 0

    for file_name, dur in results:
        if dur is None:
            skipped += 1
            continue
        if dur > threshold_seconds:
            large_rows.append((file_name, dur))
        else:
            normal_rows.append((file_name, dur))

    print(f"  Normal (<= {threshold_minutes} min): {len(normal_rows)} files")
    print(f"  Long   (>  {threshold_minutes} min): {len(large_rows)} files")
    if skipped:
        print(f"  Skipped (unreadable): {skipped} files")

    copy_jobs = []
    with ThreadPoolExecutor(max_workers=16) as executor:
        for file_name, _ in normal_rows:
            copy_jobs.append(executor.submit(copy_file, source_dir, normal_dir, file_name))
        for file_name, _ in large_rows:
            copy_jobs.append(executor.submit(copy_file, source_dir, large_dir, file_name))
        for _ in tqdm(as_completed(copy_jobs), total=len(copy_jobs), desc="Copying files"):
            pass

    write_manifest(normal_dir, normal_rows)
    write_manifest(large_dir, large_rows)

    total_normal_h = sum(d for _, d in normal_rows) / 3600
    total_large_h = sum(d for _, d in large_rows) / 3600
    print(f"\nDone. Normal: {total_normal_h:.2f} h  |  Long: {total_large_h:.2f} h")
    print(f"Normal files → {normal_dir}")
    print(f"Long files   → {large_dir}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Split .mp3 files into normal and long-recording directories by duration."
    )
    parser.add_argument("--input_dir", type=str, required=True, help="Directory containing source .mp3 files")
    parser.add_argument("--normal_dir", type=str, required=True, help="Output directory for recordings within the threshold")
    parser.add_argument("--large_dir", type=str, required=True, help="Output directory for long recordings (compilations)")
    parser.add_argument("--threshold_minutes", type=float, default=10.0, help="Duration threshold in minutes (default: 10)")
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()

    if not os.path.isdir(args.input_dir):
        raise SystemExit(f"Input directory not found: {args.input_dir}")

    run_split(
        source_dir=args.input_dir,
        normal_dir=args.normal_dir,
        large_dir=args.large_dir,
        threshold_minutes=args.threshold_minutes,
    )
